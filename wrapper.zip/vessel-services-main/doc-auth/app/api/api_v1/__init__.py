from fastapi import APIRouter
from api.api_v1.admin_config.route import admin_config_router
from api.api_v1.domain.route import domain_router
from api.api_v1.project.route import project_router
from api.api_v1.template.route import template_router
from api.api_v1.document.route import document_router
from api.api_v1.dashboard.route import dashboard_router
from api.api_v1.chat_history.route import chat_history_router

api_router = APIRouter()
api_router.include_router(admin_config_router, tags=["admin-config"])
api_router.include_router(domain_router, tags=["domain"])
api_router.include_router(project_router, tags=["project"])
api_router.include_router(template_router, tags=["template"])
api_router.include_router(document_router, tags=["document"])
api_router.include_router(dashboard_router, tags=["dashboard"])
api_router.include_router(chat_history_router, tags=["chat history"])