from fastapi import APIRouter, Request
from config.load_config import config
from api.api_v1.project.controller import ProjectController
from schemas.requests.ProjectRequest import ProjectRequest, UpdateProjectRequest
from api.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
project_router = APIRouter(prefix=config["api_prefix"])


@project_router.post("/project")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_project(request : Request , create_project_request: ProjectRequest):
    """[API router to create new project into the system]

    Args:
        create_project_request (create): [New project details]

    Raises:
        HTTPException: [Unauthorized exception when invalid token is passed]
        error: [Exception in underlying controller]

    Returns:
        [createResponse]: [create new project response]
    """
    project_obj = ProjectController().create_project(create_project_request)
    return project_obj


@project_router.get("/project/mine")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_ntid_projects(request : Request ,ntid: str):
    """[Get List of all projects]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of projects]
    """
    list_of_projects = ProjectController().get_projects_ntid(ntid)
    return list_of_projects


@project_router.get("/all-project")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_projects(request : Request):
    """[Get List of all projects]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of projects]
    """
    list_of_projects = ProjectController().get_all_project()
    return list_of_projects


@project_router.put("/project")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def update_project(request : Request , create_project_request: UpdateProjectRequest):
    """[Update project by project name]

    Raises:
        error: [Error details]

    Returns:
        [str]: [Success response]
    """
    project_obj = ProjectController().update_project(create_project_request)
    return project_obj


@project_router.delete("/project")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def delete_project(request : Request , project_id: int):
    """[Get List of all project]

    Raises:
        error: [Error details]

    Returns:
        [str]: [Success response]
    """
    project_obj = ProjectController().delete_project(project_id)
    return project_obj

@project_router.get("/project/{project_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_project_by_id(request : Request , project_id: int):
    """[Get project details by id]
    Raises:
        error: [Error details]
    Returns:
        [str]: [Success response]
    """
    project_obj = ProjectController().get_project_by_id(project_id)
    return project_obj