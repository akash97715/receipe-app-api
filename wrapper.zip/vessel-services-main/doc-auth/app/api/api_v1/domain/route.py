from fastapi import APIRouter, Request
from api.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from config.load_config import config
from api.api_v1.domain.controller import DomainController

domain_router = APIRouter(prefix=config["api_prefix"])


@domain_router.get("/domains")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_domains(request : Request):
    """[Get List of all domains]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of domains]
    """
    list_of_domains = DomainController().get_all_domains_controller()
    return list_of_domains


@domain_router.get("/sub-domains")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_subdomains(request : Request, domain_id: int):
    """[Get List of all subdomains]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of subdomains]
    """
    list_of_sub_domains = DomainController().get_all_subdomains(domain_id)
    return list_of_sub_domains
