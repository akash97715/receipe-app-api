from fastapi import APIRouter, UploadFile, File, Form, Request
from api.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

from config.load_config import config
from api.api_v1.template.controller import TemplateController
import json

template_router = APIRouter(prefix=config["api_prefix"])


@template_router.post("/template")
@async_token_validation_and_metering(uom=3)
@auth_token_validation()
async def create_template(request : Request, create_temp_request: str = Form(...), fileb: UploadFile = File(...)):
    """[API router to create new template into the system]

    Args:
        create_temp_request (create): [New template details]

    Raises:
        HTTPException: [Unauthorized exception when invalid token is passed]
        error: [Exception in underlying controller]

    Returns:
        [createResponse]: [create new template response]
    """
    create_template_request = json.loads(create_temp_request)
    template_obj = TemplateController().create_template(
        create_template_request, fileb
    )
    return template_obj


@template_router.get("/template/all")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_templates(request : Request, project_id: int):
    """[Get List of all templates]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of templates]
    """
    list_of_templates = TemplateController().get_all_template(project_id)
    return list_of_templates


@template_router.get("/template/{template_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_template(request : Request, template_id: int):
    """[Get template by ID]

    Args:
        id: [Template id to look for]

    Raises:
        HTTPException: [Not found exception]
        error: [Error details]

    Returns:
        [dict]: [Template]
    """

    template_obj = TemplateController().get_template(template_id)

    return template_obj


@template_router.put("/template/{template_id}")
@async_token_validation_and_metering(uom=3)
@auth_token_validation()
async def update_template(request : Request, template_id: int, update_temp_request: str = Form(...), fileb: UploadFile = File(...)):
    """[Updates template by ID]

    Args:
        id: [Template id to look for]
        update_temp_request: [New template request]

    Raises:
        HTTPException: [Not found exception]
        error: [Error details]

    Returns:
        [dict]: [Updated template]
    """
    update_template_request = json.loads(update_temp_request)
    return TemplateController().update_template(
        template_id, update_template_request, fileb
    )


@template_router.delete("/template/{template_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def delete_template(request : Request, template_id: int):
    """[Delete template]

    Raises:
        error: [Error details]

    Returns:
        [str]: [Success response]
    """
    template_obj = TemplateController().delete_template(template_id)
    return template_obj
