from .oauth2_as_accessor import Oauth2AsAccessor
import os
from functools import wraps
import asyncio
import datetime
import uuid
import json
import time
import hashlib
from base64 import b64encode, b64decode

# AES_SECRET_KEY = os.environ.get('AES_SECRET_KEY','')
# METERING_SQS_QUEUE = os.environ.get('METERING_SQS_QUEUE','')
vendor_serial = {"otter": 1, "aws": 2, "azure": 3, "gcp": 4, "SYSTRAN": 5, "abbyy": 6, "VESSEL": 7}
uom_serial = {"audio_duration": 1, "character_count": 2, "file_size_bytes": 3, "request_counts": 4,
                          "page_count": 5 , "total_tokens": 6 , "total_tokens_docinsight" : 7}

def async_token_validation_and_metering(uom=0):
    def decorator(f):
        @wraps(f)
        async def wrapper(request=None,*args, **kwargs):
            token = None
            flask_flag=False
            from fastapi import FastAPI, HTTPException
            #raise HTTPException(status_code=401, detail="Item not found")
            if token is None and request is not None and  isinstance(request, dict)==False :
                token = request.headers['authorization'].split()[-1]

            if not token and not flask_flag: # throw error if no token provided
                raise HTTPException(status_code=401, detail={"statusCode": 401,"statusDescription": "401 Unauthorized","error":"b_token not found."})
                
            elif not token and flask_flag:

                raise HTTPException(status_code=401, detail={"statusCode": 401,"statusDescription": "401 Unauthorized","error":"b_token not found."})
                
            response=Oauth2AsAccessor.validate_oauth2_token(token)
            if response['active']:
                pass
            elif response['active']==False and not flask_flag:
                raise HTTPException(status_code=401, detail={"statusCode": 401,"statusDescription": "401 Unauthorized","error":"b_token is invalid."})
            
            elif response['active']==False and flask_flag:

                raise HTTPException(status_code=401, detail={"statusCode": 401,"statusDescription": "401 Unauthorized","error":"b_token is invalid."})

                
            if request:
                res =  await f(request, *args, **kwargs)
               
            else:
                res =  await f(*args, **kwargs)
            start = time.time()
            process_end_time = datetime.datetime.utcnow()
            try:
                json_body = await request.json()   
            except Exception as e:
                json_body = 0

            return res
            
        return wrapper

    return decorator