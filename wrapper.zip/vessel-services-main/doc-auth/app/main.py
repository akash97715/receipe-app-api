import uvicorn
from fastapi import FastAPI
from config.load_config import config
from starlette.middleware.cors import CORSMiddleware
from api.api_v1 import api_router
from fastapi.openapi.utils import get_openapi
from schemas.requests.HealthCheckRequest import HealthCheckResponse, Status
# import configparser, os

app = FastAPI(
    title="Doc Authoring Service",
    version="0.1",
    openapi_url=(config["api_prefix"] + "/openapi.json"),
    docs_url=(config["api_prefix"] + "/docs"),
    redoc_url=(config["api_prefix"] + "/redoc"),
)
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)


@app.get(
    f"{config['api_prefix']}/health_check",
    status_code=200,
    tags=["Health check"],
)
async def health_check():
    return HealthCheckResponse(
        status=Status.success, message="health_check completed successfully"
    )


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Doc Authoring Service",
        version="0.1",
        routes=app.routes,
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi

# cfg = configparser.ConfigParser()
# cfg.read('alembic.ini')


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
