# # Database Manager
# from database.db_manager import *
# from app import orm_models
# from db.session import acquire_db_session as session

# orm_models.Base.metadata.create_all(bind=engine)
