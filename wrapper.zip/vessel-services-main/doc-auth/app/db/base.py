# Import all the models, so that Base has them before being
# imported by Alembic

# from db.base_class import Base  # noqa
from app.orm_models.domain_config_model import *
from app.orm_models.admin_config_model import *
from app.orm_models.project_model import *
from app.orm_models.template_model import *
from app.orm_models.document_model import *