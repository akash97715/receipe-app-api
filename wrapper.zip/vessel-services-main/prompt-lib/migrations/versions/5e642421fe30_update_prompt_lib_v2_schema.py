"""Update prompt lib v2 schema

Revision ID: 5e642421fe30
Revises: 4ca5ead222ec
Create Date: 2023-12-17 01:20:20.229036

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '5e642421fe30'
down_revision: Union[str, None] = '4ca5ead222ec'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column('prompts', 'id', server_default=sa.text('gen_random_uuid()'), schema='v2')
    op.alter_column('prompts', 'version', server_default=sa.text('1'), schema='v2')
    op.alter_column('prompts', 'status', server_default=sa.text("'PENDING'"), schema='v2')
    op.alter_column('prompts', 'is_visible', server_default=sa.text('true'), schema='v2')
    op.alter_column('prompts', 'created_at', server_default=sa.func.now(), schema='v2')
    op.alter_column('prompts', 'modified_at', server_default=sa.func.now(), schema='v2')

    op.alter_column('prompts_share_map', 'id', server_default=sa.text('gen_random_uuid()'), schema='v2')
    op.alter_column('prompts_share_map', 'is_deleted', server_default=sa.text('false'), schema='v2')
    op.alter_column('prompts_share_map', 'created_at', server_default=sa.func.now(), schema='v2')
    op.alter_column('prompts_share_map', 'modified_at', server_default=sa.func.now(), schema='v2')

    op.alter_column('prompts_review_log', 'id', server_default=sa.text('gen_random_uuid()'), schema='v2')
    op.alter_column('prompts_review_log', 'review_status', server_default=sa.text("'PENDING'"), schema='v2')
    op.alter_column('prompts_review_log', 'created_at', server_default=sa.func.now(), schema='v2')
    op.alter_column('prompts_review_log', 'modified_at', server_default=sa.func.now(), schema='v2')



def downgrade() -> None:
    pass
