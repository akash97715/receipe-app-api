from pydantic import BaseModel


class UserDetails(BaseModel):
    nt_id : str
    user_name: str
    user_type: str
    group_id: int
