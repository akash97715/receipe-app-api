from pydantic import BaseModel

class Prompt(BaseModel):
    admin_config_id : int
    prompt_text : str
    version : int
    annotation : str
    use_case_type : str
    prompt_type : str
    request_type : str
    submitted_source : str
    ranking : int 
    tags : list
    nt_id : str