from pydantic import BaseModel
from typing import Optional

class PromptFilter(BaseModel):
    domain_name: str
    subdomain_name: str
    category_name: Optional[str]= None
    keyword: str