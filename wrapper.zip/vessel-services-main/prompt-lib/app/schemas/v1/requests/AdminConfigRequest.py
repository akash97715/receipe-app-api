from pydantic import BaseModel


class AdminConfigRequest(BaseModel):
    nt_id: str
    domain_name: str
    sub_domain_name: str
    category_name: str

