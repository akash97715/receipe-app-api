from pydantic import BaseModel

class UserFeedbackSchema(BaseModel):
    prompt_id: int
    ranking: int