from pydantic import BaseModel


class ApprovalPrompt(BaseModel):
    status: str
    approver_id: str
    prompt_ids: list[int]