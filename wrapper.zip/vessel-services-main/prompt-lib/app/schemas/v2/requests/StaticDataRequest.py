from pydantic import BaseModel
from typing import Optional, Any


class StaticDataRequest(BaseModel):
    id: str
    name: str
    raw_data: Any
