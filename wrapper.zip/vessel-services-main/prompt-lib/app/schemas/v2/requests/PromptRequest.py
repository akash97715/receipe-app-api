from datetime import datetime
from typing import List, Optional

from db.orm_models.v2.enums import Status
from schemas.v2.requests.PromptSharingRequests import BasicPromptSharingDetails
from pydantic import BaseModel


class PromptMetadata(BaseModel):
    model: str
    temperature: float
    max_word_count: int
    section: str


class CreatePrompt(BaseModel):
    system_prompt: str
    name: str
    prompt: str
    metadata_info: Optional[PromptMetadata] = {}
    tags: List[str]
    is_visible: bool
    sharing_details: Optional[List[BasicPromptSharingDetails]] = []

class UpdatePrompt(BaseModel):
    system_prompt: str
    name: str
    prompt: str
    metadata_info: Optional[PromptMetadata] = {}
    tags: List[str]
    is_visible: bool

class PromptReviewAction(BaseModel):
    review_status: Status
    review_comment: str
