from pydantic import BaseModel
from typing import Optional
from db.orm_models.v2.enums import Shared_with_type

class BasicPromptSharingDetails(BaseModel):
    shared_with_type: Shared_with_type
    shared_with_id: str = None

class PromptShareMap(BaseModel):
    id: str
    basic_prompt_sharing_details: BasicPromptSharingDetails