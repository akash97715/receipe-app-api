import enum


class Status(enum.Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    CHANGES_REQUESTED = "CHANGES_REQUESTED"
    REJECTED = "REJECTED"
    DELETED = "DELETED"

class Fetch_Status(enum.Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    CHANGES_REQUESTED = "CHANGES_REQUESTED"
    REJECTED = "REJECTED"
    DELETED = "DELETED"
    NOT_DELETED = "NOT_DELETED"
    NOT_REJECTED = "NOT_REJECTED"

class Sort_By(enum.Enum):
    ID = "id"
    NAME = "name"
    CREATED_AT = "created_at"
    MODIFIED_AT = "modified_at"
    IS_VISIBLE = "is_visible"


class Order_By(enum.Enum):
    ASC = "ASC"
    DESC = "DESC"

class Search_Logic(enum.Enum):
    AND = "AND"
    OR = "OR"

class Search_on(enum.Enum):
    ALL = "all"
    NAME = "name"
    PROMPT = "prompt"
    SYSTEM_PROMPT = "system_prompt"

class Shared_with_type(enum.Enum):
    USER = "USER"
    GROUP = "GROUP"
    TENANT ="TENANT"