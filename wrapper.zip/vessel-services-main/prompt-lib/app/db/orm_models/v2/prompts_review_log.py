import uuid

from sqlalchemy import (
    Column,
    DateTime,
    Enum,
    ForeignKeyConstraint,
    Integer,
    String,
    func,
    text
)
from sqlalchemy.dialects.postgresql import UUID

from ...base_class import Base
from .enums import Status
from .prompts import Prompts


class PromptsReviewLog(Base):
    __tablename__ = "prompts_review_log"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text('gen_random_uuid()'))
    prompt_id = Column(UUID(as_uuid=True), index=True, nullable=False)
    prompt_version = Column(Integer, index=True, nullable=False)
    review_status = Column(Enum(Status, schema="v2"), default=Status.PENDING, server_default=text(f"'{Status.PENDING}'"), index=True, nullable=False)
    review_comment = Column(String)
    created_by = Column(String, nullable=False)
    modified_by = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now(), server_default=func.now(), nullable=False)
    modified_at = Column(
        DateTime, default=func.now(), onupdate=func.now(), server_default=func.now(), server_onupdate=func.now(), nullable=False
    )

    __table_args__ = (ForeignKeyConstraint([prompt_id, prompt_version], [Prompts.id, Prompts.version]), {"extend_existing": True, "schema": "v2"})
