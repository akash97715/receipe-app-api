from sqlalchemy import (
    Column,
    String,
    DateTime,
    Boolean,
    text,
    Enum
)
from ...base_class import Base
from sqlalchemy import func
import uuid
from sqlalchemy.dialects.postgresql import UUID
from .enums import Shared_with_type

class PromptsShareMap(Base):
    __tablename__ = "prompts_share_map"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text('gen_random_uuid()'))
    prompt_id = Column(UUID(as_uuid=True), index=True, nullable=False)
    shared_with_type = Column(Enum(Shared_with_type, name="shared_with_type", schema="v2"), index=True, nullable=False)
    shared_with_id = Column(String, index=True, nullable=False)
    created_by = Column(String, nullable=False)
    modified_by = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now(), server_default=func.now(), nullable=False)
    modified_at = Column(
        DateTime, default=func.now(), onupdate=func.now(), server_default=func.now(), server_onupdate=func.now(), nullable=False
    )
    is_deleted = Column(Boolean, default=False, server_default=text('false'), nullable=False)

    __table_args__ = {"extend_existing": True, "schema": "v2"}

    