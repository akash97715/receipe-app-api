from sqlalchemy import (
    Column,
    String,
    text
)
from ...base_class import Base
from sqlalchemy.dialects.postgresql import JSONB

class StaticApiData(Base):
    __tablename__ = "static_data"
    id = Column(String, primary_key=True, nullable=False)
    name = Column(String, nullable=False)
    raw_data = Column(JSONB)
    __table_args__ = {"extend_existing": True, "schema": "v2"}

    