import uuid

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum,
    Integer,
    String,
    func,
    text
)
from sqlalchemy.dialects.postgresql import (UUID , JSONB,ARRAY)

from ...base_class import Base
from .enums import Status


class Prompts(Base):
    __tablename__ = "prompts"
    id = Column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text('gen_random_uuid()'), nullable=False
    )
    version = Column(Integer, primary_key=True, default=1, server_default=text('1'), nullable=False)
    name = Column(String, nullable=False)
    system_prompt = Column(String, index=True, nullable=False)
    prompt = Column(String, index=True, nullable=False)
    metadata_info = Column(JSONB)
    tags = Column(ARRAY(String))
    status = Column(Enum(Status, schema="v2"), default=Status.PENDING, server_default=text(f"'{Status.PENDING}'"), nullable=False)
    is_visible = Column(Boolean, default=True, server_default=text('true'), nullable=False)
    is_private = Column(Boolean, default=True, server_default=text('true'), nullable=False)
    creator_tenant_id = Column(String)
    created_by = Column(String, nullable=False)
    modified_by = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now(), server_default=func.now(), nullable=False)
    modified_at = Column(
        DateTime, default=func.now(), onupdate=func.now(), server_default=func.now(), server_onupdate=func.now(), nullable=False
    )

    __table_args__ = ({"extend_existing": True, "schema": "v2"},)
