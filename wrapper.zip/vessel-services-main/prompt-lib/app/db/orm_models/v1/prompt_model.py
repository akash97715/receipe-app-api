import enum
from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Enum
from ...base_class import Base


class Prompts(Base):
    __tablename__ = "prompts"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, index=True)
    prompt_text = Column(String, unique=True)
    version = Column(Integer)
    annotation = Column(String)
    use_case_type = Column(String)
    prompt_type = Column(String)
    request_type = Column(String) #enum
    submitted_source = Column(String) #enum
    ranking = Column(Integer, default=0)
    tags = Column(String)
    group_id = Column(Integer)
    admin_config_id = Column(Integer, ForeignKey("adminconfig.id"))
    nt_id = Column(String, ForeignKey("user.nt_id"))
    submitted_by = Column(String)


class Status(enum.Enum):
    PENDING = "Pending"
    APPROVED = "Approved"
    REJECTED = "Rejected"


class ApprovalPrompts(Base):
    __tablename__ = "approvalprompts"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, index=True)
    prompt_id = Column(Integer, ForeignKey("prompts.id"))
    prompt_text = Column(String, unique=True)
    version = Column(Integer)
    annotation = Column(String)
    approver_id = Column(String, ForeignKey("user.nt_id"), default=None)
    submitted_by = Column(String)
    status = Column(Enum(Status), default=Status.PENDING)
    approved_time = Column(DateTime)
    use_case_type = Column(String)
    prompt_type = Column(String)
    request_type = Column(String) #enum
    submitted_source = Column(String) #enum
    ranking = Column(Integer, default= 0)
    tags = Column(String)
    group_id = Column(Integer)
    admin_config_id = Column(Integer, ForeignKey("adminconfig.id"))
    nt_id = Column(String, ForeignKey("user.nt_id"))
