from sqlalchemy import Column, String, Integer, ForeignKey, DateTime
from ...base_class import Base
from sqlalchemy.sql import func


class AdminConfig(Base):
    __tablename__ = "adminconfig"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True)
    nt_id = Column(String, ForeignKey("user.nt_id"))
    domain_id = Column(Integer, ForeignKey("domain.id"))
    sub_domain_id = Column(Integer, ForeignKey("subdomain.id"))
    category_id = Column(Integer, ForeignKey("category.id"))
    display = Column(String)
    created_at = Column(DateTime, default=func.now())


class User(Base):
    __tablename__ = "user"
    __table_args__ = {"extend_existing": True}
    nt_id = Column(String, primary_key=True)
    user_name = Column(String)
    user_type = Column(String)
    group_id = Column(Integer, ForeignKey("group.id"))

class Group(Base):
    __tablename__ = "group"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True)
    group_name = Column(String)