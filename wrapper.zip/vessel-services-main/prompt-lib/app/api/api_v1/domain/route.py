from fastapi import APIRouter, Request
from api.dependencies.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

from config.load_config import config
from api.api_v1.domain.controller import DomainController
from schemas.v1.requests.DomainRequest import DomainRequest
from schemas.v1.requests.SubDomainRequest import SubDomainRequest
from utils.logs.logger_config import logger

domain_router = APIRouter()


@domain_router.post("/domain", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_domain(request: Request,
    create_domain_request : DomainRequest
):
    """[API router to create new domain into the system]
    Tags : [unused]
    Args:
        create_domain_request (create): [New domain details]

    Raises:
        error: [Exception details]

    Returns:
        [createResponse]: [create new domain response]
    """
    logger.info("calling domain register router ...")
    domain_obj = DomainController().create_domain(
        create_domain_request
    )
    return domain_obj


@domain_router.get("/domain", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_domains(request: Request):
    """[Get List of all domains]
    Tags : [unused]
    Raises:
        error: [Error details]

    Returns:
        [list]: [List of domains]
    """
    logger.info("calling get-domains router ...")
    list_of_domains = DomainController().get_all_domains()
    return list_of_domains

# sub-domains routers ----------------------------------------------------------------------

@domain_router.post("/sub-domain", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_subdomain(request: Request,
    create_subdomain_request : SubDomainRequest
):
    """[API router to create new subdomain into the system]
    Tags : [unused]
    Args:
        create_domain_request (create): [New subdomain details]

    Raises:
        error: [Exception details]

    Returns:
        [createResponse]: [create new subdomain response]
    """
    logger.info("calling sub-domains register router ...")
    sub_domain_obj = DomainController().create_subdomain(
        create_subdomain_request
    )
    return sub_domain_obj


@domain_router.get("/sub-domain", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_subdomains(request: Request):
    """[Get List of all subdomains]
    Tags : [unused]
    Raises:
        error: [Error details]

    Returns:
        [list]: [List of subdomains]
    """
    logger.info("calling get-sub-domains router ...")
    list_of_sub_domains = DomainController().get_all_subdomains()
    return list_of_sub_domains
