from crud.v1.domain_crud import CRUDDomain
from crud.v1.subdomain_crud import CRUDSubDomain
from utils.logs.logger_config import logger

class DomainController:
    def __init__(self):
        self.CRUDDomain = CRUDDomain()  
        self.CRUDSubDomain = CRUDSubDomain()


    def get_all_domains(self):
        """[Controller to get all domains]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [list]: [list of all the domains in the system]
        """
        logger.info("executing get-all-domains-controller ...")
        return self.CRUDDomain.read_all()


    def create_domain(self, request):
        """[Controller to register new domain]

        Args:
            request ([dict]): [create new domain request]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [authorization details]
        """
        logger.info("executing create-domain-controller ...")
        logger.info("executing get-by-name domain function ...")
        domain_obj = self.CRUDDomain.get_by_name(name=request.name.lower())
        if domain_obj is not None:
            return domain_obj
        domain_request = {
                "name": request.name.lower()
            }
        return self.CRUDDomain.create(**domain_request)


    def delete_domain(self, id: int):
        """[delete Domain Details]

        Args:
            domain_id (str): [domain_id of the Domain]

        Returns:
            [dict]: [Domain details]
         """
        logger.info("executing delete-domain-controller ...")
        return self.CRUDDomain.delete(id = id)
    
    def get_domain_by_id(self, id: int):
        """[Get Domain Details by Id]

        Args:
            domain_id (int): [domain_id of the Domain]

        Returns:
            [dict]: [Domain details]
         """
        logger.info("executing get-domain-by-id-controller ...")
        return self.CRUDDomain.get_by_id(id)

# for sub-domains---------------------------------------------------------------------------

    def get_all_subdomains(self):
        """[Controller to get all sub-domains]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [list]: [list of all the sub-domains in the system]
        """
        logger.info("executing get-all-subdomains-controller ...")
        return self.CRUDSubDomain.read_all()


    def create_subdomain(self, request):
        """[Controller to register new subdomain]

        Args:
            request ([dict]): [create new subdomain request]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [authorization details]
        """
        logger.info("executing create-subdomain-controller ...")
        logger.info("executing get-by-name subdomain function ...")
        subdomain_obj = self.CRUDSubDomain.get_by_name(name=request.name.lower(), domain_id=request.domain_id)
        if subdomain_obj is not None:
            return subdomain_obj
        domain_request = {
                "name": request.name.lower(),
                "domain_id" : request.domain_id
            }
        return self.CRUDSubDomain.create(**domain_request)


    def delete_subdomain(self, id: int):
        """[delete subDomain Details]

        Args:
            subdomain_id (str): [subdomain_id of the subDomain]

        Returns:
            [dict]: [subDomain details]
         """
        logger.info("executing delete-domain-controller ...")
        return self.CRUDSubDomain.delete(id = id)

    def get_subdomain_by_id(self, id: int):
        """[Get Sub Domain Details by Id]

        Args:
            subdomain_id (int): [subdomain_id of the Domain]

        Returns:
            [dict]: [Sub Domain details]
         """
        logger.info("executing get-subdomain-by-id-controller ...")
        return self.CRUDSubDomain.get_by_id(id)