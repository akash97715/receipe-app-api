from fastapi import APIRouter, Request
from config.load_config import config
from api.api_v1.admin_config.controller import AdminConfigController
from schemas.v1.requests.AdminConfigRequest import AdminConfigRequest
from utils.logs.logger_config import logger
from api.dependencies.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation


admin_config_router = APIRouter()


@admin_config_router.post("/admin-config")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_admin_config(request: Request, create_admin_config_request: AdminConfigRequest):
    """[API router to create new admin_config into the system]

    Args:
        create_admin_config_request (create): [New admin_config details]

    Raises:
        error: [Exception details]

    Returns:
        [createResponse]: [create new admin_config response]
    """
    logger.info("calling admin-config router ...")
    admin_config_obj = AdminConfigController().create_admin_config(
        create_admin_config_request
    )
    return admin_config_obj


@admin_config_router.get("/admin-config", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_admin_configs(request: Request):
    """[Get List of all admin_configs]
    Tags : [unused]
    Raises:
        error: [Error details]

    Returns:
        [list]: [List of categories]
    """
    logger.info("calling get-admin-config router ...")
    list_of_admin_configs = AdminConfigController().get_all_admin_config()
    return list_of_admin_configs
