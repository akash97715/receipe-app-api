from crud.v1.category_crud import CRUDCategory
from utils.logs.logger_config import logger

class CategoryController:
    def __init__(self):
        self.CRUDCategory = CRUDCategory()  


    def get_all_category(self):
        """[Controller to get all categories]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [list]: [list of all the categories in the system]
        """
        logger.info("executing get-all-category-controller ...")
        return self.CRUDCategory.read_all()


    def create_category(self, request):
        """[Controller to register new Category]

        Args:
            request ([dict]): [create new Category request]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [authorization details]
        """
        logger.info("executing create-category-controller ...")
        logger.info("calling get-by-name category function ...")
        category_obj = self.CRUDCategory.get_by_name(name=request.name.lower())
        if category_obj is not None:
            return category_obj
        category_request = {
                "name": request.name.lower()
            }
        return self.CRUDCategory.create(**category_request)
        
    def delete_category(self, id: int):
        """[Get Category Details]

        Args:
            Categoryname (str): [Categoryname of the Category]

        Returns:
            [dict]: [Category details]
         """
        logger.info("executing delete-category-controller ...")
        return self.CRUDCategory.delete(id = id)

    def get_categories_by_domains(self, domain_id: int, sub_domain_id: int):
        """[Controller to get list of categories for domain and sub domain name]

        Args:
            domain_id (int): [id of the domain]
            sub_domain_id (int): [id of the sub domain]

        Returns:
            [list]: [List of category names for specified domain and sub domain]
         """
        logger.info("executing get_categories_by_domains ...")
        
        category_ids = self.CRUDCategory.get_by_domains(domain_id, sub_domain_id)
        if category_ids is None:
            return []

        return [self.CRUDCategory.get_by_id(cat_id) for cat_id in category_ids]