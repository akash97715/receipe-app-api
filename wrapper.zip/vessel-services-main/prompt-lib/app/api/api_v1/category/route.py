from fastapi import APIRouter, Request
from api.dependencies.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

from config.load_config import config
from api.api_v1.category.controller import CategoryController
from schemas.v1.requests.DomainRequest import DomainRequest
from utils.logs.logger_config import logger
from api.api_v1.domain.controller import DomainController
from utils.exceptions import ResourceNotFound
from config.errors import get_err_json_response

category_router = APIRouter()


@category_router.post("/category", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_category(request: Request,
    create_category_request : DomainRequest
):
    """[API router to create new category into the system]
    Tags : [unused]
    Args:
        create_category_request (create): [New category details]

    Raises:
        error: [Exception details]

    Returns:
        [createResponse]: [create new category response]
    """
    logger.info("calling category/register router ...")
    category_obj = CategoryController().create_category(
        create_category_request
    )
    return category_obj


@category_router.get("/category", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_categories(request: Request):
    """[Get List of all categories]
    Tags : [unused]
    Raises:
        error: [Error details]

    Returns:
        [list]: [List of categories]
    """
    logger.info("calling get-categories router ...")
    list_of_categories = CategoryController().get_all_category()
    return list_of_categories


@category_router.get("/categories/{domain_name}/{sub_domain_name}", include_in_schema=True)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_categories_by_domains(
    request: Request,
    domain_name: str,
    sub_domain_name: str
):
    """[Get List of category names for specified domain and sub domain names]

    Args:
        domain_name (str): [Name of domain]
        sub_domain_name (str) : [Name of sub domain]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of category names]
    """
    try:
        logger.info("calling get-categories router ...")

        logger.info(" calling get by name domain controller ...")
        dom_obj = DomainController().CRUDDomain.get_by_name(name=domain_name.lower())

        if dom_obj is not None:
            dom_id = dom_obj["id"]
        else:
            logger.error("domain name not found.")
            raise ResourceNotFound("domain name not found.")

        logger.info(" calling get by name sub  domain controller ...")
        sub_dom_obj = DomainController().CRUDSubDomain.get_by_name(name=sub_domain_name.lower(), domain_id=dom_id)
        if sub_dom_obj is not None:
            sub_dom_id = sub_dom_obj["id"]
        else:
            logger.error("sub domain name not found.")
            raise ResourceNotFound("sub domain name not found.")
        
        list_of_categories = CategoryController().get_categories_by_domains(dom_id, sub_dom_id)
        return list_of_categories

    except ResourceNotFound as e:
            return get_err_json_response(
            "resource with given name not found.",
            e.args,
            404,
            )