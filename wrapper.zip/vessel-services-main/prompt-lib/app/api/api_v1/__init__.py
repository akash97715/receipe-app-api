from api.api_v1.domain.route import domain_router
from api.api_v1.admin_config.route import admin_config_router
from api.api_v1.category.route import category_router
from api.api_v1.prompt.route import prompt_router
from api.api_v1.user.route import user_detail_router

from fastapi import APIRouter

api_router = APIRouter()

api_router.include_router(admin_config_router, tags=["admin-config"])
api_router.include_router(prompt_router, tags=["prompt"])
api_router.include_router(user_detail_router, tags=["user"])

api_router.include_router(domain_router, tags=["domain"])
api_router.include_router(category_router, tags=["category"])