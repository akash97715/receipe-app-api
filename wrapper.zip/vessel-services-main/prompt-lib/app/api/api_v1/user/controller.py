from crud.v1.user_crud import CRUDUser
from crud.v1.group_crud import CRUDGroup
from utils.logs.logger_config import logger
from fastapi import HTTPException

class UserController:
    def __init__(self):
        self.CRUDUser = CRUDUser()
        self.CRUDGroup  = CRUDGroup()

    def get_all_user(self):
        """[Controller to get all users]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [list]: [list of all the  users in the system]
        """
        logger.info("executing get-all-user-controller ...")
        return self.CRUDUser.read_all()

    def create_user(self, request):
        """[Controller to register new user]

        Args:
            request ([dict]): [create new user request]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [user obj]
        """
        logger.info("executing create-user-controller ...")
        user = self.CRUDUser.get_by_name(user_name=request.user_name.lower())
        if user is not None:
            return {"status": "user already exists", "nt_id": user["nt_id"]}
        user_request = { "nt_id" : request.nt_id,
                        "user_name": request.user_name.lower(),
                        "user_type": request.user_type.lower(),
                        "group_id": request.group_id
                        }
        return self.CRUDUser.create(**user_request)

    def delete_user(self, id: int):
        """[Delete user details]

        Args:
            id (int): [user id]

        Returns:
            [dict]: [deleted user details]
        """
        logger.info("executing delete-user-controller ...")
        return self.CRUDUser.delete(id=id)
    
    # group controller functions:-

    def get_all_group(self):
        """[Controller to get all groups]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [list]: [list of all the  groups in the system]
        """
        logger.info("executing get-all-group-controller ...")
        return self.CRUDGroup.read_all()

    def create_group(self, group_name: str):
        """[Controller to register new group]

        Args:
            request ([dict]): [create new group request]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [authorization details]
        """
        logger.info("executing create-group-controller ...")
        check_duplicate = self.CRUDGroup.get_by_name(group_name = group_name)
        if check_duplicate:
            raise HTTPException(
                status_code=400,
                detail=f"Group name already exists with name {group_name} !"
            )
        group_request = {"group_name": group_name
                        }
        return self.CRUDGroup.create(**group_request)

    def delete_group(self, id: int):
        """[Delete group Details]

        Args:
            groupname (str): [groupname of the group]

        Returns:
            [dict]: [group details]
        """
        logger.info("executing delete-group-controller ...")
        return self.CRUDGroup.delete(id=id)

