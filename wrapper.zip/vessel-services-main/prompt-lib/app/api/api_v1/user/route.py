from fastapi import APIRouter, Request
from config.load_config import config
from api.api_v1.user.controller import UserController
from schemas.v1.requests.UserRequest import UserDetails
from utils.logs.logger_config import logger
from api.dependencies.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation


user_detail_router = APIRouter()


@user_detail_router.post("/user/register", include_in_schema=True)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_user(request: Request,create_user_request: UserDetails):
    """[API router to create new user into the system]
    
    Tags : [unused]
    Args:
        create_user_request (create): [New user details]

    Raises:
        error: [Exception details]

    Returns:
        [createResponse]: [create new user response]
    """
    logger.info("calling user register router ...")
    user_obj = UserController().create_user(create_user_request)
    return user_obj


@user_detail_router.get("/user", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_users(request: Request):
    """[Get List of all users]

    Tags : [unused]
    Raises:
        error: [Error details]

    Returns:
        [list]: [List of users]
    """
    logger.info("calling get-all-user router ...")
    list_of_users = UserController().get_all_user()
    return list_of_users

# group router ------------>

@user_detail_router.post("/group/register", include_in_schema=True)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_group(request: Request,group_name: str):
    """[API router to create new group into the system]

    Tags : [unused]
    Args:
        create_group_request (create): [New group details]

    Raises:
        error: [Exception details]

    Returns:
        [createResponse]: [create new group response]
    """
    logger.info("calling group register router ...")
    group_obj = UserController().create_group(group_name)
    return group_obj


@user_detail_router.get("/group-names")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_group_names(request: Request):
    """[Get List of all groups]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of groups]
    """
    logger.info("calling get-all-group-names router ...")
    list_of_groups = UserController().get_all_group()
    return list_of_groups

