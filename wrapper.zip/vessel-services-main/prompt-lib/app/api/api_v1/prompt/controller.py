from config.errors import get_err_json_response
from crud.v1.prompt_crud import CRUDPrompt
from crud.v1.approval_prompt_crud import CRUDApprovalPrompt
from utils.logs.logger_config import logger
from utils.exceptions import ResourceNotFound

class PromptController:
    def __init__(self):
        self.CRUDApprovalprompt = CRUDApprovalPrompt()
        self.CRUDprompt = CRUDPrompt()

    def get_all_approval_prompts(self):
        """[Controller to get all pending for approval prompts]"""
        logger.info("executing get-all-approval-prompts controller ...")
        return self.CRUDApprovalprompt.read_all()
    
    def get_all_prompts(self):
        """[Controller to get all approved prompts]"""
        logger.info("executing get-all-prompts controller ...")
        return self.CRUDprompt.read_all()
    
    def get_approval_prompt_by_id(self, approval_prompt_id):
        """[Controller to get pending for approval prompts by id]"""
        logger.info("executing get-approval-prompt-by-id controller ...")
        return self.CRUDApprovalprompt.read_by_id(approval_prompt_id)

    def get_prompt_by_id(self, prompt_id):
        """[Controller to get prompts by id]"""
        logger.info("executing get-prompt-by-id controller ...")
        return self.CRUDprompt.read_by_id(prompt_id)

    def add_approval_prompt(self, prompt):
        """[Adds incoming prompt to approval table]"""
        logger.info("executing add-approval-prompt controller ...")
        return self.CRUDApprovalprompt.create(prompt)

    def bulk_approve_prompt(self, approval_prompt_body):
        """[Approves/Reject prompt to approval table]"""
        logger.info("executing bulk-approve-prompts controller ...")
        return self.CRUDApprovalprompt.bulk_approve_prompt(approval_prompt_body)
    
    def update_ranking_prompt(self, prompt_body):
        """[Updates ranking of prompt ]"""
        try:
            logger.info("executing update-ranking-prompt controller ...")
            prompt_req_update_body = {
                "id" : prompt_body.prompt_id,
                "ranking_value" : prompt_body.ranking
            }
            app_prompt = self.CRUDApprovalprompt.update_ranking(**prompt_req_update_body)
            if app_prompt is None:
                logger.error("Error while updating user feeback in approval-prompts table.")
                raise ResourceNotFound()

            prompt =  self.CRUDprompt.update_ranking(**prompt_req_update_body)
            if prompt is None :
                logger.error("Error while updating user feeback in prompts table.")
                raise ResourceNotFound()
        
            return "User feedback is successfully updated!!"
        
        except ResourceNotFound as e:
            return get_err_json_response(
            "Prompt with given id does not exist.",
            e.args,
            404,
            )
        except Exception as e:
            logger.error("Error while updating user feeback in prompt controller.")
            return get_err_json_response(
            "Error while updating user feeback of a prompt.",
            e.args,
            501,
            )
    
    def get_filter_prompts(self, prompt_filter):
        logger.info("executing get-filter-prompts controller ...")
        return self.CRUDprompt.filter_prompt(prompt_filter)
        
    def get_prompts_by_groupid(self, nt_id):
        logger.info("executing get-prompts-by-groupid controller ...")
        return self.CRUDprompt.get_prompt_by_group_id(nt_id)
    
    def get_all_pending_prompts(self, domain = None, subdomain = None):
        logger.info("executing get-all-pending-prompts controller ...")
        return self.CRUDApprovalprompt.read_all_pending_prompts(domain, subdomain)
    
    def get_count_pending_prompts(self,nt_id):
        logger.info("executing get-count-pending-prompts controller ...")
        return self.CRUDApprovalprompt.get_count_pending_prompts_by_ntid(nt_id)