from typing import Optional
from fastapi import APIRouter, Request
from api.dependencies.validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

from api.api_v1.prompt.controller import (
    PromptController,
)
from config.load_config import config
from schemas.v1.requests.PromptSchema import Prompt
from schemas.v1.requests.PromptFilter import PromptFilter
from schemas.v1.requests.ApprovalPrompt import ApprovalPrompt
from schemas.v1.requests.UserFeedbackSchema import UserFeedbackSchema
from utils.logs.logger_config import logger

prompt_router = APIRouter()


@prompt_router.get("/approval-prompts", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_approval_prompts(request: Request):
    """
    API to get all pending for approval prompts

    Tags: [unused]

    Returns:
    [list of all approval prompts data]
    """
    logger.info("calling approval-prompts router ...")
    response = PromptController().get_all_approval_prompts()
    return response

@prompt_router.get("/prompt", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_approved_prompts(request: Request):
    """
    API to get all approved prompts

    Tags:[unused]

    Returns:
    [list of all approved-prompts]
    """
    logger.info("calling prompts router ...")
    response = PromptController().get_all_prompts()
    return response

@prompt_router.get("/prompt/{prompt_id}", include_in_schema=False)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_approval_prompt_by_id(request: Request,prompt_id: int):
    """
    API to get pending for approval prompt by id

    Tags: [unused]

    Returns:
    [dict : detail of a prompt with given id]
    """
    logger.info("calling promptsbyId router ...")
    response = PromptController().get_approval_prompt_by_id(prompt_id)
    return response

@prompt_router.post("/prompt")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def add_prompt(request: Request,prompt: Prompt):
    """
    API to add approval prompt

    Returns:
    [dict : success message]
    """
    logger.info("calling add-prompt router ...")
    response = PromptController().add_approval_prompt(prompt)
    return response

@prompt_router.get("/pending-prompts")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_pending_prompts(request: Request, domain: Optional[str] = None, subdomain: Optional[str] = None):
    """
    API to get all pending prompts 

    Returns:
    [list of all prompts with pending status]
    """
    logger.info("calling pending-prompts router ...")
    response = PromptController().get_all_pending_prompts(domain, subdomain)
    return response

@prompt_router.post("/prompt/approve")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def approve_prompts(request: Request,prompt_body: ApprovalPrompt):
    """
    API to bulk approve/reject pending prompts

    Returns:
    [list of approved/ rejected message]
    """
    logger.info("calling bulk-approve-prompt router ...")
    response = PromptController().bulk_approve_prompt(prompt_body)
    return response

@prompt_router.put("/prompt/user-feedback")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def update_prompt_ranking(request: Request,prompt_body: UserFeedbackSchema):
    """
    API to update prompt ranking

    Returns:
    [str: success message]
    """
    logger.info("calling update-user-feedback router ...")
    response = PromptController().update_ranking_prompt(prompt_body)
    return response

@prompt_router.post("/prompt/lookup")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_filtered_prompts(request: Request,prompt_filter: PromptFilter):
    """
    API to get filtered prompts 

    Returns:
    [list of filtered data ]
    """
    logger.info("calling get-filtered-prompts router ...")
    response = PromptController().get_filter_prompts(prompt_filter)
    return response

@prompt_router.get("/prompts/{nt_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_prompts_by_groupid_for_ntid(request: Request,nt_id: str):
    """
    API to get all prompts under group_id which is associated with nt_id

    Returns:
    [list of all prompts with same group id]
    """
    logger.info("calling get-prompts-by-group-id router ...")
    response = PromptController().get_prompts_by_groupid(nt_id)
    return response

@prompt_router.get("/prompt/count/{nt_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_count_prompts_by_groupid_for_ntid(request: Request,nt_id: str):
    """
    API to get count of all pending prompts under nt_id

    Returns:
    [DICT: count value]
    """
    logger.info("calling get-count_pending_prompts router ...")
    response = PromptController().get_count_pending_prompts(nt_id)
    return response
