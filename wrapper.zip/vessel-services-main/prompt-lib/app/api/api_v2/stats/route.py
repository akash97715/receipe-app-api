
from api.api_v2.stats.controller import StatsController
from fastapi import APIRouter,Request
from utils.api_response import generate_api_success_response
from utils.logs.logger_config import logger
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

stats_router = APIRouter()


@stats_router.get("/stats")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def get_stats(
    request:Request
):
    try:
        logger.info("In get stats route..")
        user_info =  request.state.userInfo

        count = StatsController().get_stats(
            user_info
        )
        return generate_api_success_response(body=count)
    except Exception as e:
        raise e

