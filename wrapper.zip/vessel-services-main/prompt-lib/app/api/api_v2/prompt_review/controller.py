from config.errors import get_err_json_response
from utils.logs.logger_config import logger
from utils.exceptions import ResourceNotFound
from crud.v2.prompt_crud import CRUDPrompt
from crud.v2.prompt_review_crud import CRUDPromptReviewLog


class PromptReviewController:
    def __init__(self):
        self.CRUDprompt = CRUDPrompt()
        self.CRUDPromptReviewLog = CRUDPromptReviewLog()



    def get_review_log_by_prompt_id(self, prompt_id, version):
        """[Get review log by prompt id from prompt table]"""
        logger.info("executing get-review-log controller ...")
        return self.CRUDPromptReviewLog.read_by_prompt_id(prompt_id, version)