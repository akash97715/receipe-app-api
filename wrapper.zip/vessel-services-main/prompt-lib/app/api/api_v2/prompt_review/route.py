from typing import Optional
from fastapi import APIRouter, Request
from api.api_v2.prompt_review.controller import PromptReviewController

from config.load_config import config
from utils.logs.logger_config import logger
from utils.api_response import *
from api.api_v2.prompt_review.controller import PromptReviewController
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

prompt_review_router = APIRouter()

@prompt_review_router.get("/prompts/{prompt_id}/reviews")
@async_token_validation_and_metering(uom=4) 
@auth_token_validation() 
async def get_review_log_by_prompt_id(request:Request, prompt_id: str, version: int = None):
    """
    API to get review logs of a prompt by prompt id

    Returns:
    [dict : detail of a promptreviewlog with given prompt id]
    """
    
    logger.info("calling get_review_log_by_prompt_id router ...")
    review_logs = PromptReviewController().get_review_log_by_prompt_id(prompt_id, version)
    response = {"review_logs":review_logs}
    return generate_api_success_response(body=response)
