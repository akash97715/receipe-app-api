
from api.api_v2.prompt.route import prompt_router
from api.api_v2.prompt_review.route import prompt_review_router
from api.api_v2.prompt_share.route import prompt_sharing_router
from api.api_v2.static_data.route import static_data_router
from api.api_v2.stats.route import stats_router

from fastapi import APIRouter

api_router_v2 = APIRouter()

api_router_v2.include_router(prompt_router, tags=["Prompts Service v2"])
api_router_v2.include_router(prompt_sharing_router, tags=["Prompts Sharing v2"])
api_router_v2.include_router(prompt_review_router,tags=["Prompts Review Logs v2"])
api_router_v2.include_router(static_data_router,tags=["Static Data v2"])
api_router_v2.include_router(stats_router,tags=["Prompts Stats v2"])

