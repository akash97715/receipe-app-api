import json
from typing import Optional

from api.api_v2.prompt.controller import PromptController
from api.api_v2.prompt_share.controller import PromptShareController
from db.orm_models.v2.enums import Order_By, Search_on, Sort_By, Status, Fetch_Status, Search_Logic
from fastapi import APIRouter, HTTPException,Request
from schemas.v2.requests.PromptRequest import CreatePrompt, PromptReviewAction, UpdatePrompt
from utils.api_response import generate_api_success_response
from utils.logs.logger_config import logger


from config.load_config import config
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

prompt_router = APIRouter()


@prompt_router.post("/prompt")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def create_prompt(request:Request,prompt: CreatePrompt, is_pre_approved: bool = True):
    """
    API to create_prompt

    Returns:
    [dict : success message]
    """
    try:
        user_info =  request.state.userInfo
        logger.info("Starting Create Prompt operation ...")
        response = PromptController().create_prompt(prompt, is_pre_approved,user_info)
        return generate_api_success_response(body=response)
    except Exception as e :
        logger.error(f"Error in create prompt {e}")
        raise e


@prompt_router.get("/prompt/{prompt_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def get_prompt_by_id(request:Request,prompt_id: str, version: int = None):
    """
    API to get prompt by id

    Tags: [unused]

    Returns:
    [dict : detail of a prompt with given id]
    """
    try:
        user_info =  request.state.userInfo
        logger.info("calling get_prompt_by_id router ...")
        if not version:
            version = None
        response = PromptController().get_prompt_by_id(user_info, prompt_id, version)

        return generate_api_success_response(body=response)
    except Exception as e :
        logger.error(f"Error in get prompt {e}")
        raise e


@prompt_router.delete("/prompt/{prompt_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def delete_prompt_by_id(request:Request,prompt_id: str, version: int = None):
    """
    API to get prompt by id

    Tags: [unused]

    Returns:
    [dict : detail of a prompt with given id]
    """
    try:
        user_info =  request.state.userInfo

        
        logger.info("calling delete_prompt_by_id router ...")
        if not version:
            version = None
        id = PromptController().delete_prompt_by_id(prompt_id, user_info,version)
        response = {"id": id}
        return generate_api_success_response(body=response)
    except Exception as e :
        logger.error(f"Error in delete prompt {e}")
        raise e


@prompt_router.get("/prompts")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def fetch_multiple_prompts(
    request:Request,
    id: str = None,
    status: Fetch_Status = None,
    created_by: str = None,
    is_private: bool =None,
    is_visible: bool = None,
    with_review_details: bool =  False,
    page_limit: int = None,
    page_number: int = 1,
    sort_by: Sort_By = Sort_By.MODIFIED_AT,
    sort_order: Order_By = Order_By.DESC,
):
    """
    API to fetch multiple prompts with or without pagination.

    Raises:
    error: [Error returned from the router layer]

    Returns:
    [list : details of prompts]
    """
    user_info =  request.state.userInfo

    logger.info("calling fetch_multiple_prompts router ...")
    
    if page_number >= 1:
        if page_number > 1 and page_limit is None:
            logger.error("Page limit is also required with page number.")
            raise HTTPException(
                status_code=400, detail="Page limit is also required with page number."
            )
        elif page_limit is not None and page_limit <=0:
            logger.error("Page limit cannot be less than 1.")
            raise HTTPException(
                status_code=400, detail="Page limit cannot be less than 1."
            )
        
    elif page_number < 1:
        logger.error("Page number cannot be less than 1.")
        raise HTTPException(
            status_code=400, detail="Page number cannot be less than 1."
        )

    response = PromptController().get_multiple_prompts(
        user_info,
        id,
        status,
        created_by,
        is_private,
        is_visible,
        with_review_details,
        page_limit,
        page_number,
        sort_by.value,
        sort_order,
    )

    return generate_api_success_response(body=response)


@prompt_router.get("/prompts/search/text")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def search_prompts(
    request:Request,
    search_text: str,
    is_private: bool =None,
    search_on: Search_on = Search_on.ALL,
    search_tags: str = None,
    search_logic: Search_Logic = Search_Logic.AND,
    created_by: str = None,
    is_visible: bool = None,
    page_limit: int = 5,
    page_number: int = 1,
    sort_by: Sort_By = Sort_By.MODIFIED_AT,
    sort_order: Order_By = Order_By.ASC,
):
    try:
        user_info =  request.state.userInfo

        if page_number >= 1:
            if page_number > 1 and page_limit is None:
                logger.error("Page limit is also required with page number.")
                raise HTTPException(
                    status_code=400, detail="Page limit is also required with page number."
                )
            elif page_limit is not None and page_limit <=0 and page_limit != -1:
                logger.error("Page limit cannot be 0 or less than -1.")
                raise HTTPException(
                    status_code=400, detail="Page limit cannot be 0 or less than -1."
                )
        
        elif page_number < 1:
            logger.error("Page number cannot be less than 1.")
            raise HTTPException(
                status_code=400, detail="Page number cannot be less than 1."
            )

        paginated_results = PromptController().search_prompt_by_text_controller(
            user_info,
            search_text,
            search_on.value,
            search_tags,
            search_logic.value,
            created_by,
            is_private,
            is_visible,
            sort_by.value,
            sort_order.value,
            page_number,
            page_limit,
        )
        return generate_api_success_response(body=paginated_results)
    except Exception as e:
        raise e


@prompt_router.put("/prompt/{prompt_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def update_prompt_by_id(request:Request,
    prompt_id: str, prompt: UpdatePrompt, is_pre_approved: bool = True
):
    """
    API to update prompt by id

    Tags: [unused]

    Returns:
    [dict : detail of a prompt with given id]
    """
    try:
        user_info =  request.state.userInfo
        logger.info("calling update_prompt_by_id router ...")
        db_prompt = prompt.__dict__

        if not isinstance(db_prompt["metadata_info"],dict):
            metadata_info = db_prompt["metadata_info"].__dict__
            db_prompt["metadata_info"] = metadata_info

        id = PromptController().update_prompt_by_id(prompt_id, db_prompt, is_pre_approved,user_info)
        response = {"id": id}
        return generate_api_success_response(body=response)
    except Exception as e :
        logger.error(f"Error in update prompt {e}")
        raise e


@prompt_router.patch("/prompt/{id}/visibility/{is_visible}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def visibility_toggle(request:Request,id: str, is_visible: bool = True):
    """
    API to change the visibility of an approved-prompt
    Returns:
    [dict : success message]
    """
    user_info =  request.state.userInfo
    
    logger.info("calling visbility-toggle router ...")

    id = PromptController().visibility_toggle(id=id,user_info=user_info, is_visible=is_visible)

    response = {"id": id, "message": f"Visibility switched to {is_visible}"}

    return generate_api_success_response(status_code=200, body=response)


@prompt_router.put("/prompt/{id}/action")
@async_token_validation_and_metering(uom=4)
@auth_token_validation() 
async def prompt_action(request:Request,id: str, action: PromptReviewAction):
    """
    API to change prompt status
    Returns:
    [dict : success message]
    """
    user_info =  request.state.userInfo
    
    logger.info("calling visbility-toggle router ...")
    logger.info("calling prompt-action router ...")

    id = PromptController().prompt_action(
        id=id, status=action.review_status, comment=action.review_comment,user_info=user_info
    )

    response = {"id": id, "message": f"Status changed to {action.review_status.value}"}

    return generate_api_success_response(body=response)