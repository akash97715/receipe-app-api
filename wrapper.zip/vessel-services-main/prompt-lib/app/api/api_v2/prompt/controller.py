from crud.v2.prompt_crud import CRUDPrompt
from crud.v2.prompt_review_crud import CRUDPromptReviewLog
from crud.v2.prompt_share_crud import CRUDPromptShareMap
from db.orm_models.v2.enums import Status
from fastapi import HTTPException
from utils.logs.logger_config import logger
from api.api_v2.prompt_share.controller import PromptShareController 


class PromptController:
    def __init__(self):
        self.CRUDprompt = CRUDPrompt()
        self.CRUDPromptReviewLog = CRUDPromptReviewLog()
        self.CRUDPrompShareMap = CRUDPromptShareMap()

    def get_review_prompt_obj(self, prompt_id, db_prompt, message=""):
        return {
            "prompt_id": prompt_id,
            "prompt_version": db_prompt["version"],
            "review_status": db_prompt["status"],
            "review_comment": message,
            "created_by": db_prompt["created_by"],
            "modified_by": db_prompt["modified_by"],
        }
    
    
    def duplicate_check(self, prompt):
        is_duplicate = self.CRUDprompt.duplicate_check(prompt_name=prompt["name"])

        if is_duplicate:
            message = "Prompt with same name exists. Please use a unique name."
            raise HTTPException(status_code=400, detail=message)
                

    def create_prompt(self, prompt, is_pre_approved, user_info):
        """[Adds incoming prompt to prompt table]"""
        logger.info("executing add-prompt controller ...")

        prompt = prompt.dict()
        is_private = True
        if len(prompt["sharing_details"]) > 0:
            is_private = False
        db_prompt = {
            "version": 1,
            "name": prompt["name"],
            "prompt": prompt["prompt"],
            "system_prompt": prompt["system_prompt"],
            "metadata_info": prompt["metadata_info"],
            "tags": prompt["tags"],
            "status": Status.PENDING.value,
            "is_visible": prompt["is_visible"],
            "creator_tenant_id": user_info["mule_client_id"],
            "created_by": user_info["Username"],
            "modified_by": user_info["Username"],
            "is_private": is_private
        }

        self.duplicate_check(prompt)

        db_prompt_obj = self.CRUDprompt.create(**db_prompt)
        if db_prompt_obj["id"]:
            prompt_id = db_prompt_obj["id"]
        

        if db_prompt_obj is not None:
            review_prompt = self.get_review_prompt_obj(prompt_id, db_prompt, "Prompt created.")
            review_prompt = self.CRUDPromptReviewLog.create(**review_prompt)
            logger.info(f"Created a new Review prompt record : {review_prompt}")

        if is_pre_approved:
            db_prompt["status"] = Status.APPROVED.value
            db_prompt_res = self.CRUDprompt.update(
                db_prompt=db_prompt, prompt_id=prompt_id
            )

            if db_prompt_res is not None:
                review_prompt_update = self.get_review_prompt_obj(prompt_id, db_prompt, "Status changed to APPROVED. Reviewer comment: Prompt is pre-approved.")
                review_prompt_update = self.CRUDPromptReviewLog.create(
                    **review_prompt_update
                )
                logger.info(
                    f"Created a new Review prompt record: {review_prompt_update}"
                )


        response = {"id": prompt_id}
        if is_private is False:
            #create share mappings
            mapping_ids = PromptShareController().create_prompt_share_map(prompt_id, prompt["sharing_details"], user_info)
            response["mapping_ids"] = mapping_ids     
                    
        return response

    def get_prompt_by_id(self, user_info, prompt_id, version):
        """[Gets prompt by id from prompt table]"""
        logger.info("executing get-prompt controller ...")
        return self.CRUDprompt.read_by_id(user_info, prompt_id, version)

    def delete_prompt_by_id(self, prompt_id,user_info, version = None):
        """[Gets prompt by id from prompt table]"""
        logger.info("executing delete-prompt controller ...")
        db_prompt = self.CRUDprompt.read_by_id_status(user_info, prompt_id, version)

        if db_prompt is None or db_prompt["status"] == Status.DELETED:
            raise HTTPException(status_code=400, detail="Prompt id does not exist.")
        
        if "_sa_instance_state" in db_prompt:
            db_prompt.pop("_sa_instance_state")
        
        db_prompt["status"] = Status.DELETED.value
        db_prompt["modified_by"] = user_info["Username"]
        update_obj = self.CRUDprompt.update_cols(
            db_prompt["id"], 
            db_prompt["version"], 
            status = Status.DELETED, 
            modified_by = user_info["Username"],
        )

        if update_obj is not None:
            review_prompt = self.get_review_prompt_obj(prompt_id, db_prompt, "Prompt deleted.")
            review_prompt = self.CRUDPromptReviewLog.create(**review_prompt)
            logger.info(
                f"Created a new Review prompt record for delete: {review_prompt}"
            )

        latest_prompt = self.CRUDprompt.read_by_id_status(user_info, prompt_id)

        if latest_prompt is None:
            logger.info("Deleting share mapping for the prompt ...")
            self.CRUDPrompShareMap.update_delete_status(prompt_id, user_info)
            
        return prompt_id

    def get_multiple_prompts(
        self,
        user_info,
        id,
        status,
        created_by,
        is_private,
        is_visible,
        with_review_details,
        page_limit,
        page_number,
        sort_by,
        sort_order,
    ):
        """[Gets prompts from prompt table]

        Args:
            prompt id (str): [prompt id to filter the record]

        Raises:
            error: [Error returned from controller layer]

        Returns:
            [list]: [all prompt records]
        """
        logger.info("executing get-multiple-prompts controller ...")
        prompts, total_count = self.CRUDprompt.get_prompts(
            user_info = user_info, # Tenant ID of the user
            input_id=id,  # User input for ID
            input_created_by=created_by,  # User input for created_by
            input_is_private = is_private,
            input_is_visible=is_visible,  # User input for is_visible
            input_status=status,  # User input for status
            limit=page_limit,  # User input for pagination limit
            offset=page_number,  # User input for pagination offset
            order_by=sort_by,  # User input for column to order by
            sort_by=sort_order,  # User input for sorting direction (ASC or DESC)
            input_with_review_results=with_review_details,
        )

        if page_limit is None:
            page_limit = total_count
        if page_number is None:
            page_number = 0

        return {
            "prompts": prompts,
            "page_number": page_number,
            "page_limit": page_limit,
            "total_count": total_count,
        }

    def search_prompt_by_text_controller(
        self,
        user_info,
        search_text,
        search_on,
        search_tags,
        search_logic,
        created_by,
        is_private,
        is_visible,
        sort_by,
        sort_order,
        page_number,
        page_limit,
    ):
        """[Gets prompts by text from prompt table]"""
        logger.info("executing search-prompt-by-text controller ...")
        if search_tags is not None:
            search_tags = search_tags.strip(' ,')
            if(len(search_tags)==0):
                search_tags = None
            else:
                search_tags = list(filter(None,search_tags.split(',')))

        prompts = self.CRUDprompt.get_prompts_by_text(
            user_info,
            search_text,
            search_on,
            search_tags,
            search_logic,
            created_by,
            is_private,
            is_visible,
            sort_by,
            sort_order,
            page_number,
            page_limit,
        )
        return prompts

    def visibility_toggle(self, id,user_info, is_visible: bool = True):
        """[Toggles visibility of an approved prompt]"""

        logger.info("executing prompt-visibility controller ...")

        prompt = self.CRUDprompt.read_by_id_status(user_info, id)

        if prompt is None:
            raise HTTPException(status_code=400, detail="Prompt id does not exist.")

        if prompt["status"] != Status.APPROVED:
            message = "cannot change visibility of non-approved prompts"

            raise HTTPException(status_code=400, detail=message)

        if "_sa_instance_state" in prompt:
            prompt.pop("_sa_instance_state")

        update_obj = self.CRUDprompt.update_cols(
            prompt["id"], 
            prompt["version"], 
            is_visible= is_visible, 
            modified_by = user_info["Username"],
            )

        return id

    def prompt_action(self, id, status: Status, comment: str,user_info):
        """[Changes status of a prompt]"""

        logger.info("executing add-prompt controller ...")

        prompt = self.CRUDprompt.read_by_id(user_info, id)
        
        latest_approved = None
        
        if status == Status.APPROVED:
            latest_approved = self.CRUDprompt.read_by_id_status(user_info, id)

        if prompt is None:
            raise HTTPException(status_code=400, detail="Prompt id does not exist.")

        if status == Status.DELETED:
            raise HTTPException(status_code=400, detail="You can not delete a prompt!")

        if prompt["status"] == status:
            message = f"Status for this prompt is already set to '{status.value}'"

            raise HTTPException(status_code=400, detail=message)

        elif (
            prompt["status"] == Status.PENDING
            or prompt["status"] == Status.CHANGES_REQUESTED
        ):
            if "_sa_instance_state" in prompt:
                prompt.pop("_sa_instance_state")

            prompt["status"] = status
            update_obj = self.CRUDprompt.update_cols(
                prompt["id"], 
                prompt["version"], 
                status= prompt["status"], 
                modified_by = user_info["Username"],
                )

            if update_obj is not None:
                review_prompt = self.get_review_prompt_obj(
                    id, prompt, f"Status changed to {status.value}. Reviewer comment: {comment}"
                )
                review_prompt = self.CRUDPromptReviewLog.create(**review_prompt)
                logger.info(
                    f"Created a new Review prompt record for Status change: {review_prompt}"
                )
            
            if latest_approved is not None:
                self.delete_prompt_by_id(
                    prompt_id = latest_approved['id'], 
                    version = latest_approved["version"], 
                    user_info= user_info,
                )

        else:
            message = "Status can only be changed for prompts in 'PENDING' OR 'CHANGES_REQUESTED' state."

            raise HTTPException(status_code=400, detail=message)

        return id

    def add_to_review_table(self, prompt_id, db_prompt,user_info):
        review_prompt_update = self.get_review_prompt_obj(prompt_id, db_prompt, "Prompt updated.")
        review_prompt_update = self.CRUDPromptReviewLog.create(**review_prompt_update)
        return review_prompt_update

    def update_record(self, prompt_id, db_prompt, status,user_info):
        db_prompt["status"] = status
        if "_sa_instance_state" in db_prompt:
            db_prompt.pop("_sa_instance_state")

        db_prompt_res = self.CRUDprompt.update_cols(**db_prompt)

        if db_prompt_res is not None:
            review_prompt_update = self.add_to_review_table(
                prompt_id=prompt_id, db_prompt=db_prompt,user_info=user_info
            )
            logger.info(f"Created a new Review prompt record : {review_prompt_update}")

    def create_prompt_obj(self, prompt_id, prompt_obj, status, version, user_info):
        return {
            "id": prompt_id,
            "version": version,
            "name": prompt_obj["name"],
            "prompt": prompt_obj["prompt"],
            "system_prompt": prompt_obj["system_prompt"],
            "metadata_info": prompt_obj["metadata_info"],
            "tags": prompt_obj["tags"],
            "status": status,
            "is_visible": prompt_obj["is_visible"],
            "creator_tenant_id": user_info["mule_client_id"],
            "created_by": prompt_obj["created_by"],
            "modified_by": user_info["Username"],
            "is_private": prompt_obj["is_private"]
        }

    def update_prompt_by_id(self, prompt_id, prompt_obj, is_pre_approved,user_info):
        """[Gets prompt by id from prompt table]"""
        logger.info("executing update-prompt controller ...")

        has_access = self.CRUDprompt.check_user_access_to_prompt(user_info, prompt_id)
        if has_access is not True:
            raise HTTPException(status_code=403, detail="User does not have access to this prompt!") 
        
        latest_prompt = self.CRUDprompt.read_by_id(user_info, prompt_id)
        if len(latest_prompt) == 0:
            raise HTTPException(status_code = 400, detail="Prompt id does not exist.")
        
        can_change_status_flag = False
        
        if (
            latest_prompt["status"].value == Status.PENDING.value
            or latest_prompt["status"].value == Status.CHANGES_REQUESTED.value
        ):
            can_change_status_flag = True
        
        prompt_obj["is_private"] = latest_prompt["is_private"]    
        prompt_obj["created_by"] = latest_prompt["created_by"]
        
        if prompt_obj['name'].lower() != latest_prompt['name'].lower():
            self.duplicate_check(prompt_obj)

        if can_change_status_flag:
            
            db_prompt_obj = self.create_prompt_obj(
                prompt_id=prompt_id,
                prompt_obj=prompt_obj,
                status=Status.PENDING.value,
                version=latest_prompt["version"],
                user_info=user_info
            )

            self.update_record(
                prompt_id=prompt_id,
                db_prompt=db_prompt_obj,
                status=Status.PENDING.value,
                user_info=user_info
            )

        else:
            db_prompt = self.create_prompt_obj(
                prompt_id=prompt_id,
                prompt_obj=prompt_obj,
                status=Status.PENDING.value,
                version=latest_prompt["version"] + 1,
                user_info=user_info

            )

            db_obj = self.CRUDprompt.create(**db_prompt)
            if db_obj:
                review_prompt = self.get_review_prompt_obj(prompt_id, db_prompt, "New version created.")
                review_prompt = self.CRUDPromptReviewLog.create(**review_prompt)
                logger.info(
                    f"Created a new Review prompt record for create : {review_prompt}"
                )

        if is_pre_approved:
            self.prompt_action(prompt_id, Status.APPROVED, "updated prompt is pre-approved.", user_info)

        return prompt_id
