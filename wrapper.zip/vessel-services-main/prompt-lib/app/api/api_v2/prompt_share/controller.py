from utils.logs.logger_config import logger
from crud.v2.prompt_share_crud import CRUDPromptShareMap
from crud.v2.prompt_crud import CRUDPrompt
from crud.v2.prompt_review_crud import CRUDPromptReviewLog
from db.orm_models.v2.enums import Shared_with_type, Status
from fastapi import HTTPException


class PromptShareController:
    def __init__(self):
        self.CRUDPromptShareMap = CRUDPromptShareMap()
        self.CRUDPrompt = CRUDPrompt()
        self.CRUDPromptReviewLog = CRUDPromptReviewLog()
        

    def create_prompt_share_map(self, id, sharing_details,user_info):
        """[create a prompt share map]"""

        logger.info("executing create-prompt-share-map controller ...")
        
        latest_prompt = self.CRUDPrompt.read_by_id(user_info,id)
        latest_approved = self.CRUDPrompt.read_by_id_status(user_info, id)

        if latest_approved is None:
            if len(latest_prompt) == 0:
                raise HTTPException(status_code=400, detail="The given prompt id doesn't exist.")

            elif latest_prompt['status'] == Status.DELETED or latest_prompt["status"] == Status.REJECTED:
                raise HTTPException(status_code=400, detail="The given prompt has been rejected/deleted.")

        else:
            latest_prompt = latest_approved


        latest_prompt["is_private"] = False
        latest_prompt["modified_by"] = user_info["Username"]

        mapping_id_list = []

        for sharing_detail in sharing_details:
            if not isinstance(sharing_detail, dict):
                sharing_detail = sharing_detail.dict()
            
            #check for default tenant id
            if sharing_detail["shared_with_type"] == Shared_with_type.TENANT and sharing_detail["shared_with_id"] in [None,'']:
                sharing_detail["shared_with_id"] = user_info["mule_client_id"]

            duplicate_check = self.CRUDPromptShareMap.duplicate_check(prompt_id = id,
                                                                      shared_with_type = sharing_detail["shared_with_type"],
                                                                      shared_with_id = sharing_detail['shared_with_id'])
            
            if(duplicate_check):
                mapping_id_list.append(str(duplicate_check["id"]))
                continue
            
            db_prompt = {
                "prompt_id": id,
                "shared_with_type": sharing_detail["shared_with_type"],
                "shared_with_id": sharing_detail["shared_with_id"],
                "is_deleted": False,
                "created_by": user_info["Username"],
                "modified_by": user_info["Username"],
            }

            obj = self.CRUDPromptShareMap.create(**db_prompt)
            mapping_id_list.append(str(obj["id"]))
        
        if "_sa_instance_state" in latest_prompt:
            latest_prompt.pop("_sa_instance_state")

        #update is_private for all the versions.
        update_obj = self.CRUDPrompt.update_privacy(
            latest_prompt["id"], 
            latest_prompt['is_private'], 
            latest_prompt["modified_by"],
        )

        return mapping_id_list

    def get_by_id_sharetype(self,user_info, prompt_id: str, shared_with_type: Shared_with_type = None):
        """[Gets prompt share mapping by id and shared_with_type]"""

        logger.info("executing get-sharing-details controller ...")

        check = self.CRUDPrompt.check_user_access_to_prompt(user_info, prompt_id)
        
        if check == False:
            raise HTTPException( status_code= 400, detail ="User does not have access to the prompt.")
        
        response = self.CRUDPromptShareMap.read_by_id_sharetype( prompt_id, shared_with_type)

        if len(response) == 0:
            raise HTTPException(
                status_code=400,
                detail="There are no records present with the specified parameters.",
            ) 

        return response

    def delete_by_share_id_type(
        self, prompt_id: str, user_info,  shared_with_type: Shared_with_type = None, shared_with_id: str = None
    ):
        """[Deletes prompt share mapping by id and shared_with_type/share_with_id]"""

        logger.info("executing delete-sharing-details controller ...")
        
        if shared_with_type is None and shared_with_id is not None: 
            raise HTTPException(status_code=400, detail="Shared_with_type must be passed along with shared_with_id")
        
        mappings = self.get_by_id_sharetype(user_info, prompt_id, shared_with_type)

        
        if len(mappings) != 0:
            no_of_maps =  self.CRUDPromptShareMap.update_delete_status(prompt_id, user_info,shared_with_type, shared_with_id)

        else:
            raise HTTPException(
                status_code=400,
                detail="There are no records present with the specified parameters.",
            )
        
        response = self.CRUDPromptShareMap.read_by_id_sharetype(prompt_id, shared_with_type)

        if len(response) == 0:
            logger.info("calling update crud for prompt ..")
            update_obj = self.CRUDPrompt.update_privacy(prompt_id, True, user_info["Username"])

        return no_of_maps
