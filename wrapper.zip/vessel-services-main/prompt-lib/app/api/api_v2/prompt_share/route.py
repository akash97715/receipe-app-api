from typing import Optional
from fastapi import APIRouter, Request,HTTPException
from schemas.v2.requests.PromptSharingRequests import BasicPromptSharingDetails
from db.orm_models.v2.enums import Shared_with_type
from api.api_v2.prompt_share.controller import PromptShareController

from config.load_config import config
from utils.logs.logger_config import logger
from utils.api_response import *
from typing import List
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

prompt_sharing_router = APIRouter()

@prompt_sharing_router.post("/prompt/{id}/share")
@async_token_validation_and_metering(uom=4) 
@auth_token_validation() 
async def create_prompt_share_map(request:Request,id: str, sharing_details: List[BasicPromptSharingDetails]):
    """
    API to create sharing details for a prompt 

    Returns:
    [list : ids of the mappings created]
    """
    logger.info("calling create-prompt-share-mapping router ...")
    user_info =  request.state.userInfo
    response = PromptShareController().create_prompt_share_map(id, sharing_details,user_info)

        
    return generate_api_success_response(body= {"id": response})


@prompt_sharing_router.get("/prompt/{id}/share")
@async_token_validation_and_metering(uom=4) 
@auth_token_validation() 
async def get_prompt_by_id(request:Request,id: str, shared_with_type: Shared_with_type = None):
    """
    API to get sharing details for a prompt 

    Returns:
    [dict : sharing details of a prompt with given id]
    """
    logger.info("calling get-prompt-sharing-details router ...")
    
    user_info =  request.state.userInfo

    response = PromptShareController().get_by_id_sharetype(user_info, id, shared_with_type)
        
    return generate_api_success_response(body=response)


@prompt_sharing_router.delete("/prompt/{id}/share")
@async_token_validation_and_metering(uom=4) 
@auth_token_validation() 
async def delete_prompt_by_id(request:Request, id: str, shared_with_type: Shared_with_type = None, shared_with_id: str = None):
    """
    API to delete  prompt share mapping  

    Returns:
    [dict : ids of the mappings deleted]
    """
    logger.info("calling delete-prompt-share-mapping router ...")
    user_info =  request.state.userInfo
    
    response = PromptShareController().delete_by_share_id_type(id,user_info, shared_with_type, shared_with_id )
        
    return generate_api_success_response(message= f"{response} mappings deleted.")