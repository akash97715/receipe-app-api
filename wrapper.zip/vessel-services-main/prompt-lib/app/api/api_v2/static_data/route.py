from typing import Optional
from fastapi import APIRouter, Request
from config.load_config import config
from utils.logs.logger_config import logger
from utils.api_response import *
from api.api_v2.static_data.controller import StaticDataController
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from schemas.v2.requests.StaticDataRequest import StaticDataRequest

static_data_router = APIRouter()

@static_data_router.post("/static_data")
@async_token_validation_and_metering(uom=4) 
@auth_token_validation() 
async def create_static_data(request:Request, static_info: StaticDataRequest):
    """
    API to create_static_data

    Returns:
    success
    """
    logger.info("calling create_static_data router ...")
    response = StaticDataController().create_static_data(static_info)
    return generate_api_success_response(message="Entry created successfully.",body= response)


@static_data_router.get("/static_data/{id}")
@async_token_validation_and_metering(uom=4) 
@auth_token_validation() 
async def get_static_data(request:Request, id: str):
    """
    API to get static data created

    Returns:
    [dict : data of the given id]
    """
    
    logger.info("calling get_static_data router ...")
    raw_data = StaticDataController().get_static_data(id)
    return generate_api_success_response(message="Static Information details.",body=raw_data)
