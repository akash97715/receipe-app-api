from config.errors import get_err_json_response
from utils.logs.logger_config import logger
from utils.exceptions import ResourceNotFound
from crud.v2.static_data_crud import CRUDStaticData


class StaticDataController:
    def __init__(self):
        self.CRUDStaticData = CRUDStaticData()

    def create_static_data(self, static_info):
        """[Adds incoming static info to static data table]"""
        try:
            logger.info("executing create static info controller ...")
            data = {
                "id":static_info.id.upper(),
                "name": static_info.name.upper(),
                "raw_data": static_info.raw_data
            }
            return self.CRUDStaticData.create(**data)
        except Exception as e:
            raise e

    def get_static_data(self, id):
        """[Get raw data by id from static data table]"""
        try:
            logger.info("executing get_static_data controller ...")
            return self.CRUDStaticData.get_by_id(id)
        except Exception as e:
            raise e
