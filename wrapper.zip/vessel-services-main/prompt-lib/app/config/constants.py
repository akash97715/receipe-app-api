ADMIN_CONFIG_LIST = ["domain", "subdomain", "category"]
