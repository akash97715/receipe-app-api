from db.session import acquire_db_session as session
from db.orm_models.v2.prompts_review_log import PromptsReviewLog
from config.errors import get_err_json_response
from utils.logs.logger_config import logger
from sqlalchemy import desc


class CRUDPromptReviewLog:
    def create(self, **kwargs):
        """[CRUD function to create a new User record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-PromptsReview crud ...")
            obj = PromptsReviewLog(**kwargs)
            with session() as transaction_session:
                transaction_session.add(obj)
                transaction_session.commit()
                transaction_session.refresh(obj)
            return obj.__dict__

        except Exception as e:
            logger.error("Error while adding to PromptsReview table")
            return get_err_json_response(
                "Error while adding to PromptsReview table",
                e.args,
                501,
            )

    def read_all(self):
        """[CRUD function to read_all Users record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all user records]
        """
        try:
            logger.info("executing read-all-PromptsReview crud ...")
            with session() as transaction_session:
                obj: PromptsReviewLog = transaction_session.query(
                    PromptsReviewLog
                ).all()
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []

        except Exception as e:
            logger.error("Error while getting data from PromptsReview table")
            return get_err_json_response(
                "Error while getting data from PromptsReview table",
                e.args,
                501,
            )

    def get_by_name(self, name: str):
        """[CRUD function to read a PromptsReview record]

        Args:
            PromptsReview_name (str): [PromptsReview name to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [PromptsReview record matching the criteria]
        """
        try:
            logger.info("executing get-by-name-PromptsReview crud ...")
            with session() as transaction_session:
                obj: PromptsReviewLog = (
                    transaction_session.query(PromptsReviewLog)
                    .filter(PromptsReviewLog.name == name)
                    .first()
                )
            if obj is not None:
                return obj.__dict__
            else:
                return None

        except Exception as e:
            logger.error("Error while filtering PromptsReview table by name")
            return get_err_json_response(
                "Error while filtering PromptsReview table by name",
                e.args,
                501,
            )

    def get_by_id(self, id: int):
        """[CRUD function to read a PromptsReview record]

        Args:
            PromptsReview_id (str): [PromptsReview id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [PromptsReview record matching the criteria]
        """
        try:
            logger.info("executing get-PromptsReview-by-id crud ...")
            with session() as transaction_session:
                obj: PromptsReviewLog = (
                    transaction_session.query(PromptsReviewLog)
                    .filter(PromptsReviewLog.id == id)
                    .first()
                )
            if obj is not None:
                return obj.__dict__
            else:
                return None

        except Exception as e:
            logger.error("Error while filtering PromptsReview table by id")
            return get_err_json_response(
                "Error while filtering PromptsReview table",
                e.args,
                501,
            )


    def read_by_prompt_id(self, prompt_id, version):
        """[CRUD function to read a review log record]

        Args:
            prompt id (str): [prompt id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt review record matching the criteria]
        """
        try:
            logger.info("executing read-prompt-by-id crud ...")
            with session() as transaction_session:
                query = (transaction_session.query(PromptsReviewLog)
                        .filter(PromptsReviewLog.prompt_id == prompt_id))
                
                if version is not None:
                    query = query.filter(PromptsReviewLog.prompt_version == version)

                review_logs: PromptsReviewLog = (query.order_by(desc(PromptsReviewLog.modified_at))
                                                        .all())
                    
                if review_logs is not None:
                    return [review_log.__dict__ for review_log in review_logs]
                else:
                    return None
            
        except Exception as e:
            logger.error("Error while reading records by id from prompt review log table")
            raise e