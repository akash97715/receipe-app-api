
from db.orm_models.v2.prompts import Prompts
from crud.v2.prompt_crud import CRUDPrompt
from db.session import acquire_db_session as session
from utils.logs.logger_config import logger
from db.orm_models.v2.enums import Status
from sqlalchemy import func, distinct



class CRUDStats:
    def __init__(self) -> None:
        self.CRUDPrompt = CRUDPrompt()
        
    def get_stats(self, user_info):
        try:
            logger.info("Inside CRUD stats - get stats !")
            with session() as transaction_session:
                query= transaction_session.query(func.count(distinct(Prompts.id))).filter(CRUDPrompt.get_user_access_check_query(user_info),Prompts.status == Status.APPROVED)
                private_count = query.filter(Prompts.is_private == True).scalar()
                shared_count = query.filter(Prompts.is_private == False).scalar()
                return {
                    "approved_private_prompts_count": private_count,
                    "approved_shared_prompts_count": shared_count
                }
        except Exception as e:
            raise e