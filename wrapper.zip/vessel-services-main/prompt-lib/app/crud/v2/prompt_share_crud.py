from sqlalchemy import and_, or_, select, exists
from db.session import acquire_db_session as session
from db.orm_models.v2.prompts_share_map import PromptsShareMap
from db.orm_models.v2.prompts import Prompts
from db.orm_models.v2.enums import Shared_with_type
from utils.logs.logger_config import logger

class CRUDPromptShareMap:

    @staticmethod
    def get_user_access_check_query(user_info):
        return or_(
                and_(
                    Prompts.created_by == user_info["Username"],
                    Prompts.creator_tenant_id == user_info["mule_client_id"],
                ),
                and_(
                    Prompts.is_private == False,
                    exists(select(1)).where(
                        (PromptsShareMap.prompt_id == Prompts.id) &
                        (PromptsShareMap.shared_with_id.in_([user_info["Username"], user_info["mule_client_id"]]))
                    ),
                ),
            )

    def create(self, **kwargs):
        """[CRUD function to create a new record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-PromptShareMap crud ...")
            obj = PromptsShareMap(**kwargs)
            with session() as transaction_session:
                transaction_session.add(obj)
                transaction_session.commit()
                transaction_session.refresh(obj)
            
            return obj.__dict__
        
        except Exception as e:
            logger.error("Error while adding to PromptShareMap table")
            raise e

    def read_all(self):
        """[CRUD function to read_all entries]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all records]
        """
        try:
            logger.info("executing read-all-PromptShareMap crud ...")
            with session() as transaction_session:
                obj: PromptsShareMap = transaction_session.query(PromptsShareMap).all()
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []
            
        except Exception as e:
            logger.error("Error while getting data from PromptShareMap table")
            raise e

    def read_by_id_sharetype(self, prompt_id: str, shared_with_type: Shared_with_type = None):
        """[CRUD function to read a record by id and "shared with type"]

        Args:
            prompt_id (str): [id of the prompt]
            share_with_type (Optional(str)): [type of entities the prompt is shared with eg: USERS or GROUPS.]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [record matching the criteria]
        """
        try:
            logger.info("executing get-by-id-sharetype-PromptShareMap crud ...")
            with session() as transaction_session:
                obj = transaction_session.query(PromptsShareMap)
                if shared_with_type is None:
                    obj = obj.filter(PromptsShareMap.prompt_id == prompt_id, PromptsShareMap.is_deleted == False).all()
                        
                else:
                    obj = obj.filter(PromptsShareMap.prompt_id == prompt_id,
                                    PromptsShareMap.shared_with_type == shared_with_type,
                                    PromptsShareMap.is_deleted == False).all()
                
            if obj is not None:
 
                for entry in obj:
                    entry = entry.__dict__

                return obj
            else:
                return []
            
        except Exception as e:
            logger.error("Error while filtering PromptShareMap table...")
            raise e
        
    def update_delete_status(self, prompt_id: str, user_info, shared_with_type: Shared_with_type= None, shared_with_id: str = None):
        """[CRUD function to delete a record by id]

        Args:
            prompt_id (str) : [prompt id whose mapping needs to be deleted]
            shared_with_type (str) : [type of shared ids that need to be deleted]
            shared_with_id (str) : [shared id that needs to be deleted]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            int : number of deleted records
        """
        try:
            logger.info("executing delete-promptShareMap crud ...")
            with session() as transaction_session:
                obj: PromptsShareMap = (
                        transaction_session.query(PromptsShareMap)
                        .filter(PromptsShareMap.prompt_id == prompt_id, PromptsShareMap.is_deleted == False)
                )

                if shared_with_type is not None:
                    obj = obj.filter(PromptsShareMap.shared_with_type == shared_with_type) 
                
                if shared_with_id is not None:
                    obj = obj.filter(PromptsShareMap.shared_with_id == shared_with_id)
                
                obj = obj.update(dict(is_deleted = True , modified_by = user_info["Username"]), synchronize_session=False)

                transaction_session.commit()

            if obj is not None:
               return obj
            else:
                return 0
            
        except Exception as e:
            logger.error("Error while deleting record in PromptShareMap table...")
            raise e
        

    def duplicate_check(self, prompt_id: str,shared_with_type: Shared_with_type, shared_with_id: str):
        """[CRUD function to check for duplicate entry]

        Args:
            prompt_id (str): [prompt id of the record]
            shared_with_type (str): [type of the entity prompt is shared with]
            shared_with_id (str): [id of the entity prompt is shared with]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            str: [id of the record if it exists]
        """
        try:
            logger.info("executing duplicated-check crud ...")
            with session() as transaction_session:
                obj: PromptsShareMap = (
                    transaction_session.query(PromptsShareMap)
                    .filter(PromptsShareMap.prompt_id == prompt_id,
                            PromptsShareMap.shared_with_type == shared_with_type, 
                            PromptsShareMap.shared_with_id == shared_with_id, 
                            PromptsShareMap.is_deleted == False)
                    .first()
                )
                transaction_session.commit()

            if obj is not None:
               return obj.__dict__
            else:
                return None
            
        except Exception as e:
            logger.error("Error while reading a record in PromptShareMap table...")
            raise e