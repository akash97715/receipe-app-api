from fastapi import HTTPException
from crud.v2.prompt_review_crud import CRUDPromptReviewLog
from db.orm_models.v2.enums import Status, Fetch_Status, Sort_By, Order_By, Search_on
from db.orm_models.v2.prompts import Prompts
from db.orm_models.v2.prompts_review_log import PromptsReviewLog
from db.orm_models.v2.prompts_share_map import PromptsShareMap
from db.session import acquire_db_session as session
from sqlalchemy import and_, desc, or_, tuple_, exists, select
from sqlalchemy.sql import func
from utils.logs.logger_config import logger


class CRUDPrompt:
    def __init__(self) -> None:
        self.CRUDPromptReviewLog = CRUDPromptReviewLog()

    def get_review_prompt_obj(self, db_prompt):
        return {
            "prompt_id": db_prompt["id"],
            "prompt_version": db_prompt["version"],
            "review_status": db_prompt["status"],
            "review_comment": "",
            "created_by": db_prompt["created_by"],
            "modified_by": db_prompt["modified_by"],
        }

    @staticmethod
    def get_user_access_check_query(user_info):
        return or_(
                and_(
                    Prompts.created_by == user_info["Username"],
                    Prompts.creator_tenant_id == user_info["mule_client_id"],
                ),
                and_(
                    Prompts.is_private == False,
                    exists(select(1)).where(
                        (PromptsShareMap.prompt_id == Prompts.id) &
                        (PromptsShareMap.shared_with_id.in_([user_info["Username"], user_info["mule_client_id"]])) &
                        (PromptsShareMap.is_deleted == False)
                    ),
                ),
            )

    def create(self, **kwargs):
        """[CRUD function to create a new prompt record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-prompt crud ...")
            db_prompt = Prompts(**kwargs)
            with session() as transaction_session:
                transaction_session.add(db_prompt)
                transaction_session.commit()
                transaction_session.refresh(db_prompt)
                logger.info("Created a new prompt record")

            db_prompt = db_prompt.__dict__
            if db_prompt is not None:
                return db_prompt
            else:
                return None

        except Exception as e:
            logger.error("Error while adding to prompt table")
            raise e

    def read_by_name(self, prompt_name):
        """[CRUD function to read a prompt record by name]

        Args:
            prompt_name (str): [prompt_name to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing read-prompt-by-name crud ...")
            with session() as transaction_session:
                obj: Prompts = (
                    transaction_session.query(Prompts)
                    .filter(func.lower(Prompts.name) == func.lower(prompt_name))
                    .all()
                )
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []
        except Exception as e:
            logger.error("Error while reading records by name from prompt table")
            raise e

    def duplicate_check(self, prompt_name):
        """[CRUD function to read a prompt record by name]

        Args:
            prompt_name (str): [prompt_name to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing read-prompt-by-name crud ...")
            with session() as transaction_session:
                
                obj: Prompts = (
                    transaction_session.query(exists().where(
                        func.lower(Prompts.name) == func.lower(prompt_name), 
                        Prompts.status.notin_([Status.DELETED, Status.REJECTED])
                    )).scalar()
                )

            if obj:
                return True
            else:
                return False
        except Exception as e:
            logger.error("Error while reading records by name from prompt table")
            raise e


    def read_by_id(self, user_info, prompt_id, version=None):
        """[CRUD function to read a specific or the latest version of prompt]

        Args:
            prompt id (str): [prompt id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing read-prompt-by-id crud ...")
            with session() as transaction_session:
                obj: Prompts = (
                    transaction_session.query(Prompts)
                    .filter(
                        Prompts.id == prompt_id,
                        (Prompts.version == version) if version is not None else True,
                        self.get_user_access_check_query(user_info)
                    )
                    .order_by(desc(Prompts.version))
                    .first()
                )
            if obj is not None:
                return obj.__dict__
            else:
                logger.info("Prompt not found with then mentioned attributes for the current user!")
                return []
        except Exception as e:
            logger.error("Error while reading records by id from prompt table")
            raise e

    def update(self, db_prompt, prompt_id):
        """[CRUD function to update a Prompt record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update prompt crud ...")
            with session() as transaction_session:
                obj: Prompts = (
                    transaction_session.query(Prompts)
                    .filter(Prompts.id == prompt_id)
                    .update(db_prompt, synchronize_session=False)
                )
                transaction_session.commit()
            if obj is not None:
                return obj
            else:
                return None

        except Exception as e:
            logger.error("Error while updating Prompts table")
            raise e

    def read_by_id_status(self,user_info, prompt_id, version=None):
        """[CRUD function to read a prompt record]

        Args:
            prompt id (str): [prompt id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing read_by_id_version crud ...")
            with session() as transaction_session:
                obj = transaction_session.query(Prompts).filter(self.get_user_access_check_query(user_info=user_info))
                if version:
                    obj = obj.filter(
                            and_(Prompts.id == prompt_id, Prompts.version == version, Prompts.creator_tenant_id == user_info["mule_client_id"])
                        ).first()
                else:
                    obj= obj.filter(
                            and_(
                                Prompts.id == prompt_id,
                                Prompts.status == Status.APPROVED.value,
                                Prompts.creator_tenant_id == user_info["mule_client_id"],
                            )
                        ).first()
            if obj is not None:
                return obj.__dict__
            else:
                return None
        except Exception as e:
            logger.error(
                "Error while reading records by id and status from prompt table"
            )
            raise e

    def update_cols(self, id, version, **columns):
        """[CRUD function to update record of the specified version of a prompt]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update_status prompt crud ...")

            with session() as transaction_session:
                obj: Prompts = (
                    transaction_session.query(Prompts)
                    .filter(
                        and_(
                            Prompts.id == id,
                            Prompts.version == version,
                        )
                    )
                    .update(columns, synchronize_session=False)
                )
                transaction_session.commit()

            if obj is not None:
                return obj
            else:
                return None

        except Exception as e:
            logger.error("Error while updating Prompts table for delete")
            raise e
        

    def update_privacy(self, id, is_private, modified_by):
        """[CRUD function to update privacy of the all versions of a prompt]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update_privacy prompt crud ...")

            with session() as transaction_session:
                obj: Prompts = (
                    transaction_session.query(Prompts)
                    .filter(
                            Prompts.id == id
                    )
                    .update(dict(is_private= is_private, modified_by= modified_by), synchronize_session=False)
                )
                transaction_session.commit()

            if obj is not None:
                return obj
            else:
                return None

        except Exception as e:
            logger.error("Error while updating Prompts table")
            raise e   


    def get_prompts(
        self,
        user_info,
        input_id,
        input_created_by,
        input_is_private,
        input_is_visible,
        input_status,
        limit,
        offset,
        order_by,
        sort_by,
        input_with_review_results,
    ):
        """[CRUD function to read_multiple prompts record]

        Args:
            input id (str): [prompt id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all prompt records]
        """
        try:
            logger.info("executing read-prompts crud ...")
            with session() as transaction_session:
                # Build the query dynamically
                query = transaction_session.query(Prompts).filter(self.get_user_access_check_query(user_info))

                if input_id is not None:
                    query = query.filter(Prompts.id == input_id)

                if input_created_by is not None:
                    query = query.filter(Prompts.created_by == input_created_by)

                if input_is_private is not None:
                    query = query.filter(Prompts.is_private == input_is_private)

                if input_is_visible is not None:
                    query = query.filter(Prompts.is_visible == input_is_visible)

                if input_status is not None and input_status != "ALL":
                    if input_status == Fetch_Status.NOT_DELETED:
                        query = query.filter(Prompts.status != "DELETED")
                    elif input_status == Fetch_Status.NOT_REJECTED:
                        query = query.filter(Prompts.status != Status.DELETED, Prompts.status != Status.REJECTED)
                    else:
                        query = query.filter(Prompts.status == Status(input_status.value))

                # Apply ordering and sorting
                if order_by is not None:
                    order_column = getattr(Prompts, order_by)
    
                    if sort_by == Order_By.ASC:
                        query = query.order_by(order_column.asc())
                    else:
                        query = query.order_by(order_column.desc())

                total_count = query.count()

                # Apply pagination
                if limit is not None:
                    start_index = (offset - 1) * limit
                    end_index = start_index + limit
                    query = query.offset(start_index).limit(limit)
                

                # Execute the query
                prompts = query.all()
                if prompts == []:
                    logger.info("There are no prompts in table with matching criteria")
                    return ([], total_count)

                if input_with_review_results:
                    logger.info(
                        "Extracting IDs & versions from the prompts for fetching related review logs"
                    )
                    related_ids_versions_list = [
                        (prompt.id, prompt.version) for prompt in prompts
                    ]

                    logger.info(
                        "Query to filter the PromptReviewLogTable based on the list of IDs and versions"
                    )
                    subquery = (
                        transaction_session.query(
                            PromptsReviewLog.prompt_id, 
                            PromptsReviewLog.prompt_version,
                            func.max(PromptsReviewLog.modified_at).label(
                                "max_modified_at"
                            ),
                        )
                        .group_by(
                            PromptsReviewLog.prompt_id, PromptsReviewLog.prompt_version
                        ).subquery()
                    )

                    review_results = (
                        transaction_session.query(
                            PromptsReviewLog
                        )
                        .join(
                            subquery, and_(
                                PromptsReviewLog.prompt_id == subquery.c.prompt_id,
                                PromptsReviewLog.prompt_version == subquery.c.prompt_version,
                                PromptsReviewLog.modified_at == subquery.c.max_modified_at,
                                )
                            )
                        ).all()
                    
                    logger.info("Dropping unneccessary column...")

                # return prompts
                if prompts is not None:
                    if input_with_review_results:
                        logger.info("Restructuring the output for prompts")

                        for p_row in range(len(prompts)):
                            for r_row in range(len(review_results)):
                                prompt = prompts[p_row].__dict__
                                review_result = review_results[r_row].__dict__
                                review_logs = {
                                    "review_status": review_result["review_status"],
                                    "review_comment": review_result["review_comment"],
                                    "review_modified_at": review_result["modified_at"],
                                    "review_modified_by": review_result["modified_by"],
                                    "review_created_at": review_result["created_at"],
                                    "review_created_by": review_result["created_by"],
                                }
                                if (
                                    prompt["id"] == review_result["prompt_id"]
                                    and prompt["version"] == review_result["prompt_version"]
                                ):
                                    prompt.update({"review_logs": review_logs})

                    prompts = [prompt.__dict__ for prompt in prompts]
                else:
                    prompts = []

                return prompts, total_count

        except Exception as e:
            logger.error("Error while reading records from prompt table")
            raise e

    def get_prompts_by_text(
        self,
        user_info,
        search_text,
        search_on,
        search_tags,
        search_logic,
        created_by,
        is_private,
        is_visible,
        sort_by,
        sort_order,
        page_number,
        page_limit,
    ):
        with session() as transaction_session:
            obj: Prompts = transaction_session.query(Prompts).filter(self.get_user_access_check_query(user_info), Prompts.status == Status.APPROVED)
            if search_tags is not None :
                    if search_logic == "AND":
                        obj  = obj.filter(Prompts.tags.contains(search_tags))
                    else:
                        obj  = obj.filter(Prompts.tags.overlap(search_tags))
            
            elif(len(search_text.strip())==0):
                return {
                    "prompts": [],
                    "page_number": page_number,
                    "page_limit": page_limit,
                    "total_count": 0
                }
            if search_on == "all":
                obj = obj.filter(
                    Prompts.name.ilike(f"%{search_text}%")
                    | Prompts.prompt.ilike(f"%{search_text}%")
                    | Prompts.system_prompt.ilike(f"%{search_text}%")
                )
            elif search_on == "name":
                obj = obj.filter(
                    Prompts.name.ilike(f"%{search_text}%")
                )
            elif search_on == "prompt":
                obj = obj.filter(
                    Prompts.prompt.ilike(f"%{search_text}%")
                )
            elif search_on == "system_prompt":
                obj = obj.filter(
                    Prompts.system_prompt.ilike(f"%{search_text}%")
                )

            if is_private is not None:
                obj = obj.filter(Prompts.is_private == is_private)

            if created_by:
                obj = obj.filter(Prompts.created_by == created_by)

            if is_visible is not None:
                obj = obj.filter(Prompts.is_visible == is_visible)


            # sorting section
            sort_column = getattr(Prompts, sort_by)
            if sort_order == "DESC":
                obj = obj.order_by(sort_column.desc())
            else:
                obj = obj.order_by(sort_column.asc())

            # total count
            total_count = obj.count()

            # pagination section
            if page_limit > -1:
                start_index = (page_number - 1) * page_limit
                end_index = start_index + page_limit
                obj = obj.offset(start_index).limit(page_limit)

            return {
                "prompts": obj.all(),
                "page_number": page_number,
                "page_limit": page_limit,
                "total_count": total_count,
            }

    def get_all_prompts_by_id(self, prompt_id, user_info):
        """[CRUD function to read a prompt record]

        Args:
            prompt id (str): [prompt id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing get_all_prompts_by_id crud ...")
            with session() as transaction_session:
                obj: Prompts = (
                    transaction_session.query(Prompts)
                    .filter(Prompts.id == prompt_id, self.get_user_access_check_query(user_info))
                    .order_by(Prompts.modified_at)
                    .all()
                )
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []
        except Exception as e:
            logger.error("Error while reading records by id from prompt table")
            raise e

    def check_user_access_to_prompt(self, user_info, prompt_id, version = None):
        try:
            logger.info("Checking if the user has access to the prompt...")
            with session() as transaction_session:
                has_access: Prompts = (
                    transaction_session.query(exists().where(
                         Prompts.id == prompt_id,
                        (Prompts.version == version) if version is not None else True,
                        self.get_user_access_check_query(user_info)
                    )).scalar()
                )
            if has_access:
                return True
            else:
                return False
        except Exception as e:
            logger.error("Error while reading records by id from prompt table")
            raise e
        