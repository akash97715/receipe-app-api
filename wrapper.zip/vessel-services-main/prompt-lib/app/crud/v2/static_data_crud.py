from db.session import acquire_db_session as session
from db.orm_models.v2.static_api import StaticApiData
from config.errors import get_err_json_response
from utils.logs.logger_config import logger
from sqlalchemy import desc


class CRUDStaticData:
    def create(self, **kwargs):
        """[CRUD function to create a new User record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-CRUDStaticData crud ...")
            obj = StaticApiData(**kwargs)
            with session() as transaction_session:
                transaction_session.add(obj)
                transaction_session.commit()
                transaction_session.refresh(obj)
            return obj.__dict__

        except Exception as e:
            logger.error("Error while adding to StaticData table")
            raise e

    def get_by_id(self, data_id: str):
        """[CRUD function to read a StaticData record]

        Args:
            id (str): [StaticData id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [StaticData record matching the criteria]
        """
        try:
            logger.info("executing get-by-id-StaticData crud ...")
            with session() as transaction_session:
                obj: StaticApiData = (
                    transaction_session.query(StaticApiData)
                    .filter(StaticApiData.id == data_id)
                    .first()
                )
            if obj is not None:
                return obj.__dict__
            else:
                return None

        except Exception as e:
            logger.error("Error while filtering StaticData table by id")
            return get_err_json_response(
                "Error while filtering StaticData table by id",
                e.args,
                501,
            )
