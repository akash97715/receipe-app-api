from db.session import acquire_db_session as session
from db.orm_models.v1.admin_config_model import Group
from config.errors import get_err_json_response
from utils.logs.logger_config import logger

class CRUDGroup:
    def create(self, **kwargs):
        """[CRUD function to create a new user record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-user crud ...")
            group = Group(**kwargs)
            with session() as transaction_session:
                transaction_session.add(group)
                transaction_session.commit()
                transaction_session.refresh(group)
            return group.__dict__
        except Exception as e:
            logger.error("Error while adding to group table")
            return get_err_json_response(
            "Error while adding to group table",
            e.args,
            501,
        )

    def read_all(self):
        """[CRUD function to read_all groups record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all group records]
        """
        try:
            logger.info("executing read-all group crud ...")
            with session() as transaction_session:
                obj: Group = transaction_session.query(Group).all()
            if obj is not None:
                return [row.__dict__["group_name"] for row in obj]
            else:
                return []
            
        except Exception as e:
            logger.error("Error while reading records from group table")
            return get_err_json_response(
            "Error while reading records from group table",
            e.args,
            501,
        )


    def get_by_id(self, id: int):
        """[CRUD function to read a group record]

        Args:
            id (int): [group id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [str]: [group name matching the criteria]
        """
        try:
            logger.info("executing get-by-id group crud ...")
            with session() as transaction_session:
                obj: Group = (
                    transaction_session.query(Group)
                    .filter(Group.id == id)
                    .first()
                )
                if obj is not None:
                    return {"group_name": obj.__dict__["group_name"]}
                else:
                    return None
                
        except Exception as e:
            logger.error("Error while reading a record by name from group table")
            return get_err_json_response(
            "Error while reading a record by name from group table",
            e.args,
            501,
        )

    def get_by_name(self, group_name: str):
        """[CRUD function to read a group record by group_name]
        Args:
            group_name (str): [group name to filter the record]
        Raises:
            error: [Error returned from the DB layer]
        Returns:
            [str]: [group name matching the criteria]
        """
        try:
            logger.info("executing get-by-name group crud ...")
            with session() as transaction_session:
                obj: Group = (
                    transaction_session.query(Group)
                    .filter(Group.group_name == group_name)
                    .first()
                )
                if obj is not None:
                    return {"group_name": obj.__dict__["group_name"]}
                else:
                    return None

        except Exception as e:
            logger.error("Error while reading a record by name from group table")
            return get_err_json_response(
            "Error while reading a record by name from group table",
            e.args,
            501,
        )

    def update(self, **kwargs):
        """[CRUD function to update a group record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update group crud ...")
            with session() as transaction_session:
                obj: Group = (
                    transaction_session.query(Group)
                    .filter(Group.id == kwargs.get("id"))
                    .update(kwargs, synchronize_session=False)
                )
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("Error while updating group ")
            return get_err_json_response(
            "Error while updating group table",
            e.args,
            501,
        )

    def delete(self, id: int):
        """[CRUD function to delete a group record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete group crud ...")
            with session() as transaction_session:
                obj: Group = (
                    transaction_session.query(Group).filter(Group.id == id).first()
                )
                transaction_session.delete(obj)
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("error while deleting group")
            return get_err_json_response(
            "Error while deleting a record from group table",
            e.args,
            501,
        )

