from db.session import acquire_db_session as session
from db.orm_models.v1.admin_config_model import User
from config.errors import get_err_json_response
from utils.logs.logger_config import logger

class CRUDUser:
    def create(self, **kwargs):
        """[CRUD function to create a new user record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-user crud ...")
            user = User(**kwargs)
            with session() as transaction_session:
                transaction_session.add(user)
                transaction_session.commit()
                transaction_session.refresh(user)
            return user.__dict__
        except Exception as e:
            logger.error("Error while adding to user table")
            return get_err_json_response(
            "Error while adding to user table",
            e.args,
            501,
        )

    def read_all(self):
        """[CRUD function to read_all users record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all user records]
        """
        try:
            logger.info("executing read-all user crud ...")
            with session() as transaction_session:
                obj: User = transaction_session.query(User).all()
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []
            
        except Exception as e:
            logger.error("Error while reading records from user table")
            return get_err_json_response(
            "Error while reading records from user table",
            e.args,
            501,
        )

    def get_by_name(self, user_name: str):
        """[CRUD function to read a user record]

        Args:
            user_name (str): [user name to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [user record matching the criteria]
        """
        try:
            logger.info("executing read-by-username user crud ...")
            with session() as transaction_session:
                obj: User = (
                    transaction_session.query(User)
                    .filter(User.user_name == user_name)
                    .first()
                )
                if obj is not None:
                    return obj.__dict__
                else:
                    return None
                
        except Exception as e:
            logger.error("Error while reading a record by name from user table")
            return get_err_json_response(
            "Error while reading a record by name from user table",
            e.args,
            501,
        )

    def get_by_id(self, nt_id: str):
        """[CRUD function to read a user record]

        Args:
            nt_id (str): [user id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [user record matching the criteria]
        """
        try:
            logger.info("executing get-by-id user crud ...")
            with session() as transaction_session:
                obj: User = (
                    transaction_session.query(User)
                    .filter(User.nt_id == nt_id)
                    .first()
                )
                if obj is not None:
                    return obj.__dict__
                else:
                    return None
                
        except Exception as e:
            logger.error("Error while reading a record by name from user table")
            return get_err_json_response(
            "Error while reading a record by name from user table",
            e.args,
            501,
        )

    def update(self, **kwargs):
        """[CRUD function to update a user record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update user crud ...")
            with session() as transaction_session:
                obj: User = (
                    transaction_session.query(User)
                    .filter(User.nt_id == kwargs.get("nt_id"))
                    .update(kwargs, synchronize_session=False)
                )
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("Error while updating user ")
            return get_err_json_response(
            "Error while updating user table",
            e.args,
            501,
        )

    def delete(self, nt_id: str):
        """[CRUD function to delete a user record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete user crud ...")
            with session() as transaction_session:
                obj: User = (
                    transaction_session.query(User).filter(User.nt_id == nt_id).first()
                )
                transaction_session.delete(obj)
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("error while deleting user")
            return get_err_json_response(
            "Error while deleting a record from user table",
            e.args,
            501,
        )

    def get_groupId(self, nt_id: str):
        """[CRUD function to get groupId of a user record]

        Args:
            nt_id (str): [user ntid to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [user group id matching the criteria]
        """
        try:
            logger.info("executing get-groupId user crud ...")
            with session() as transaction_session:
                obj = (
                    transaction_session.query(User.group_id)
                    .filter(User.nt_id == nt_id)
                    .first()
                )
                return obj
                
        except Exception as e:
            logger.error("error while getting group by group id")
            return get_err_json_response(
            "Error while reading a record by name from user table",
            e.args,
            501,
        )