from db.session import acquire_db_session as session
from db.orm_models.v1.prompt_model import ApprovalPrompts,Prompts
from db.orm_models.v1.admin_config_model import AdminConfig
from config.errors import get_err_json_response
from crud.v1.domain_crud import CRUDDomain
from crud.v1.subdomain_crud import CRUDSubDomain
from crud.v1.category_crud import CRUDCategory
from crud.v1.user_crud import CRUDUser
from crud.v1.group_crud import CRUDGroup
from crud.v1.admin_config_crud import CRUDAdminConfig
from utils.logs.logger_config import logger
from utils.exceptions import ResourceNotFound
import json
from sqlalchemy import and_,desc

class CRUDPrompt:
    def __init__(self) -> None:
        self.CRUDDomain = CRUDDomain()    
        self.CRUDSubDomain = CRUDSubDomain()    
        self.CRUDCategory = CRUDCategory() 
        self.CRUDUser = CRUDUser()   
        self.CRUDGroup = CRUDGroup()
        self.CRUDAdminConfig = CRUDAdminConfig()
    
    def create(self, prompt):
        """[CRUD function to create a new prompt record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-prompt crud ...")
            with session() as transaction_session:
                db_prompt = Prompts(
                    admin_config_id = prompt.admin_config_id,
                    prompt_text = prompt.prompt_text, 
                    version = prompt.version,
                    annotation = prompt.annotation,
                    use_case_type = prompt.use_case_type,
                    prompt_type = prompt.prompt_type,
                    request_type = prompt.request_type,
                    submitted_source = prompt.submitted_source,
                    ranking = prompt.ranking,
                    tags = prompt.tags,
                    nt_id = prompt.nt_id,
                    group_id = prompt.group_id,
                    submitted_by = prompt.nt_id
                )
                transaction_session.add(db_prompt)
                transaction_session.commit()
                transaction_session.refresh(db_prompt)    
            return db_prompt.__dict__["id"]
        
        except Exception as e:
            logger.error("Error while adding to prompt table")
            return get_err_json_response(
            "Error while adding to prompt table",
            e.args,
            501,
        )

    def get_admin_config_data_for_prompts(self, all_prompts_data):
        try:
            logger.info("executing get_admin_config_data_for_prompts crud ...")
            for prompts in all_prompts_data:
                prompts = prompts.__dict__
                prompts["tags"] = json.loads(prompts["tags"])
                admin_config_id = prompts["admin_config_id"]
                admin_config_data = self.CRUDAdminConfig.get_display_by_id(admin_config_id)
                prompts.update(admin_config_data)
                logger.info("fetching group name from group id..")
                group_name = self.CRUDGroup.get_by_id(prompts["group_id"])
                prompts.update(group_name)
            return all_prompts_data
        
        except Exception as e:
            logger.error("Error while getting admin-config-data for a prompt.")
            return get_err_json_response(
            "Error while getting admin-config-data for a prompt",
            e.args,
            501,
        )
    
    def read_all(self):
        """[CRUD function to read_all prompt record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all prompt records]
        """
        try:
            logger.info("executing read-all-prompt crud ...")
            with session() as transaction_session:
                all_prompts_data = transaction_session.query(Prompts).all()
                response = self.get_admin_config_data_for_prompts(all_prompts_data= all_prompts_data)
                return response
            
        except Exception as e:
            logger.error("Error while reading records from prompt table")
            return get_err_json_response(
            "Error while reading records from prompt table",
            e.args,
            501,
        )
        
    def read_by_id(self, prompt_id: int):
        """[CRUD function to read a prompt record]

        Args:
            prompt id (str): [prompt id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing read-prompt-by-id crud ...")
            with session() as transaction_session:
                prompt_data =  (transaction_session.query(Prompts)
                        .filter(Prompts.id == prompt_id)
                        .all()
                )
                response = self.get_admin_config_data_for_prompts(all_prompts_data= prompt_data)
                return response
        except Exception as e:
            logger.error("Error while reading records by id from prompt table")
            return get_err_json_response(
            "Error while reading records by id from prompt table",
            e.args,
            501,
        )
    
    def update_ranking(self, **kwargs):
        """[CRUD function to update a Prompt record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update-ranking prompt crud ...")
            with session() as transaction_session:
                obj: Prompts = (
                        transaction_session.query(Prompts)
                        .filter(Prompts.id == kwargs.get("id"))
                        .first()
                    )
                if obj is not None:
                    obj.ranking  = obj.ranking + kwargs.get("ranking_value")
                    if(obj.ranking < 0):
                        obj.ranking = 0
                            
                    transaction_session.add(obj)
                    transaction_session.commit()
                    transaction_session.refresh(obj)
                    return obj.__dict__
                else:
                    return None
        
        except Exception as e:
            logger.error("Error while updating Prompts table")
            return get_err_json_response(
            "Error while updating Prompts table",
            e.args,
            501,
        )

    def delete(self, id: int):
        """[CRUD function to delete a prompt record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete-prompt crud ...")
            with session() as transaction_session:
                obj = transaction_session.query(Prompts)\
                    .filter(Prompts.id == id)\
                    .first()
                transaction_session.delete(obj)
                transaction_session.commit()
        except Exception as e:
            logger.error("Error while deleting records by id from prompt table")
            return get_err_json_response(
            "Error while deleting records by id from prompt table",
            e.args,
            501,
        )

    def filter_prompt(self, prompt_filter):
        """[CRUD function to filter a prompt record]

        Args:
            kwargs : [multiple arguments to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing filter-prompt crud ...")
            with session() as transaction_session:
                get_domain = self.CRUDDomain.get_by_name(prompt_filter.domain_name.lower())
                if get_domain is None:
                    raise ResourceNotFound("Domain with given name do not exist.")
                get_domain_id = get_domain["id"]
                get_admin_config_ids = []
                get_domain_admin_config_ids = transaction_session.query(AdminConfig.id).filter(AdminConfig.domain_id == get_domain_id)
                for ids in get_domain_admin_config_ids:
                    get_admin_config_ids.append(ids[0])
                get_subdomain = self.CRUDSubDomain.get_by_name(prompt_filter.subdomain_name.lower(), get_domain_id)
                if get_subdomain is None:
                    raise ResourceNotFound("SubDomain with given name do not exist.")
                get_subdomain_id = get_subdomain["id"]
                get_subdomain_admin_config_ids = transaction_session.query(AdminConfig.id).filter(AdminConfig.sub_domain_id == get_subdomain_id).all()
                for ids in get_subdomain_admin_config_ids:
                    get_admin_config_ids.append(ids[0])
                if prompt_filter.category_name:
                    get_category = self.CRUDCategory.get_by_name(prompt_filter.category_name.lower())
                    if get_category is None:
                        raise ResourceNotFound("Category with given name do not exist.")
                    get_category_id = get_category["id"]
                    get_admin_config_ids = transaction_session.query(AdminConfig.id).filter(and_(AdminConfig.category_id == get_category_id, AdminConfig.domain_id == get_domain_id, AdminConfig.sub_domain_id == get_subdomain_id))
                get_prompts = transaction_session.query(Prompts).filter(Prompts.admin_config_id.in_(get_admin_config_ids)).all()
                result = []
                keyword = prompt_filter.keyword
                for prompt in get_prompts:
                    if keyword.lower() in prompt.prompt_text.lower():
                        result.append(prompt)
                response = self.get_admin_config_data_for_prompts(all_prompts_data= result)
                return response
            
        except ResourceNotFound as ex:
            logger.error("Error: resource with given name not exist while filtering prompts.")
            return get_err_json_response(
            "Error while filtering records from prompt table",
            ex.args,
            400,
        )
        except Exception as e:
            logger.error("Error while filtering records from prompt table")
            return get_err_json_response(
            "Error while filtering records from prompt table",
            e.args,
            501,
        )

    def get_prompt_by_group_id(self, nt_id: str):
        """[CRUD function to read a prompt record]

        Args:
            group id (str): [group id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [prompt record matching the criteria]
        """
        try:
            logger.info("executing get-prompt-by-group-id prompt crud ...")
            with session() as transaction_session:
                group_id = self.CRUDUser.get_groupId(nt_id)[0]
                all_prompts_data = (transaction_session.query(ApprovalPrompts)
                                        .filter(ApprovalPrompts.group_id == group_id)
                                        .order_by(desc(ApprovalPrompts.id))
                                        .all())
                response = self.get_admin_config_data_for_prompts(all_prompts_data= all_prompts_data)
                return response
        except Exception as e:
            logger.error("Error while fetching records by group id from approval prompt table")
            return get_err_json_response(
            "Error while fetching records by group id from approval prompt table",
            e.args,
            501,
        )