import json
from db.session import acquire_db_session as session
from datetime import datetime
from db.orm_models.v1.prompt_model import ApprovalPrompts,Status
from crud.v1.prompt_crud import CRUDPrompt
from crud.v1.admin_config_crud import CRUDAdminConfig
from crud.v1.user_crud import CRUDUser
from crud.v1.group_crud import CRUDGroup
from config.errors import get_err_json_response
from utils.logs.logger_config import logger
from sqlalchemy import and_,desc
from utils.exceptions import BadRequestException

class CRUDApprovalPrompt:
    def __init__(self):
        self.CRUDPrompt = CRUDPrompt()
        self.CRUDUser = CRUDUser()
        self.CRUDGroup = CRUDGroup()
        self.CRUDAdminConfig = CRUDAdminConfig()

    def create(self, prompt):
        """[CRUD function to create a new approval_prompt record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create approval prompt crud ...")
            prompt.tags = json.dumps(prompt.tags)
            prompt_dict = prompt.dict()
            prompt_dict["submitted_by"] = prompt_dict["nt_id"]
            db_prompt = ApprovalPrompts(**prompt_dict)
            db_prompt.group_id = self.CRUDUser.get_groupId(db_prompt.nt_id)[0]
            with session() as transaction_session:
                transaction_session.add(db_prompt)
                transaction_session.commit()
                transaction_session.refresh(db_prompt)
            return {"message": "Successfully added"}
        except Exception as e:
            logger.error("Error while adding to approval prompt table")
            return get_err_json_response(
            "Error while adding to appproval prompt table",
            e.args,
            501,
        )

    def get_admin_config_data_for_approval_prompts(self, all_prompts_data, domain = None, subdomain = None):
        try:
            logger.info("executing get_admin_config_data_for_prompts crud ...")
            prompt_list = []
            for prompts in all_prompts_data:
                prompts = prompts.__dict__
                prompts["tags"] = json.loads(prompts["tags"])
                admin_config_id = prompts["admin_config_id"]
                if domain and subdomain:
                    admin_config_data = self.CRUDAdminConfig.get_display_by_id(admin_config_id, domain, subdomain)
                else:
                    admin_config_data = self.CRUDAdminConfig.get_display_by_id(admin_config_id)
                if admin_config_data:
                    prompts.update(admin_config_data)
                    logger.info("fetching group name from group id..")
                    group_name = self.CRUDGroup.get_by_id(prompts["group_id"])
                    prompts.update(group_name)
                    prompt_list.append(prompts)
            return prompt_list
        
        except Exception as e:
            logger.error("Error while getting admin-config-data for an approval prompt.")
            return get_err_json_response(
            "Error while getting admin-config-data for an approval prompt",
            e.args,
            501,
        )

    def read_all(self):
        """[CRUD function to read_all approval_prompt record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all approval_prompt records]
        """
        try:
            logger.info("executing read all approval prompt crud ...")
            with session() as transaction_session:
                all_prompts_data = transaction_session.query(ApprovalPrompts).all()
                response = self.get_admin_config_data_for_approval_prompts(all_prompts_data=all_prompts_data)
                return response
            
        except Exception as e:
            logger.error("Error while reading records from approval prompt table")
            return get_err_json_response(
            "Error while reading records from appproval prompt table",
            e.args,
            501,
        )
        
    def read_by_id(self, approval_id: int):
        """[CRUD function to read a approval_prompt record]

        Args:
            approval_prompt_id (str): [approval_prompt id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [approval_prompt record matching the criteria]
        """
        try:
            logger.info("executing read-by-id approval prompt crud ...")
            with session() as transaction_session:
                approval_prompt_data = (transaction_session.query(ApprovalPrompts)
                                        .filter(ApprovalPrompts.id == approval_id)
                                        .all())
                response = self.get_admin_config_data_for_approval_prompts(all_prompts_data=approval_prompt_data)
                return response
                
        except Exception as e:
            logger.error("Error while reading record by id from approval prompt table")
            return get_err_json_response(
            "Error while reading records by id from appproval prompt table",
            e.args,
            501,
        )

    def bulk_approve_prompt(self, approval_prompt_body):
        """[CRUD function to approve bulk request a approval_prompt record]

        Args:
            approval_prompt_body (Obj): approval_prompt_body to approve/reject a record

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            str: approval_prompt record approved/rejected message

        """
        try:
            logger.info("executing bulk approve prompt crud ...")
            output=[]
            with session() as transaction_session:  
                if approval_prompt_body.status != "APPROVED" and approval_prompt_body.status != "REJECTED":
                    raise BadRequestException()
                
                for id in approval_prompt_body.prompt_ids:
                    prompt_body = (transaction_session.query(ApprovalPrompts)
                                .filter(ApprovalPrompts.id == id)
                                .first())
                    if prompt_body is None:
                        output.append(f"Prompt with id = {id} does not exist.")
                        continue
                    prompt_id = None
                    if prompt_body.status == Status.PENDING:
                        if approval_prompt_body.status == "APPROVED":
                            prompt_id = self.CRUDPrompt.create(prompt=prompt_body)    
                        prompt_body.prompt_id = prompt_id
                        prompt_body.approver_id = approval_prompt_body.approver_id
                        prompt_body.status = approval_prompt_body.status
                        prompt_body.approved_time = datetime.now()
                        transaction_session.add(prompt_body)
                        transaction_session.commit()
                        transaction_session.refresh(prompt_body)
                        output.append(f"Successfully {approval_prompt_body.status} the prompt with id = {id} !!")
                    else:
                        output.append(f"Prompt with id = {id} already {prompt_body.status.value}")
            return output
        
        except BadRequestException as e:
            return get_err_json_response(
            "Status must be APPROVED or REJECTED only.Please send correct status!",
            e.args,
            400,
            )
        except Exception as e:
            logger.error("Error while approving/rejecting a record from approval prompt table")
            return get_err_json_response(
            "Error while approving/rejecting a record from appproval prompt table",
            e.args,
            501,
        )

    def update_ranking(self, **kwargs):
        """[CRUD function to update a Prompt record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update-ranking crud ...")
            with session() as transaction_session:
                obj:  ApprovalPrompts= (
                        transaction_session.query(ApprovalPrompts)
                        .filter(ApprovalPrompts.prompt_id == kwargs.get("id"))
                        .first()
                    )
                if obj is not None:
                    obj.ranking  = obj.ranking + kwargs.get("ranking_value")
                    if(obj.ranking < 0):
                        obj.ranking = 0
                            
                    transaction_session.add(obj)
                    transaction_session.commit()
                    transaction_session.refresh(obj)
                    return obj.__dict__
                else:
                    return None
            
        except Exception as e:
            logger.error("Error while updating Approval Prompts table")
            return get_err_json_response(
            "Error while updating Approval Prompts table",
            e.args,
            501,
        )

    def read_all_pending_prompts(self, domain = None, subdomain = None):
        """[CRUD function to read_all pending approval_prompt record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all pending approval_prompt records]
        """
        try:
            logger.info("executing read-all-pending-prompts crud ...")
            with session() as transaction_session:
                pending_prompts_data = (transaction_session.query(ApprovalPrompts)
                        .filter(ApprovalPrompts.status == "PENDING")
                        .order_by(desc(ApprovalPrompts.id))
                        .all())
                response = self.get_admin_config_data_for_approval_prompts(all_prompts_data=pending_prompts_data, domain=domain, subdomain=subdomain)
                return response
            
        except Exception as e:
            logger.error("Error while reading from Approval Prompts table")
            return get_err_json_response(
            "Error while reading records from appproval prompt table",
            e.args,
            501,
        )

    def get_count_pending_prompts_by_ntid(self, nt_id:str):
        """[CRUD function to get count of pending approval_prompt records by ntid]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [count of all pending approval_prompt records for a ntid]
        """
        try:
            logger.info("executing read-all-pending-prompts crud ...")
            with session() as transaction_session:
                pending_prompts_count = (transaction_session.query(ApprovalPrompts)
                        .filter(
                            and_(
                            ApprovalPrompts.status == "PENDING",
                            ApprovalPrompts.nt_id == nt_id
                        ))
                        .count())
                return {"prompt_pending_approval_count":pending_prompts_count}
                
        except Exception as e:
            logger.error("Error while reading count from Approval Prompts table")
            return get_err_json_response(
            "Error while reading count of pending approval records from appproval prompt table",
            e.args,
            501,
        )
