from db.session import acquire_db_session as session
from db.orm_models.v1.prompt_config_model import SubDomain
from config.errors import get_err_json_response
from utils.logs.logger_config import logger

class CRUDSubDomain:

    def create(self, **kwargs):
        """[CRUD function to create a new sub_domain record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-sub-domain crud ...")
            sub_domain = SubDomain(**kwargs)
            with session() as transaction_session:
                transaction_session.add(sub_domain)
                transaction_session.commit()
                transaction_session.refresh(sub_domain)
            return sub_domain.__dict__
        
        except Exception as e:
            logger.error("Error while adding to subdomain table")
            return get_err_json_response(
            "Error while adding to subdomain table",
            e.args,
            501,
        )


    def read_all(self):
        """[CRUD function to read_all sub_domains record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all sub_domain records]
        """
        try:
            logger.info("executing read-all-sub-domain crud ...")
            with session() as transaction_session:
                obj: SubDomain = transaction_session.query(SubDomain).all()
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []
            
        except Exception as e:
            logger.error("Error while reading records from sub domain table")
            return get_err_json_response(
            "Error while reading records from sub domain table",
            e.args,
            501,
        )


    def get_by_name(self, name: str, domain_id: int):
        """[CRUD function to read a domain record]

        Args:
            domain_name (str): [domain name to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [domain record matching the criteria]
        """
        try:
            logger.info("executing get-by-name sub-domain crud ...")
            with session() as transaction_session:
                obj: SubDomain = (
                        transaction_session.query(SubDomain)
                        .filter(SubDomain.name == name)
                        .filter(SubDomain.domain_id == domain_id)
                        .first()
                    )
            if obj is not None:
                return obj.__dict__
            else:
                return None
            
        except Exception as e:
            logger.error("error while filtering sub domain by name.")
            return get_err_json_response(
            "Error while filtering sub domain table",
            e.args,
            501,
        )

    def get_by_id(self, id: int):
        """[CRUD function to read a sub domain record]

        Args:
            subdomain_id (str): [subdomain id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [sub domain record matching the criteria]
        """
        try:
            logger.info("executing get-by-id sub-domain crud ...")
            with session() as transaction_session:
                obj: SubDomain = (
                        transaction_session.query(SubDomain)
                        .filter(SubDomain.id == id)
                        .first()
                    )
            if obj is not None:
                return obj.__dict__
            else:
                return None
            
        except Exception as e:
            logger.error("error while filtering subdomain by id.")
            return get_err_json_response(
            "Error while filtering subdomain table",
            e.args,
            501,
        )

    def update(self, **kwargs):
        """[CRUD function to update a sub_domain record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update-sub-domain crud ...")
            with session() as transaction_session:
                obj: SubDomain = (
                        transaction_session.query(SubDomain)
                        .filter(SubDomain.id == kwargs.get("id"))
                        .update(kwargs, synchronize_session=False)
                    )
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("error while updating subdomain.")
            return get_err_json_response(
            "Error while updating sub domain table",
            e.args,
            501,
        )


    def delete(self, id: int):
        """[CRUD function to delete a sub_domain record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete-sub-domain crud ...")
            with session() as transaction_session:
                obj: SubDomain = (
                        transaction_session.query(SubDomain)
                        .filter(SubDomain.id == id)
                        .first()
                    )
                transaction_session.delete(obj)
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("error while deleting subdomain.")
            return get_err_json_response(
            "Error while deleting record from sub domain table",
            e.args,
            501,
        )
