from db.session import acquire_db_session as session
from db.orm_models.v1.prompt_config_model import Category
from db.orm_models.v1.admin_config_model import AdminConfig
from config.errors import get_err_json_response
from utils.logs.logger_config import logger

class CRUDCategory:

    def create(self, **kwargs):
        """[CRUD function to create a new category record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-category crud ...")
            category = Category(**kwargs)
            with session() as transaction_session:
                transaction_session.add(category)
                transaction_session.commit()
                transaction_session.refresh(category)
            return category.__dict__
        
        except Exception as e:
            logger.error("Error while creating entry in category table")
            return get_err_json_response(
            "Error while adding to category table",
            e.args,
            501,
        )



    def read_all(self):
        """[CRUD function to read_all categorys record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all category records]
        """
        try:
            logger.info("executing read-all-category crud ...")
            with session() as transaction_session:
                obj: Category = transaction_session.query(Category).all()
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []
            
        except Exception as e:
            logger.error("Error while reading from category table")
            return get_err_json_response(
            "Error while reading from category table",
            e.args,
            501,
        )


    def get_by_name(self, name: str):
        """[CRUD function to read a Category record]

        Args:
            Category_name (str): [Category name to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [Category record matching the criteria]
        """
        try:
            logger.info("executing get-by-name-category crud ...")
            with session() as transaction_session:
                obj: Category = (
                        transaction_session.query(Category)
                        .filter(Category.name == name)
                        .first()
                    )
            if obj is not None:
                return obj.__dict__
            else:
                return None
            
        except Exception as e:
            logger.error("Error while filtering category table")
            return get_err_json_response(
            "Error while filtering category table",
            e.args,
            501,
        )



    def get_by_id(self, id: int):
        """[CRUD function to read a category record]

        Args:
            category_id (str): [category id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [Category record matching the criteria]
        """
        try:
            logger.info("executing get-category-by-id crud ...")
            with session() as transaction_session:
                obj: Category = (
                        transaction_session.query(Category)
                        .filter(Category.id == id)
                        .first()
                    )
            if obj is not None:
                return obj.__dict__
            else:
                return None
            
        except Exception as e:
            logger.error("Error while filtering category table by id")
            return get_err_json_response(
            "Error while filtering category table",
            e.args,
            501,
        )


    def get_by_domains(self, domain_id: int, sub_domain_id: int):
        """[CRUD function to read category records by domain and sub domain]

        Args:
            domain_id (int): [Domain ID to filter the record]
            sub_domain_id (int): [Sub domain ID to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [Category ids matching criteria]
        """
        try:
            logger.info("executing catgeory crud get by domains...")
            with session() as transaction_session:
                obj: AdminConfig = (
                        transaction_session.query(AdminConfig)
                        .filter(AdminConfig.domain_id == domain_id, AdminConfig.sub_domain_id ==  sub_domain_id)
                    )
            if obj is not None:
                return  [row.__dict__["category_id"] for row in obj]
            else:
                return None
            
        except Exception as e:
            logger.error("Error while filtering category table")
            return get_err_json_response(
            "Error while filtering category table",
            e.args,
            501,
        )


    def update(self, **kwargs):
        """[CRUD function to update a category record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update-category crud ...")
            with session() as transaction_session:
                obj: Category = (
                        transaction_session.query(Category)
                        .filter(Category.id == kwargs.get("id"))
                        .update(kwargs, synchronize_session=False)
                    )
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("Error while updating category table")
            return get_err_json_response(
            "Error while updating category table",
            e.args,
            501,
        )


    def delete(self, id: int):
        """[CRUD function to delete a category record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete-category crud ...")
            with session() as transaction_session:
                obj: Category = (
                        transaction_session.query(Category)
                        .filter(Category.id == id)
                        .first()
                    )
                transaction_session.delete(obj)
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("Error while deleting from category table")
            return get_err_json_response(
            "Error while deleting from category table",
            e.args,
            501,
        )
