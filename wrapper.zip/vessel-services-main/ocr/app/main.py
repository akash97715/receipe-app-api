from fastapi import FastAPI

app = FastAPI()


@app.get("/health")
def health():
    return {"message": "I'm healthy"}

@app.get("/{any_path}")
def hello_world():
    return {"message": "Hello World"}