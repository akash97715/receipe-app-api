# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import abc
import json
import os
import logging
import uuid
import json
import datetime

import boto3

import requests

# legacy link based approach
AICORE_API_SERVER_HOST = os.environ.get("VESSEL_REGISRY_API_HOST", "localhost")
AICORE_API_SERVER_PORT = os.environ.get("VESSEL_REGISRY_API_PORT", "80")
aws_access_key_id = os.environ.get("DYNAMO_DB_AWS_ACCESS_KEY_ID", "access_key")
aws_secret_access_key = os.environ.get("DYNAMO_DB_AWS_SECRET_ACCESS_KEY", "secret_access_key")
aws_region = os.environ.get("Dynamo_AWS_REGION", "us-east-1")
dynamodb_table = os.environ.get("DYNAMO_DB_METERING_TABLE","" )

class ApiAccessorError(Exception):
    def __init__(self, message, error_code):
        super(ApiAccessorError, self).__init__(message)

        self.error_code = error_code

class UUIDEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, uuid.UUID):
            return obj.hex
        return json.JSONEncoder.default(self, obj)


# DynamoDB accessor that implements MeteringSvcDbAccessor protocol
class MeteringSvcDynamoDBAccessor():
    g_aicore_sess = None

    # Handle transient errors using exponential backoff with Jitter
    # Wait 2^i * 100 ms, on the i-th retry | wait 20 second per try maximum
    # (TODO: Move these values to Configuration)
    @staticmethod
    def get_db_session(force_reset=False):
        # VESSEL_DB_HOST env contain the DB host
        #

        try:
            session = boto3.Session(
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )
            MeteringSvcDynamoDBAccessor.g_aicore_sess = session.resource('dynamodb', region_name=aws_region)

            return MeteringSvcDynamoDBAccessor.g_aicore_sess
        except Exception as ex:
            MeteringSvcDynamoDBAccessor.g_aicore_sess = None
            logging.warning('Error in Opening a Dynamodb Connection. It will be Retried. %s', str(ex))
            raise


    @staticmethod
    def save_metering_svc_req(svc_req):
        try:
            aicore_sess = MeteringSvcDynamoDBAccessor.get_db_session()
            vendor_serial = {"otter": 1, "aws": 2, "azure": 3, "gcp": 4, "SYSTRAN": 5, "abbyy": 6, "VESSEL": 7}
            uom_serial = {"audio_duration": 1, "character_count": 2, "file_size_bytes": 3, "request_counts": 4,
                          "page_count": 5 , "total_tokens": 6}
            svc_req["vendor_id"] = vendor_serial.get(svc_req["vendor_id"], 0)
            logging.warn("statementcon4")
            svc_req["r_uom_id"] = uom_serial.get(svc_req["unit_of_measurement"], 0)
            logging.warn("statementcon5")
            logging.warn("statementcon6")


            svc = aicore_sess.Table(dynamodb_table)
            print("Metering DB is" , dynamodb_table)
            response = svc.put_item(
                Item={
                    'pk_id': svc_req["pk_id"],
                    'r_sv_id': svc_req['r_sv_id'],
                    'r_yr': svc_req['r_yr'],
                    'r_m':  svc_req['r_m'],
                    'r_d':  svc_req['r_d'],
                    'r_st_id': 1,

                    'r_svc_adapter_id': svc_req["vendor_id"],
                    'r_uom_id': int(svc_req["r_uom_id"]),
                    'r_arr_t': svc_req["r_arr_t"],
                    'api_key':  svc_req["api_key"],
                    'r_chnl_id': svc_req["r_chnl_id"],
                    'r_chnl_type_id': svc_req["r_chnl_type_id"],
                    'r_id': svc_req["r_id"],

                    'r_param_1': svc_req["r_param_1"],
                    'r_param_2': svc_req["r_param_2"],
                    'r_parent_wf_req_id': svc_req["r_parent_wf_req_id"],

                    'r_ret_t': svc_req["r_ret_t"],
                    'r_su_id': svc_req["r_su_id"],
                    'r_svc_op_type': svc_req["svc_op_type"],
                    'r_tt': str(svc_req["r_tt"]),
                    'r_uom_val': svc_req["r_uom_val"],
                    'r_user_id': svc_req["r_user_id"],

                    'raw_url': svc_req["raw_url"],

                    'rec_id': svc_req["rec_id"],

                    'rec_t': str(datetime.datetime.utcnow()),
                    'src_ip': 'NA',

                    'usecase_id': 'NA'

                }
            )
            print(response)
        except Exception as ex:
            logging.warn('Error occured in Vessel:MeteringSvcDynamoDBAccessor. %s', str(ex))
            return
