from fastapi import HTTPException

from .oauth2_as_accessor import Oauth2AsAccessor
import os
from functools import wraps
import asyncio
from .metering_dynamodb_accessor import MeteringSvcDynamoDBAccessor
import datetime
import uuid
import json
from .generic_topic_msg_producer import TopicMsgPublisher
import time
# from flask import Response
import hashlib
from Crypto import Random
from Crypto.Cipher import AES
from base64 import b64encode, b64decode

AES_SECRET_KEY = os.environ.get('AES_SECRET_KEY', '')
METERING_SQS_QUEUE = os.environ.get('METERING_SQS_QUEUE', '')
print("Queue is", METERING_SQS_QUEUE)
vendor_serial = {"otter": 1, "aws": 2, "azure": 3, "gcp": 4, "SYSTRAN": 5, "abbyy": 6, "VESSEL": 7}
uom_serial = {"audio_duration": 1, "character_count": 2, "file_size_bytes": 3, "request_counts": 4,
              "page_count": 5, "total_tokens": 6, "total_tokens_docinsight": 7}


class AESCipher(object):
    def __init__(self, key):
        self.block_size = AES.block_size
        self.key = hashlib.sha256(key.encode()).digest()

    def decrypt(self, encrypted_text):
        encrypted_text = b64decode(encrypted_text)
        iv = encrypted_text[:self.block_size]
        cipher = AES.new(self.key, AES.MODE_GCM, iv)
        plain_text = cipher.decrypt(encrypted_text[self.block_size:]).decode("utf-8")
        return self.__unpad(plain_text)

    @staticmethod
    def __unpad(plain_text):
        last_character = plain_text[len(plain_text) - 1:]
        return plain_text[:-ord(last_character)]


def metering(uom_val, url, headers, json_body, process_end_time, res):
    print(headers)
    print(json_body)
    req_arrival_time = headers['x_agw_request_time']
    req_arrival_time_utc = datetime.datetime.strptime(req_arrival_time[:-6], "%Y-%m-%dT%H:%M:%S.%f")

    print("req_arrival_time_utc", req_arrival_time_utc, str(req_arrival_time_utc))

    client_id = str(uuid.UUID(hex=headers['x-agw-client_id']))  # for r_su_id
    print("Client is:", client_id)
    client_id_split = client_id.split('-')[4]
    print("Client ID Split", client_id_split)
    access_token = client_id.replace(client_id_split, headers['x_agw_api_id'])  # for api_key
    print("Access Token which is the Api Key", access_token)

    metering_req = {}
    metering_req["r_tt"] = (process_end_time - req_arrival_time_utc).total_seconds()
    print(metering_req["r_tt"])
    metering_req["r_yr"] = req_arrival_time_utc.year
    metering_req['r_m'] = req_arrival_time_utc.month
    metering_req['r_d'] = req_arrival_time_utc.day
    metering_req["rec_id"] = str(uuid.uuid4())
    metering_req["api_key"] = access_token
    metering_req["pk_id"] = headers['x_agw_api_id'] + "#" + str(metering_req["r_yr"]) + "#" + str(
        metering_req["r_m"]) + "#" + str(metering_req["r_d"])
    metering_req["r_su_id"] = client_id
    # str(uuid.UUID(hex="6f90ab7409494cdfb67e09de2de63334"))
    # metering_req["r_sv_id"] = headers['x-correlation-id']
    metering_req["r_sv_id"] = headers['x_agw_api_id']  # this will go into Lambda (picks the value from Cache)
    metering_req["r_arr_t"] = str(req_arrival_time_utc)
    metering_req["vendor_id"] = 0
    metering_req["r_param_1"] = "NA"
    metering_req["r_param_2"] = "NA"
    metering_req["raw_url"] = str(url)
    metering_req["svc_op_type"] = str(url).split("/")[-1]
    metering_req["r_ret_t"] = str(process_end_time)
    metering_req['r_chnl_type_id'] = "NA"
    metering_req['r_chnl_id'] = 'NA'
    metering_req['r_user_id'] = 'NA'
    metering_req['r_parent_wf_req_id'] = 'NA'
    metering_req['r_id'] = str(uuid.uuid4())

    res_json = res.json()  # for uom 6
    print("Response json is ---", res_json)

    if uom_val == 2:

        if json_body:
            metering_req["r_uom_val"] = len(str(json_body))
            metering_req["unit_of_measurement"] = "character_count"
    elif uom_val == 4:
        # metering_obj = GenericMetering()
        # print("json_body[value]",json_body[value])
        if json_body:
            metering_req["r_uom_val"] = 1
            metering_req["unit_of_measurement"] = "request_counts"
    elif uom_val == 6:
        if json_body:
            if 'totalTokens' in res_json:
                print("OpenAI Response")
                metering_req["r_uom_val"] = res.totalTokens   # OpenAI response
                metering_req["r_param_1"] = json_body['engine']  # engine param in the OpenAI Request Body
                metering_req["vendor_id"] = vendor_serial['azure']  # Vendor ID Azure
            elif 'total_tokens' in res_json:  # key in Bedrock response
                print("Bedrock response")
                metering_req["r_uom_val"] = res.total_tokens  # Bedrock response
                metering_req["r_param_1"] = json_body['model']  # model param in the Bedrock Request Body
                metering_req["vendor_id"] = vendor_serial['aws']  # Vendor ID AWS
            else:
                raise HTTPException(status_code=400, detail=f"Error: Invalid operation")  # in case of any other error
            # if res.totalTokens:    # OpenAI response
            #     metering_req["r_uom_val"] = res.totalTokens
            #     metering_req["r_param_1"] = json_body['engine']  # engine param in the OpenAI Request Body
            # else:   # res.total_tokens: Bedrock response
            #     metering_req["r_uom_val"] = res.total_tokens   # Bedrock response
            #     metering_req["r_param_1"] = json_body['model']    # model param in the Bedrock Request Body
            metering_req["unit_of_measurement"] = "total_tokens"
            # metering_req["vendor_id"] = vendor_serial['azure']
            # metering_req["r_param_1"] = json_body['engine']  # engine param in the OpenAI Request Body
    elif uom_val == 7:
        if json_body:
            metering_req["r_uom_val"] = res.totaltokensllm + res.totaltokensembedding
            metering_req["unit_of_measurement"] = "total_tokens_docinsight"
            metering_req["vendor_id"] = vendor_serial['azure']
            embeddings_params = {'engine': json_body['embedding_engine'], 'totalTokens': res.totaltokensembedding}
            metering_req["r_param_1"] = json.dumps(embeddings_params)
            llm_params = {'engine': json_body['llm_engine'], 'totalTokens': res.totaltokensllm}
            metering_req["r_param_2"] = json.dumps(llm_params)
    elif uom_val == 8:
        if json_body:
            metering_req["r_uom_val"] = json_body["n"]
            metering_req["unit_of_measurement"] = "images_count"
            metering_req["r_param_1"] = "Dall-E"
            metering_req["r_param_2"] = json_body["size"]  # size of image requested
            metering_req["vendor_id"] = vendor_serial["azure"]
    print(metering_req)
    return metering_req


def async_token_validation_and_metering(uom=0):
    def decorator(f):
        @wraps(f)
        async def wrapper(request=None, *args, **kwargs):
            token = None
            flask_flag = False
            from fastapi import FastAPI, HTTPException
            # raise HTTPException(status_code=401, detail="Item not found")
            if token is None and request is not None and isinstance(request, dict) == False:
                try:
                    # encrypted_token = request.headers['authorization'].split()[-1]
                    # ae = AESCipher(AES_SECRET_KEY)
                    # token = ae.decrypt(encrypted_token)
                    # print("encrypted_token",encrypted_token)
                    token = request.headers['authorization'].split()[-1]
                    print(" fast api")
                except Exception as ex:
                    print(ex)
                    print("not a fast api")

            if not token and not flask_flag:  # throw error if no token provided
                print("invalid token")
                raise HTTPException(status_code=401, detail={"statusCode": 401, "statusDescription": "401 Unauthorized",
                                                             "error": "b_token not found."})
                return {
                    "statusCode": 401,
                    "statusDescription": "401 Unauthorized",
                    "headers": {
                        "Set-cookie": "cookies",
                        "Content-Type": "application/json"
                    },
                    'body': '{"error":"b_token not found."}'
                }

            elif not token and flask_flag:

                # r = Response(response='{"error":"b_token not found."}', status=401, mimetype="application/json")
                # r.headers["Content-Type"] = "application/json"
                raise HTTPException(status_code=401, detail={"statusCode": 401, "statusDescription": "401 Unauthorized",
                                                             "error": "b_token not found."})
                # return r

            response = Oauth2AsAccessor.validate_oauth2_token(token)
            print("testing", response)
            if response['active']:
                pass
            elif response['active'] == False and not flask_flag:
                raise HTTPException(status_code=401, detail={"statusCode": 401, "statusDescription": "401 Unauthorized",
                                                             "error": "b_token is invalid."})

                return {
                    "statusCode": 401,
                    "statusDescription": "401 Unauthorized",
                    "headers": {
                        "Set-cookie": "cookies",
                        "Content-Type": "application/json"
                    },
                    'body': '{"error":"b_token is invalid."}'
                }
            elif response['active'] == False and flask_flag:
                # r = Response(response='{"error":"b_token is invalid."}', status=401, mimetype="application/json")
                # r.headers["Content-Type"] = "application/json"
                raise HTTPException(status_code=401, detail={"statusCode": 401, "statusDescription": "401 Unauthorized",
                                                             "error": "b_token is invalid."})

                # return r

            if request:
                res = await f(request, *args, **kwargs)

            else:
                res = await f(*args, **kwargs)
            start = time.time()
            process_end_time = datetime.datetime.utcnow()
            try:
                json_body = await request.json()
            except Exception as e:
                print(e)
                json_body = 0

            # The response from the decorated function
            print("response is ", res)
            try:
                if isinstance(uom, list):
                    for uom_val in uom:
                        print(uom_val, "uom_val")

                        metering_req = metering(uom_val, request.url, request.headers, json_body, process_end_time, res)
                        # MeteringSvcDynamoDBAccessor.save_metering_svc_req(metering_req)
                        TopicMsgPublisher.send_msg_to_topic(METERING_SQS_QUEUE, json.dumps(metering_req))

                elif isinstance(uom, int):

                    print(uom, "uom")
                    if uom != 0:
                        # add function result as parameter
                        metering_req = metering(uom, request.url, request.headers, json_body, process_end_time, res)
                        # MeteringSvcDynamoDBAccessor.save_metering_svc_req(metering_req)
                        TopicMsgPublisher.send_msg_to_topic(METERING_SQS_QUEUE, json.dumps(metering_req))
                print("Metering time: ", time.time() - start)
            except Exception as ex:
                print(str(ex))

            return res

        return wrapper

    return decorator


def sync_token_validation_and_metering(uom=0):
    def decorator(f):
        @wraps(f)
        def wrapper(request=None, *args, **kwargs):
            token = None
            flask_flag = False
            if token is None and request is not None and isinstance(request, dict) == False:
                try:
                    # encrypted_token = request.headers['authorization'].split()[-1]
                    # ae = AESCipher(AES_SECRET_KEY)
                    # token = ae.decrypt(encrypted_token)
                    # print("encrypted_token",encrypted_token)
                    token = request.headers['authorization'].split()[-1]
                    print(" fast api")
                except Exception as ex:
                    print(ex)
                    print("not a fast api")
            elif token is None and request is not None and isinstance(request, dict):
                try:

                    print('args', args)
                    print(request['headers'])
                    if 'headers' in request and 'authorization' in request['headers']:
                        # encrypted_token = request['headers']['authorization'].split()[-1]
                        # ae = AESCipher(AES_SECRET_KEY)
                        # token = ae.decrypt(encrypted_token)
                        token = request['headers']['authorization'].split()[-1]
                    print("lambda")
                except Exception as ex:
                    print(ex)
                    print("not a lambda")
            elif token is None and request is None:

                try:
                    flask_flag = True
                    from flask import request as req
                    from flask import Response
                    print(req.headers)
                    # encrypted_token = req.headers['authorization'].split()[-1]
                    # ae = AESCipher(AES_SECRET_KEY)
                    # token = ae.decrypt(encrypted_token)
                    token = req.headers['authorization'].split()[-1]
                    print(" flask app")
                except Exception as ex:
                    print(ex)
                    print("not a flask app")

            if not token and not flask_flag:  # throw error if no token provided
                print("invalid token")
                return {
                    "statusCode": 401,
                    "statusDescription": "401 Unauthorized",
                    "headers": {
                        "Set-cookie": "cookies",
                        "Content-Type": "application/json"
                    },
                    'body': '{"error":"b_token not found."}'
                }

            elif not token and flask_flag:

                r = Response(response='{"error":"b_token not found."}', status=401, mimetype="application/json")
                r.headers["Content-Type"] = "application/json"
                return r

            response = Oauth2AsAccessor.validate_oauth2_token(token)
            print("testing", response)
            if response['active']:
                pass
            elif response['active'] == False and not flask_flag:
                return {
                    "statusCode": 401,
                    "statusDescription": "401 Unauthorized",
                    "headers": {
                        "Set-cookie": "cookies",
                        "Content-Type": "application/json"
                    },
                    'body': '{"error":"b_token is invalid."}'
                }
            elif response['active'] == False and flask_flag:
                r = Response(response='{"error":"b_token is invalid."}', status=401, mimetype="application/json")
                r.headers["Content-Type"] = "application/json"
                return r

            if request:
                res = f(request, *args, **kwargs)
            else:
                res = f(*args, **kwargs)
            start = time.time()
            process_end_time = datetime.datetime.utcnow()
            try:
                json_body = request.json()
            except Exception as e:
                print(e)
                json_body = 0

            if isinstance(uom, list):
                for uom_val in uom:
                    print(uom_val, "uom_val")

                    metering_req = metering(uom_val, request.url, request.headers, json_body, process_end_time)
                    # TopicMsgPublisher.send_msg_to_topic("https://vpce-07f14fc163915315f-d8tjijf1.sqs.us-east-1.vpce.amazonaws.com/555316523483/dev-metering-SQS-topic.fifo",json.dumps(metering_req))

            elif isinstance(uom, int):

                print(uom, "uom")
                if uom != 0:
                    metering_req = metering(uom, request.url, request.headers, json_body, process_end_time)
                    # TopicMsgPublisher.send_msg_to_topic("https://vpce-07f14fc163915315f-d8tjijf1.sqs.us-east-1.vpce.amazonaws.com/555316523483/dev-metering-SQS-topic.fifo",json.dumps(metering_req))

            return res

        return wrapper

    return decorator
