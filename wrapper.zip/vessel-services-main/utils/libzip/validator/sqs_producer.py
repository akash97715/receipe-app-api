import boto3
import os
import logging
import json
import uuid
from botocore.client import Config
import time

# storing only for temporary purpose. Later will go to aws secrets only
# secrets same as DB

aws_access_key_id=os.environ.get("DYNAMO_DB_AWS_ACCESS_KEY_ID", "")
aws_secret_access_key=os.environ.get("DYNAMO_DB_AWS_SECRET_ACCESS_KEY", "")
# aws_region=os.environ.get("AWS_REGION", "us-east-1")



class SQSProducer:
    sqs_sess = None
    time_to_wait=2  #if error occurs how many seconds we need to wait
    total_retry=3     #if error occurred how many times we rerun that function
    retry=total_retry
    
    @staticmethod
    def get_sqs_session():
        
        try:
            config = Config(connect_timeout=60, retries={'max_attempts': SQSProducer.total_retry})
            session = boto3.Session(
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )
            SQSProducer.sqs_sess = session.client('sqs', region_name="us-east-1",config=config)
            return SQSProducer.sqs_sess
        except Exception as ex:
            logging.warning('Error in Opening a Sqs Connection. . %s', str(ex))
            raise
            
            
    @staticmethod
    def get_queue_url(queue_name):
        print("printing from get_queue_url", queue_name)
        try:
            if os.environ.get(queue_name, None):
                return os.environ.get(queue_name, None)
            else:
                

                    #logging.warning("Url is valid")
                os.environ[queue_name]=queue_name
                return os.environ[queue_name]
                # else:
                #     #logging.warning("Invalid url")
                #     sqs_sess = SQSProducer.get_sqs_session()
                #     response = sqs_sess.get_queue_url(
                #         QueueName=queue_name,
                #     )
                #     SQSProducer.retry=SQSProducer.total_retry
                #     os.environ[queue_name]=response["QueueUrl"]
                #     return os.environ[queue_name]
           
                
        except Exception as ex:
            logging.warning('Error in get_queue_url in SQSProducer . %s', str(ex))
            logging.warning('Error in get_queue_url in SQSProducer . now retry value is %s', str(SQSProducer.retry))

            SQSProducer.sqs_sess=None
            if SQSProducer.retry:
                time.sleep(SQSProducer.time_to_wait)
                SQSProducer.retry=SQSProducer.retry-1
                return SQSProducer.get_queue_url(queue_name)
            else:
                logging.warning('Error in get_queue_url  in SQSProducer we trired maximum retries. %s', str(ex))
                raise
            #logging.warning('Error in get_queue_url of SQSProducer. %s', str(ex))
            #raise
    @staticmethod
    def send(queue_name, msg):
        try:
            messagegorupid=str(uuid.uuid4())
            sqs_sess = SQSProducer.get_sqs_session()
            print("SQS Session from send method" , sqs_sess)
            queue_url = SQSProducer.get_queue_url(queue_name)
            response = sqs_sess.send_message(
                QueueUrl = queue_url,
                MessageBody=msg.decode(),
                MessageGroupId=messagegorupid,
                MessageDeduplicationId= messagegorupid
            )
            SQSProducer.retry=SQSProducer.total_retry
            logging.warning(response)
        except Exception as ex:
            logging.warning('Error in send_message  in SQSProducer . %s', str(ex))
            logging.warning('Error in send_message in SQSProducer . now retry value is %s', str(SQSProducer.retry))

            SQSProducer.sqs_sess=None
            if SQSProducer.retry:
                time.sleep(SQSProducer.time_to_wait)

                SQSProducer.retry=SQSProducer.retry-1
                return SQSProducer.send(queue_name, msg)
            else:
                logging.warning('Error in send_message  in SQSProducer we trired maximum retries. %s', str(ex))
                raise
            #logging.warning('Error in send_message of SQSProducer. %s', str(ex))
            #raise
            
