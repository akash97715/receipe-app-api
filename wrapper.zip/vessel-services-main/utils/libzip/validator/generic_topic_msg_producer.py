# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import abc
import logging
import os
import json
import time
import threading
import signal




#3rd party
# from kafka import KafkaProducer

from .sqs_producer import SQSProducer

#KAFKA_BROKER_HOST = "{0}:9092".format(os.environ.get("GBIAICORE_QUEUE_IP", "localhost"))
KAFKA_BROKER_HOST = "{0}".format(os.environ.get("VESSEL_QUEUE_HOST", "localhost"))

        
#Produces messages to specified topic in highly scalable manner and sends them to relevant topics/queues for later processing.
#TODO: Have a config file packaged along with app that gives the defualt DB/QUEUE locations and can be overidden by container -e settings during docker run
class TopicMsgPublisher():
    
    my_topic_producer = None
    
    @staticmethod
    def get_topic_producer(sqs_or_kafka=0):
        #TODO: check if connection is live/working. IF NOT, reinitialize the conneciton
        if TopicMsgPublisher.my_topic_producer:
            return TopicMsgPublisher.my_topic_producer
        else:
            if sqs_or_kafka:
                TopicMsgPublisher.my_topic_producer = SQSProducer#KafkaProducer(bootstrap_servers= KAFKA_BROKER_HOST, batch_size =5)
            return TopicMsgPublisher.my_topic_producer
 

    @staticmethod
    def send_msg_to_topic(topic, msg_json):
        if '.fifo' in topic.strip().lower():
            sqs_or_kafka=1
        else:
            sqs_or_kafka=0
        producer = TopicMsgPublisher.get_topic_producer(sqs_or_kafka)
        #send the msg to a topic
        producer.send(topic, msg_json.encode('utf-8'))
        logging.warn('Published message: {0} to TOPIC {1}'.format(msg_json.encode('utf-8'), topic))

        #TODO: tweak the buffer so that msgs gets flushed in an optimized manner
        #p.flush()
