import logging
from app.commons.config import config


logging.basicConfig(
    level=config.LOG_LEVEL,
    format="%(asctime)s [%(levelname)s] - %(message)s",
    handlers=[logging.StreamHandler()],  # Display log messages in the console
)

logger = logging.getLogger(__name__)