import os
from typing import cast
from dotenv import load_dotenv
from pydantic_settings import BaseSettings

load_dotenv()

import os
 
db_username = os.getenv("DB_USERNAME", "null")
db_password = os.getenv("DB_PASSWORD", "null")
db_endpoint = os.getenv("DB_ENDPOINT", "null")
db_name = os.getenv("DB_NAME", "null")
 
SQLALCHEMY_DATABASE_URL = f"postgresql://{db_username}:{db_password}@{db_endpoint}:5432/{db_name}"
class Config(BaseSettings):
    RDS_URI: str = cast(str, os.getenv("RDS_URI", SQLALCHEMY_DATABASE_URL))
    DEV_MODE: bool = True
    PORT: int = 8000
    
    PINGFEDERATE_TOKEN_URL: str = cast(str, os.getenv("PINGFEDERATE_TOKEN_URL"))
    PINGFEDERATE_TOKEN_VALIDATION_URL: str = cast(str, os.getenv("PINGFEDERATE_TOKEN_VALIDATION_URL"))
    PINGFEDERATE_CLIENT_ID: str = cast(str, os.getenv("PINGFEDERATE_CLIENT_ID"))
    PINGFEDERATE_CLIENT_SECRET: str = cast(str, os.getenv("PINGFEDERATE_CLIENT_SECRET"))
    FORM_DATA_HEADER : dict =  {"Content-type": "application/x-www-form-urlencoded"}
    ALLOWED_GROUPS: str = cast(str, os.getenv("ALLOWED_GROUPS"))
    LOG_LEVEL: str =  cast(str, os.getenv("LOG_LEVEL", "ERROR"))
    class Config:
        case_sensitive = False

def get_allowed_origins(config: Config) -> list:
    origins = ["*"]
    return origins

config = Config()