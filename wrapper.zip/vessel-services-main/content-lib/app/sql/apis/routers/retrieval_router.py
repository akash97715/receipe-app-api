from fastapi import APIRouter,HTTPException
from app.logs.logger_config import logger
from app.commons.load_config import config
from app.commons.errors import get_err_json_response
from app.sql.controllers.ChunkMetadataController import ChunkMetadataController
from app.sql.controllers.ContentIndexController import ContentIndexController
from app.sql.controllers.ChatHistoryController import ChatHistoryController
from app.sql.helper.functions import get_output_source_doc,get_output_response_with_source
from app.sql.schemas.requests import ChatHistory,LLMRequest,LLMRequestWithChatHistory,CustomFiltersRequest,CustomFiltersLLMRequest
import json
from app.sql.crud.chunk_metadata_crud import CRUDChunkMetadata
from fastapi import Request
from app.sql.validator.decorators import async_token_validation_and_metering
from app.sql.dependencies.authorization.auth_decorator import auth_token_validation


retrieval_router = APIRouter(prefix=config["api_prefix"])

@retrieval_router.post(
    "/result/retrieval",
    status_code=200,
    tags=["Retrieval"],
    description="get Document Sources by chunk metadata",
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_doc_sources_by_chunk_metadata(request : Request,llm_request: LLMRequest):
    try:
        llm_request = llm_request.__dict__
        content_index_name = ContentIndexController().get_content_index_name_by_id(llm_request["content_index_id"])
        metadata={}
        if llm_request["content_metadata_id"] >=0:
            obj = ChunkMetadataController().get_chunk_by_metadata_id(llm_request["content_metadata_id"])
            chunk_metadata = ChunkMetadataController().extract_chunk_metadata(obj)
            metadata = {
                "md5": [chunk_metadata["md5"]],
                "section": [chunk_metadata["section"]]
            }
        elif llm_request["document_id"] >=0 :
            (md5,content_index_id) = CRUDChunkMetadata().get_md5_by_doc_id(document_id=llm_request["document_id"])
            metadata = {
                "md5": [md5]
            }
        output = get_output_source_doc(query=llm_request["prompt"],filter=metadata,index=content_index_name)
        for entry in output:
            entry["metadata"] = json.loads(entry["metadata"])
        return output
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@retrieval_router.post(
    "/result/conversation",
    status_code=200,
    tags=["Retrieval"],
    description="get result from LLM based on document source from retrieval step"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_answer_from_llm(request:Request,llm_request: LLMRequestWithChatHistory):
    try:
        llm_request = llm_request.__dict__
        content_index_name = ContentIndexController().get_content_index_name_by_id(llm_request["content_index_id"])
        metadata={}
        if llm_request["content_metadata_id"] >=0:
            obj = ChunkMetadataController().get_chunk_by_metadata_id(llm_request["content_metadata_id"])
            chunk_metadata = ChunkMetadataController().extract_chunk_metadata(obj)
            metadata = {
                "md5": [chunk_metadata["md5"]],
                "section": [chunk_metadata["section"]]
            }
        elif llm_request["document_id"] >=0 :
            (md5,content_index_id) = CRUDChunkMetadata().get_md5_by_doc_id(document_id=llm_request["document_id"])
            metadata = {
                "md5": [md5]
            }
        chat_history_controller = ChatHistoryController(llm_request["chat_history"])
        chat_history = chat_history_controller.preprocess()
        output = get_output_response_with_source(query=llm_request["prompt"],filter=metadata,index=content_index_name,chat_history=chat_history)
        for entry in output["source_documents"]:
            entry["metadata"] = json.loads(entry["metadata"])
        return output
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@retrieval_router.post(
    "/result/retrieval/custom_filter",
    status_code=200,
    tags=["Retrieval"],
    description="get Result by custom metadata filter",
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_result_by_custom_filters(request : Request,filter_request: CustomFiltersRequest):
    try:
        filter_request = filter_request.__dict__
        content_index_name = ContentIndexController().get_content_index_name_by_id(filter_request["content_index_id"])
        metadata = {}
        if filter_request["metadata_filters"]:
            metadata = filter_request["metadata_filters"]
        if filter_request["documents"]:
            for doc_id in filter_request["documents"]:
                (md5,_) = CRUDChunkMetadata().get_md5_by_doc_id(document_id=doc_id)
                if "md5" not in metadata.keys(): 
                    metadata["md5"] = [] 
                metadata["md5"].append(md5)
        output = get_output_source_doc(query=filter_request["prompt"],filter=metadata,index=content_index_name)
        return output
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@retrieval_router.post(
    "/result/conversation/custom_filter",
    status_code=200,
    tags=["Retrieval"],
    description="get result from LLM based on custom metadata filter",
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_conversation_by_custom_filters(request : Request,filter_request: CustomFiltersLLMRequest):
    try:
        filter_request = filter_request.__dict__
        content_index_name = ContentIndexController().get_content_index_name_by_id(filter_request["content_index_id"])
        metadata = {}
        if filter_request["metadata_filters"]:
            metadata = filter_request["metadata_filters"]
        if filter_request["documents"]:
            for doc_id in filter_request["documents"]:
                (md5,_) = CRUDChunkMetadata().get_md5_by_doc_id(document_id=doc_id)
                if "md5" not in metadata.keys(): 
                    metadata["md5"] = [] 
                metadata["md5"].append(md5)
        chat_history_controller = ChatHistoryController(filter_request["chat_history"])
        chat_history = chat_history_controller.preprocess()
        output = get_output_response_with_source(query=filter_request["prompt"],filter=metadata,index=content_index_name,chat_history=chat_history)
        return output
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")