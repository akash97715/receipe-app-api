from fastapi import APIRouter
from app.logs.logger_config import logger
from app.commons.load_config import config
from app.sql.controllers.DocumentController import DocumentController
from fastapi import UploadFile,File
from app.commons.exceptions import FileException,BadRequestException
import json
from app.commons.constants import cust_separators_list,no_of_files
from app.commons.errors import get_err_json_response
from fastapi import Request
from app.sql.validator.decorators import async_token_validation_and_metering
from app.sql.dependencies.authorization.auth_decorator import auth_token_validation


document_router = APIRouter(prefix=config["api_prefix"])


@document_router.get(
    "/document/{content_index_id}",
    status_code=200,
    tags=["Document"],
    description="GET Document by context_id"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_documents_by_content_index(request : Request,content_index_id: int):
    """
    API to Get all documents for a content index id 

    Agrs:
        (int):content_index_id

    Returns:
        (dict): documents matching the criteria.
    """
    documents = DocumentController().get_documents_by_content_index_controller(context_id = content_index_id)
    return documents

@document_router.post(
    "/document/upload",
    status_code=200,
    tags=["Document"],
    description="Upload Document for a context index id"
)
@async_token_validation_and_metering(uom=3)
@auth_token_validation()
async def upload_document(request : Request, content_index_id: int,
                            doc_source: str,
                            cust_md: str=None,
                            files:list[UploadFile] = File(...)):
    """
    API to Upload documents.

    Agrs:
        (int):content_index_id
        (str):doc_source
        request(list[files]): [actual doc files to be uploaded]

    Raises:
        error: [Error raised from router layer]

    Returns:
        [dict]: documents details success

    """
    try:
        logger.info("router executing...")

        if(len(files) > no_of_files or len(files) < 1):
            raise FileException(f"No of files sould be less than {no_of_files}")

        upload_doc_request = {
            "content_index_id": content_index_id,
            "doc_source": doc_source,
            "cust_separators": cust_separators_list,
            "cust_md": cust_md 
        }
        upload_doc_response =  DocumentController().upload_document_controller(request=upload_doc_request,files = files)
        return upload_doc_response
    
    except FileException as e:
        logger.error("error related to files")
        return get_err_json_response(
        f"Error in doc router:{str(e)}",
        e.args,
        400,
        )
    except BadRequestException as e:
        logger.error("error due to invalid cust_seperators value.")
        return get_err_json_response(
        f"Error in doc router: {str(e)}",
        e.args,
        400,
        )

@document_router.delete(
    "/document/{document_id}",
    status_code=200,
    tags=["Document"],
    description="Delete document by id"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def delete_document(request : Request,
    document_id: int
):
    """
    API to delete document by id.

    Agrs:
        (int):document_id

    Raises:
        error: [Error raised from router layer]

    Returns:
        {}:  success response

    """
    logger.info("executing delete document router ...")
    obj = DocumentController().delete_document_controller(document_id= document_id)
    return obj

@document_router.post(
    "/chunks/upload",
    status_code=200,
    tags=["Chunk Metadata"],
    description="Upload chunks in json file  for a context index id"
)
@async_token_validation_and_metering(uom=3)
@auth_token_validation()
async def upload_document(request : Request,
                          content_index_id: int,
                            doc_source: str,
                            md5: str,
                            file:UploadFile = File(...)):
    """
    API to Upload chunks in json file.

    Agrs:
        (int):content_index_id
        (str):doc_source
        request(files): [json file to be uploaded]

    Raises:
        error: [Error raised from router layer]

    Returns:
        [dict]: json file upload success details

    """
    try:
        logger.info("router executing...")

        upload_doc_request = {
            "content_index_id": content_index_id,
            "doc_source": doc_source,
            "md5": md5
        }
        upload_doc_response =  DocumentController().upload_json_controller(request=upload_doc_request,file = file)
        return upload_doc_response
    
    except FileException as e:
        logger.error("error related to file type")
        return get_err_json_response(
        f"Error in doc router:{str(e)}",
        e.args,
        400,
        )
    except BadRequestException as e:
        logger.error("error due to invalid cust_seperators value.")
        return get_err_json_response(
        f"Error in doc router: {str(e)}",
        e.args,
        400,
        )