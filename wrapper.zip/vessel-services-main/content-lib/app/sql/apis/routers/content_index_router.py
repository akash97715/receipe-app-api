from app.logs.logger_config import logger
from app.commons.load_config import config
from app.sql.schemas.responses import (
    Status,
    HealthCheckResponse,
    ResourceCreationResponse
)
from app.sql.schemas.requests import (
    ContentIndex,
    ContentSplitting,
    DocumentRequest
)
from app.sql.orm_models.models import (
    ContentIndexORM,
    ContentSplittingORM,
    DocumentORM
)
from typing import Optional, List
from fastapi.responses import JSONResponse
from app.sql.controllers.ContentIndexController import ContentIndexController
from app.sql.controllers.ContentSplittingController import ContentSplittingController
from app.sql.controllers.ChunkMetadataController import ChunkMetadataController
from fastapi import APIRouter,Depends,HTTPException,File,UploadFile
from fastapi import Request
from app.sql.validator.decorators import async_token_validation_and_metering
from app.sql.dependencies.authorization.auth_decorator import auth_token_validation

from app.sql.schemas.requests import (
    LengthType,ChunkAlgoType,ChunkMetadataResponse
)
from app.commons.errors import get_err_json_response

content_index_router = APIRouter(prefix=config["api_prefix"])


@content_index_router.post(
    "/content",
    status_code=201,
    tags=["Content indexing"],
    description="Creates Content Index and Splitting",
    response_model=ResourceCreationResponse,
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_content_index(
    request : Request,
    index_request: ContentIndex
):
    clientid= request.headers.get("x-agw-client_id") if request.headers.get("x-agw-client_id") is not None else None
    logger.info(f"Tenant Id - {clientid}")
    if not clientid:
        raise HTTPException(status_code=404, detail="Invalid Client id")
    content_index_dict = index_request.__dict__
    content_index_name = content_index_dict["content_index_name"]
    is_name_valid,msg = ContentIndexController().is_valid_opensearch_index_name(index_name=content_index_name)
    if not is_name_valid:
        raise HTTPException(status_code=400, detail=f"Error: {msg}")
    content_index_by_name = ContentIndexController().get_content_index_by_name(content_index_dict["content_index_name"]) 
    if(content_index_by_name!=None):
        content_index_obj = content_index_by_name
        message = "Content index already created"
    else:
        content_splitting_data = content_index_dict.pop("content_splitting_metadata")
        if content_splitting_data==None:
            default_filters = {
                "chunk_size": 1000,
                "chunk_overlap": 10,
                "chunking_algorithm": "recursive",
                "split_document_by": [
                    "tokens"
                ],
                "length": "tokens"
            }
            content_splitting_data = ContentSplitting(**default_filters)
        content_index_obj = ContentIndexController().create_content_index_controller(index_request)
        _ = ContentSplittingController().create_content_splitting_controller(content_splitting_data,content_index_obj["content_index_id"])
        message = "Content index created successfully"
        _ = ContentIndexController().create_client_content_mapping_controller(client_id = clientid, content_id = content_index_obj["content_index_id"])
    return ResourceCreationResponse(
        status=Status.success,
        message=message,
        resource_id=str(content_index_obj["content_index_id"])
    )

@content_index_router.get(
    "/content/default_filters",
    status_code=200,
    tags=["Content indexing"],
    description="GET Default Filters available"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_default_filters(request : Request):
    try:
        default_filters ={
            "content_splitting_metadata": {
                "chunk_size": 1000,
                "chunk_overlap": 10,
                "chunking_algorithm": "recursive",
                "split_document_by": [
                    "tokens"
                ],
                "length": "tokens"
            }
        }
        return default_filters
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@content_index_router.get(
    "/content",
    status_code=200,
    tags=["Content indexing"],
    description="GET Content Index and Splitting"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_all_content_index(request : Request):
    try:
        clientid= request.headers.get("x-agw-client_id") if request.headers.get("x-agw-client_id") is not None else None
        logger.info(f"Tenant Id - {clientid}")
        if not clientid:
            message = "Invalid Client Id"
            return HTTPException(status_code=404, detail=message)
        content_index_list = ContentIndexController().get_all_content_index(clientid)
        return content_index_list
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@content_index_router.get(
    "/content/{content_index_id}",
    status_code=200,
    tags=["Content indexing"],
    description="GET Content Index and Splitting by content_index_id"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_content_index_by_id(request : Request,
    content_index_id: int
):
    try: 
        content_index = ContentIndexController().get_content_index_by_id(content_index_id)
        if content_index is None:
                raise HTTPException(status_code=404, detail=f"Error: resource not found by content_index_id:{content_index_id}")
        content_splitting_metadata = ContentSplittingController().get_content_splitting_by_content_index_id(content_index["content_index_id"])
        content_index["content_splitting_metadata"] = content_splitting_metadata
        return content_index
    except HTTPException as e:
        return JSONResponse(
            status_code=e.status_code,
            content={
                "status_code": e.status_code,
                "status": "error",
                "message": e.detail,
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

@content_index_router.get(
    "/content_by_index",
    status_code=200,
    tags=["Content indexing"],
    description="GET content index by index type"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_content_index_by_index_type(request : Request,
    content_index_type: str,
):
    try:
        if content_index_type != "private" and content_index_type != "shared":
                raise HTTPException(status_code=400, detail=f"Error: expected content_index_type to be either private or shared.")
        content_index_entries = ContentIndexController().get_content_index_by_type(content_index_type)
        return content_index_entries
    except HTTPException as e:
        return JSONResponse(
            status_code=e.status_code,
            content={
                "status_code": e.status_code,
                "status": "error",
                "message": e.detail,
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
    
@content_index_router.get(
    "/content/document/",
    status_code=200,
    tags=["Chunk Metadata"],
    description="GET chunk metadata by content_index and document",
    response_model=List[ChunkMetadataResponse]
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_chunk_metadata(request : Request,
    content_index_id: int,
    document_id: int,
):
    obj = ChunkMetadataController().get_chunk_metadata(content_index_id,document_id)
    return obj

@content_index_router.get(
    "/enums",
    status_code=200,
    tags=["Get Enums"],
    description="GET Enums"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def get_enums(request : Request,key: str):
    try:
        # Fetch the data from the enums file
        enums = {
            "models": ChunkAlgoType._member_names_,
            "length": LengthType._member_names_
        }
        if key=="models": return enums["models"]
        if key=="length": return enums["length"]
        return JSONResponse(
            status_code=400,
            content={
                "status_code": 400,
                "status": "error",
                "message": f"enum_type: {key} is unknown, available value of key is models or length.",
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
    

@content_index_router.delete(
    "/content/{content_index_name}",
    status_code=200,
    tags=["Content indexing"],
    description="Delete content index by name"
)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def delete_content_index(request : Request,
    content_index_name: str
):
    """
    API to delete content index .

    Agrs:
        (str):content_index_name

    Raises:
        error: [Error raised from router layer]

    Returns:
        {}:  success response

    """
    logger.info("executing delete content router ...")
    obj = ContentIndexController().delete_content_index_controller(content_index_name= content_index_name)
    return obj

    