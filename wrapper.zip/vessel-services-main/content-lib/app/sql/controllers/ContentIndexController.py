from app.sql.schemas.responses import ResourceCreationResponse,Status
from app.sql.crud.contentindex_crud import CRUDContentIndex
from app.sql.crud.clientcontent_crud import CRUDContentContentMapping
from app.logs.logger_config import logger
from sqlalchemy import func
from app.commons.errors import get_err_json_response
from app.sql.helper.functions import delete_index
import re
import json

class ContentIndexController:
    def __init__(self):
        self.CRUDContentIndex = CRUDContentIndex()
        self.CRUDContentContentMapping = CRUDContentContentMapping()

    def is_valid_opensearch_index_name(self,index_name):
        if not index_name.islower():
            return (False,"index name should be in lower case")    
        if index_name.startswith('_') or index_name.startswith('-'):
            return (False,'index name should not startswith "_" or "-" ')
        invalid_chars = r'[:, "*+/\|?#><]'
        if re.search(invalid_chars, index_name):
            return (False,'invalid character allowed characters are  "_" or "-" ')
        if ' ' in index_name or ',' in index_name:
            return (False,'invalid character allowed characters are  "_" or "-" ')
        return (True,"success")
    
    def create_content_index_controller(self, request):
        content_index_data = request.__dict__ 
        content_index_data["meta_tags"] = json.dumps(content_index_data["meta_tags"])
        content_index_data["created_date"] = func.now()
        content_index_data["last_modified_date"] = func.now()
        content_index_data["content_status"] = "updated"
        content_index_data["last_modified_by"] = content_index_data["nt_id"]
        content_index_data["created_by"] = content_index_data["nt_id"]
        content_res =  self.CRUDContentIndex.create(**content_index_data)
        return content_res
    
    def get_content_index_by_name(self,content_index_name):
        return self.CRUDContentIndex.get_by_content_index_name(content_index_name)

    def get_all_content_index(self, client_id = None):
        all_content_index = self.CRUDContentIndex.get_all_content_index()
        client_content_ids = self.CRUDContentContentMapping.get_client_content_by_client_id(client_id=client_id)
        filtered_content_index = []
        for content_index in all_content_index:
            if content_index.content_index_id in client_content_ids:
                filtered_content_index.append(content_index)
        return filtered_content_index
    
    def get_content_index_by_type(self,content_index_type):
        return self.CRUDContentIndex.get_content_indexes_by_index_type(content_index_type)
    
    def get_content_index_name_by_id(self,content_index_id):
        return self.CRUDContentIndex.get_name_by_id(content_index_id)
    
    def get_content_index_by_id(self,content_index_id):
        return self.CRUDContentIndex.get_content_index_by_id(content_index_id)
    
    def create_client_content_mapping_controller(self, client_id, content_id):
        client_content_dict = {
            "client_id" : client_id,
            "content_id" : content_id
        }
        return self.CRUDContentContentMapping.create(**client_content_dict)
    
    def delete_content_index_controller(self, content_index_name):
        """[Controller to delete content-index and all related docs by name]

        Args:
            content_index_name (str)): The name of the content index .

        Returns :
            (str) : Success message

        Raises:
            error: [Error returned from controller layer]
        """
        try:
            content_index = self.CRUDContentIndex.get_by_content_index_name(content_index_name)
            logger.info("executing delete content controller...")
            logger.info("calling ml delete index function from functions.py...")
            status = delete_index(index= content_index_name)
            print(status)
            if status == True:
                logger.info("calling crud content index ...")
                self.CRUDContentIndex.delete_by_name(content_index_name)
                self.CRUDContentContentMapping.delete_by_content_index_id(content_index["content_index_id"])
                return ResourceCreationResponse(
                        status=Status.success,
                        message= "Content index successfully deleted!",
                        resource_id= str(content_index_name)
                    )
            else:
                return ResourceCreationResponse(
                        status=Status.failure,
                        message= "Content index deletion from vector db unsuccessful!",
                        resource_id= str(content_index_name)
                    )

        except Exception as e:
            logger.error("Error at delete content index controller")
            return get_err_json_response(
            f"Error in content index controller: {str(e)}",
            e.args,
            501,
            )