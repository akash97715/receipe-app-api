from app.sql.crud.contentsplitting_crud import CRUDContentSplitting
from app.logs.logger_config import logger
from app.commons.constants import split_by
from app.commons.exceptions import BadRequestException
from app.commons.errors import get_err_json_response

class ContentSplittingController:
    def __init__(self):
        self.CRUDContentSplitting = CRUDContentSplitting()

    def get_content_splitting_by_content_index_id(self,content_index_id):
        try:
            obj = self.CRUDContentSplitting.get_content_splitting_by_context_id(content_index_id)
            return obj
        except Exception as e:
            logger.error("error in create content splitting controller.")
            return get_err_json_response(
            "Error in content splitting controller",
            e.args,
            501,
            )
    def create_content_splitting_controller(self, request,content_index_id):
        try:
            content_splitting_data = request.__dict__ 
            content_splitting_data["split_document_by"] = ",".join(content_splitting_data["split_document_by"])
            content_splitting_data["content_index_id"] = content_index_id

            if content_splitting_data["split_document_by"] not in split_by:
                raise BadRequestException(f'split_document_by should be "tokens" or "characters" only.')
            if content_splitting_data["chunk_size"] < content_splitting_data["chunk_overlap"]:
                raise BadRequestException("chunk size should be greater than overlap.")

            content_res =  self.CRUDContentSplitting.create(**content_splitting_data)
            return content_res
        
        except BadRequestException as e:
            logger.error("error due to split-document-by in create content splitting controller.")
            return get_err_json_response(
            "Error in content splitting controller",
            e.args,
            400,
            )
        except Exception as e:
            logger.error("error in create content splitting controller.")
            return get_err_json_response(
            "Error in content splitting controller",
            e.args,
            501,
            )