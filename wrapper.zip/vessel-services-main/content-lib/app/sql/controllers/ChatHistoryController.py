from app.sql.schemas.requests import ChatStructure

class ChatHistoryController:
    def __init__(self, _chat_history):
        self.chat_history = _chat_history

    def preprocess(self):
        result = []
        for chat in self.chat_history:
            result.append((chat.user_query, chat.bot))
        return result
