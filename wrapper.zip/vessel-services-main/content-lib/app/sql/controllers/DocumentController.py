from app.sql.crud.document_crud import CRUDDocument
from app.sql.crud.contentsplitting_crud import CRUDContentSplitting
from app.sql.crud.contentindex_crud import CRUDContentIndex
from app.logs.logger_config import logger
from sqlalchemy import func
from app.commons.exceptions import ResourceNotFound,BadRequestException
from app.commons.errors import get_err_json_response
from app.sql.helper.functions import *
from app.sql.crud.chunk_metadata_crud import CRUDChunkMetadata
from app.sql.schemas.enums import ChunkType, DocType
from app.sql.schemas.responses import ResourceCreationResponse, Status
import json

class DocumentController:
    def __init__(self):
        self.CRUDDocument = CRUDDocument()
        self.CRUDContentSplitting = CRUDContentSplitting()
        self.CRUDContentIndex = CRUDContentIndex()
        self.CRUDChunkMetadata = CRUDChunkMetadata()

    def get_all_document_controller(self):
        """[Controller to get all documents]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [list]: [list of all the  documents in the system]
        """
        logger.info("executing get-all-Document-controller ...")
        return self.CRUDDocument.read_all()
    
    def get_documents_by_content_index_controller(self, context_id: int):
        """[Controller to get all documents by context id]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [list]: [list of all the  documents with given context id]
        """
        logger.info("executing get_documents_by_content_index ...")
        return self.CRUDDocument.get_documents_by_content_index(context_id)

    def create_document_controller(self, request):
        """[Controller to register new document]

        Args:
            request ([dict]): [create new document request]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: documents details
        """
        logger.info("executing create-Document-controller ...")
        document_request = request.__dict__
        return self.CRUDDocument.create(**document_request)
    

    def delete_document_controller(self, document_id: int):
        """[Get document Details]

        Args:
            documentid (int)): [document_id of the document]

        Returns:
            [dict]: [success response]
        """
        logger.info("executing delete-document-controller ...")
        logger.info("extracting md5 for document: calling get-md chunk crud...")
        (md5,content_index_id) = self.CRUDChunkMetadata.get_md5_by_doc_id(document_id=document_id)
        content_index_name = self.CRUDContentIndex.get_name_by_id(content_index_id)
        logger.info("calling ml delete index function from functions.py...")
        status = delete_doc(md5=md5,index=content_index_name)
        if status == True:
            logger.info("calling crud delete document ...")
            self.CRUDDocument.delete(id=document_id)
            return ResourceCreationResponse(
                            status=Status.success,
                            message= "Doc successfully deleted!",
                            resource_id= str(document_id)
                        )
        else:
            return ResourceCreationResponse(
                    status=Status.failure,
                    message= "document deletion from open-search db unsuccessful!",
                    resource_id= str(document_id)
                )

    def upload_document_controller(self,request,files):
        """[Controller to upload a new document for a context id]

        Args:
            request ([dict]): [upload new document request]
            request(list[files]): [actual doc files to be uploaded]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: documents details
        """
        try:

            logger.info("executing upload-document-controller ...")
            splitting_obj = self.CRUDContentSplitting.get_content_splitting_by_context_id(content_index_id=request["content_index_id"])
            if splitting_obj is None:
                raise ResourceNotFound("content splitting data for given id not found.")

            document_id_list = []
            for file in files:
                logger.info("detecting file type ..")
                file_type = (file.filename.rsplit(".",1)[-1]).upper()   
                if file_type != "PDF" and file_type != "DOCX" and file_type != "XLSX":
                    raise FileException("Doc Type should be pdf or word or excel only.")

                if file_type == "PDF" :
                    doc_type = DocType.PDF
                elif file_type == "XLSX" :
                    doc_type = DocType.XLSX
                else:
                    doc_type = DocType.WORD

                logger.info("calling ml process file function...")
                if not request["cust_md"]:
                    cust_md = {}
                else:
                    cust_md = json.loads(request["cust_md"])
                page_content,metadata = process_file(file=file,
                                                    cust_md=cust_md,cust_separators=request["cust_separators"],
                                                    split_by=splitting_obj.split_document_by,
                                                    chunk_size=splitting_obj.chunk_size,
                                                    overlap=splitting_obj.chunk_overlap)
                
                md5 = metadata[0]["md5"]
                # print(md5)
                duplicate_check = self.CRUDDocument.duplicate_check(md5 = md5, content_index_id= request["content_index_id"])
                if(duplicate_check):    
                    document_id_list.append(duplicate_check.__dict__["document_id"])
                    continue    

                logger.info("calling content index crud ....") 
                content_index_name  = self.CRUDContentIndex.get_name_by_id(content_index_id=request["content_index_id"])
                logger.info("calling ml upload file to os funtion ...")
                file_upload_response = upload_file_to_os(index = content_index_name,
                                                            page_content = page_content,
                                                            metadata = metadata)
                
                logger.info("calling create doc crud ...")
                document_request = {
                    "file_name": file.filename,
                    "doc_type": doc_type,
                    "doc_source": request["doc_source"],
                    "content_index_id": request["content_index_id"],
                    "md5": md5
                }
                document_obj = self.CRUDDocument.create(**document_request)
                document_id_list.append(document_obj["document_id"])
            
                logger.info("calling create chunk metadata crud...")
                for data in metadata:
                    chunk_request = {
                        "chunk_metadata" : str(data),
                        "chunk_type" : ChunkType.text,
                        "content_index_id" : request["content_index_id"],
                        "document_id" : document_obj["document_id"],
                        "created_at": func.now()
                    }
                    chunk_response = self.CRUDChunkMetadata.create(**chunk_request)

            logger.info("execution done...")

            return ResourceCreationResponse(
                status=Status.success,
                message= "Document Upload Successful !",
                resource_id= str(document_id_list)
            )
        
        except FileException as e:
            logger.error("error due to type of doc")
            return get_err_json_response(
            f"Error in doc controller: {str(e)}",
            e.args,
            400,
        )   
        except BadRequestException as e:
            logger.error("error due to upload of same doc again")
            return get_err_json_response(
            f"Error in doc controller: {str(e)}",
            e.args,
            400,
        )      
        except ResourceNotFound as e:
            logger.error("error in doc controller for upload doc")
            return get_err_json_response(
            f"Error in doc controller: {str(e)}",
            e.args,
            404,
        )
        except Exception as e:
            logger.error("error in doc controller for upload doc")
            return get_err_json_response(
            f"Error in doc controller: {str(e)}",
            e.args,
            501,
        )

    def upload_json_controller(self,request,file):
        """[Controller to upload a new json file for a context id]

        Args:
            request ([dict]): [upload new document request]
            request(file): [json file having chunks to be uploaded]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: documents details
        """
        try:
            logger.info("executing upload-json-controller ...")

            logger.info("detecting file type ..")
            file_type = (file.filename.rsplit(".",1)[-1]).upper()   
            if file_type != "JSON":
                raise FileException("File Type should be json only.")
            doc_type = DocType.JSON

            is_name_valid,msg =is_valid_opensearch_index_name(index_name=request["md5"])
            if not is_name_valid:
                raise BadRequestException(f"Error: {msg}")
            
            duplicate_check = self.CRUDDocument.duplicate_check(md5= request["md5"], content_index_id= request["content_index_id"])
            if(duplicate_check == True):
                raise BadRequestException(f'Duplicate file found in same index: {file.filename}')   

            logger.info("calling extract json data function...")
            page_content,metadata = self.CRUDChunkMetadata.extract_json_data(md5=request["md5"],file=file)
            # print(page_content,metadata)

            logger.info("calling content index crud ....") 
            content_index_name  = self.CRUDContentIndex.get_name_by_id(content_index_id=request["content_index_id"])
            logger.info("calling ml upload file to os funtion ...")
            chunk_upload_response = upload_file_to_os(index = content_index_name,
                                                        page_content = page_content,
                                                        metadata = metadata)
            
            logger.info("calling create doc crud ...")
            document_request = {
                "file_name": file.filename,
                "doc_type": doc_type,
                "doc_source": request["doc_source"],
                "content_index_id": request["content_index_id"],
                "md5": request["md5"]
            }
            document_obj = self.CRUDDocument.create(**document_request)
            
            logger.info("calling create chunk metadata crud...")
            for data in metadata:
                chunk_request = {
                    "chunk_metadata" : str(data),
                    "chunk_type" : ChunkType.text,
                    "content_index_id" : request["content_index_id"],
                    "document_id" : document_obj["document_id"],
                    "created_at": func.now()
                }
                chunk_response = self.CRUDChunkMetadata.create(**chunk_request)

            logger.info("execution done...")

            return ResourceCreationResponse(
                status=Status.success,
                message= "Json Upload Successful !",
                resource_id= str(document_obj["document_id"])
            )
        
        except FileException as e:
            logger.error("error due to type of doc")
            return get_err_json_response(
            f"Error in doc controller: {str(e)}",
            e.args,
            400,
        )    
        except BadRequestException as e:
            logger.error("error due to absence of md5/duplicate md5 in metadata")
            return get_err_json_response(
            f"Error in doc controller: {str(e)}",
            e.args,
            400,
        )         
        except Exception as e:
            logger.error("error in doc controller for upload json")
            return get_err_json_response(
            f"Error in doc controller: {str(e)}",
            e.args,
            501,
        )