from pydantic import BaseModel
from typing import List, Optional,Union
from datetime import datetime
from fastapi import UploadFile,File
from app.sql.schemas.enums import IndexTypeEnum,ContentStatus,LengthType,ChunkAlgoType,DocType

class ContentSplitting(BaseModel):
    chunk_size: int
    chunk_overlap: int
    chunking_algorithm: ChunkAlgoType
    split_document_by: List[str]
    length: LengthType

class ContentIndex(BaseModel):
    nt_id: str
    index_type: IndexTypeEnum
    content_index_name: str
    content_description: Optional[str]=""
    meta_tags: Optional[List[str]]=[]
    content_splitting_metadata : Optional[ContentSplitting]=None

class DocumentRequest(BaseModel):
    doc_type: DocType 
    doc_source: str
    file_name: str
    content_index_id: int

class Citation(BaseModel):
    documentName: str
    page: Union[int, str]
    section: str

class ChatStructure(BaseModel):
    user_query: str
    bot: str
    citation: List[Citation]
    counter: int

class ChatHistory(BaseModel):
    chat_history: List[ChatStructure]

class DocumentUploadSchema(BaseModel):
    doc_type: DocType
    doc_source: str
    content_index_id: int
    cust_md: Optional[dict]
    # files: list[UploadFile] = File(...)

class LLMRequest(BaseModel):
    prompt: str
    content_index_id: int
    content_metadata_id: Optional[int]
    document_id: Optional[int]

class LLMRequestWithChatHistory(BaseModel):
    prompt: str
    content_index_id: int
    content_metadata_id: Optional[int]
    chat_history: List[ChatStructure]
    document_id: Optional[int]

class ChunkMetadataResponse(BaseModel):
    section: str
    content_metadata_id: int

class CustomFiltersRequest(BaseModel):
    content_index_id: int
    prompt: str
    metadata_filters : Optional[dict] = None
    documents: Optional[List[int]] = None

class CustomFiltersLLMRequest(BaseModel):
    content_index_id: int
    prompt: str
    metadata_filters : Optional[dict] = None
    documents: Optional[List[int]] = None
    chat_history: List[ChatStructure]