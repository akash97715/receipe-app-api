import logging, requests
from app.commons.config import config 
from fastapi import Request
from fastapi import HTTPException
from starlette.responses import Response, JSONResponse
from fastapi import status
import json

class ExceptionCustom(HTTPException):
    pass

class AuthController:
    logger = logging.getLogger(__name__)

    @staticmethod 
    async def verify_token(request: Request) -> Response:
        logging.info(f"Request: {request.headers.__dict__}")
        authorization = request.headers["x-auth"]
        if authorization is None:
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "X-auth header is missing"})
        if not authorization.startswith("Bearer "):
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Invalid Bearer token format"})
        bearer_token = authorization[7:]
        if not bearer_token:
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Token not found"})
        payload = {
            "token": {bearer_token},
            "client_id": {config.PINGFEDERATE_CLIENT_ID},
            "client_secret": {config.PINGFEDERATE_CLIENT_SECRET}
          }
        try:
            response = requests.post(url=config.PINGFEDERATE_TOKEN_VALIDATION_URL, data=payload, headers=config.FORM_DATA_HEADER)
            responseDict = json.loads(response.text)            
            if("active" in responseDict.keys()):
                if(responseDict["active"] == False):
                    return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Token expired"})
            user_groups = []
            if (config.ALLOWED_GROUPS != ""):
                allowed_groups = config.ALLOWED_GROUPS.split("|")
                groups = responseDict.get("group")
                groups_cleaned = [group.split("CN=")[1].split(",")[0] for group in groups]
                for group in groups_cleaned:               
                    for allowed_group in allowed_groups:
                        if (group == allowed_group):
                            user_groups.append(group)
                if (len(user_groups) == 0):
                    return JSONResponse(status_code=status.HTTP_403_FORBIDDEN, content={"detail": "User does not belong to any known groups"})
                responseDict["group"] = user_groups
            request.state.userInfo = responseDict
            return JSONResponse(status_code=status.HTTP_200_OK, content=responseDict)
        
        except requests.HTTPError as http_err:
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Token invalid"})
        except requests.RequestException as err:
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={"detail": "Bad request"})
        except Exception as e:
            return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content={"detail": "Internal server error."})
