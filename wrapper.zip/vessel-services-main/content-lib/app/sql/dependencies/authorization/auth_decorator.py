from functools import wraps
from .auth_controller import AuthController
from fastapi import HTTPException
import json

def auth_token_validation():
    def decorator(func):
        @wraps(func)
        async def wrapper(request, *args, **kwargs):
            response = await AuthController.verify_token(request)
            if (response.status_code==200):
                return await func( request, *args, **kwargs)
            else:
                raise HTTPException(status_code=response.status_code, detail=json.loads(response.body)["detail"])
        return wrapper
    return decorator