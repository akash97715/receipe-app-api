"""
API Helper Functions

This file contains a collection of helper functions designed to streamline the use of the API. These functions are designed to simplify common tasks and improve code readability.
"""

import os, hashlib, pathlib, re, json
from dotenv import load_dotenv
from PyPDF2 import PdfReader
from langchain.document_loaders import (
    UnstructuredWordDocumentLoader,
    PyMuPDFLoader,
    UnstructuredExcelLoader,
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import OpenSearchVectorSearch, FAISS
from langchain.chains import RetrievalQA, ConversationalRetrievalChain
from langchain.llms import OpenAI
import shutil
import logging
from opensearchpy import OpenSearch
from app.sql.helper.vox_dev.ias_openai_langchain import (
    IASOpenaiConversationalLLM,
    IASOpenaiEmbeddings,
)
from app.commons.exceptions import FileException
from app.commons.constants import file_size

load_dotenv()

OPENSEARCH_HOST = os.getenv("OPENSEARCH_HOST")
OPENSEARCH_USERNAME = os.getenv("OPENSEARCH_USERNAME")
OPENSEARCH_PASSWORD = os.getenv("OPENSEARCH_PASSWORD")
LLM_ENGINE = os.getenv("LLM_ENGINE")

logger = logging.getLogger()

def is_valid_opensearch_index_name(index_name):
    if not index_name.islower():
        return (False,"md5 should be in lower case")    
    if index_name.startswith('_') or index_name.startswith('-'):
        return (False,'md5 should not startswith "_" or "-" ')
    invalid_chars = r'[:, "*+/\|?#><]'
    if re.search(invalid_chars, index_name):
        return (False,'invalid character allowed characters are  "_" or "-" ')
    if ' ' in index_name or ',' in index_name:
        return (False,'invalid character allowed characters are  "_" or "-" ')
    return (True,"success")

def save_upload_file(file):
    """
    Saves the uploaded file locally

    Agrs:
        file (fastapi(File)): uploaded file

    Returns:
        file_path (str): path to the saved file.
    """
    file_path = file.filename
    # file_path = f"./backend/app/content_library_app/helper/temp_save/{file.filename}"

    try:
        with open(file_path, "wb+") as file_object:
            shutil.copyfileobj(file.file, file_object)
        logger.info(f"file saved locally at {file_path}")
    except Exception as e:
        logger.error(f"Error saving the file {str(e)}")

    return file_path


def del_file(file_path):
    """
    Deletes the file at the file path mentioned

    Args:
        file_path: path to the file

    Returns:
        Nothing
    """

    try:
        if os.path.exists(file_path):
            os.remove(file_path)
            logger.info("File deleted successfully")
        else:
            logger.warning("file does not exist")

    except Exception as e:
        logging.warning(f"Error deleting the file: {str(e)}")


def calculate_md5_hash(file_path):
    """
    Calculates the MD5 hash of a string.

    Args:
        file_path (str): The path to the file.

    Returns:
        str: The MD5 hash value.
    """
    with open(file_path, "rb") as file_to_check:
        # read contents of the file
        data = file_to_check.read()
        # pipe contents of the file through
        md5 = hashlib.md5(data).hexdigest()

    return md5


def fetch_page_section_mapping(file):
    """
    Fetches the page-section mapping from a PDF file.

    Args:
        file (str): The path to the PDF file.

    Returns:
        dict: A dictionary mapping section titles to page numbers.
    """
    page_section_mapping = {}

    # Read the pdf file for mapping
    reader = PdfReader(file)
    # Check if the PDF has an outline (bookmarks)
    if "/Outlines" in reader.trailer["/Root"]:
        outlines = reader.outline

        def title_page_outline(outline, depth, current_depth=0):
            if current_depth < depth:
                if not isinstance(outline, list):
                    title = re.sub(r"[^a-zA-Z\s]+", "", outline.title).strip()
                    title = title.replace(" ", "_")
                    page_number = reader.get_destination_page_number(outline)
                    page_section_mapping[title] = page_number

                else:
                    # Recursively map child outlines
                    for child in outline:
                        title_page_outline(child, depth, current_depth + 1)

        # page_section map for the outline tree
        for outline in outlines:
            try:
                if len(outlines) == 2:
                    title_page_outline(outline, depth=2)
                else:
                    title_page_outline(outline, depth=1)
            except:
                continue
    else:
        print("The PDF doesn't have any bookmarks (outlines).")

    return page_section_mapping


def search_dict(dictionary, search_value):
    """
    Fetchs the key based on the search value

    Args:
        dictionary (dict[str:int]): dictionary containing key-value pairs
        search_value (int): value to be search

    Returns:
        closest_key (str): key with value equal to or smaller than the search value
    """

    keys = list(dictionary.keys())
    values = list(dictionary.values())

    if search_value in values:
        return keys[values.index(search_value)]

    closest_smaller_value = None
    closest_key = ""

    for key, value in dictionary.items():
        if value < search_value:
            if closest_smaller_value is None or value > closest_smaller_value:
                closest_smaller_value = value
                closest_key = key

    return closest_key


def process_file(
    file,
    cust_md={},
    cust_separators=["paragraph", "sentence", "word", "character"],
    split_by="tokens",
    chunk_size=400,
    overlap=40,
):
    """
    Extracts content and metadata from a file

    Args:
        file (File): path to the file(pdf/docx)
        cust_md (dict): custom metadata to be added to the splits
        cust_separators (list[str]): Separators to be used(in order) default = ['paragraph','sentence','word','character']
        split_by (str): parameter for each split('tokens' or 'characters') default= 'tokens'
        chunk_size (int): size of each split default = 400
        overlap (int): amount of overlap between splits default = 40

    Returns:
        page_content (list[str]): list containing splits
        metadata (list[dict]): metadata for each split
    """
    # save file locally as get the file path
    file_path = save_upload_file(file)
    if os.path.getsize(file_path) / (1024 * 1024) > file_size:
        del_file(file_path)
        raise FileException(f"File size should be less than {file_size} MB.")

    # calculate and save the md5 value of the file.
    try:
        md5_value = calculate_md5_hash(file_path)
    except Exception as e:
        logger.error(f"Error in calculating md5 hash value: \n{str(e)}")
        raise Exception(f"Error in calculating md5 hash value: \n{str(e)}")

    file_type = pathlib.Path(file_path).suffix
    page_section_mapping = {}

    # load and split the file in pages.
    if file_type == ".pdf":
        page_section_mapping = fetch_page_section_mapping(file_path)

        loader = PyMuPDFLoader(file_path)
    elif file_type == ".doc" or file_type == ".docx":
        loader = UnstructuredWordDocumentLoader(
            file_path, mode="elements", strategy="fast"
        )
    elif file_type == ".xlsx":
        loader = UnstructuredExcelLoader(file_path, mode="elements", strategy="fast")
    else:
        page_content = ["No page_content"]
        metadata = ["No metadata"]
        logger.info("PDF/Docx/Xlsx file was not uploaded")
        return page_content, metadata

    pages = loader.load()

    # replacing text with corresponding markers
    for i in range(len(cust_separators)):
        if cust_separators[i] == "paragraph":
            cust_separators[i] = "\n\n"
        elif cust_separators[i] == "sentence":
            cust_separators[i] = "\n"
        elif cust_separators[i] == "word":
            cust_separators[i] = " "
        elif cust_separators[i] == "character":
            cust_separators[i] = ""

    try:
        # splitting the document based on the specified parameters
        if split_by == "tokens":
            text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                chunk_size=chunk_size, chunk_overlap=overlap, separators=cust_separators
            )
        elif split_by == "characters":
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size, chunk_overlap=overlap, separators=cust_separators
            )
        else:
            logger.info(f"Option selected is not available")
            page_content = ["No page_content"]
            metadata = ["No metadata"]
            return page_content, metadata

        texts = text_splitter.split_documents(pages)
        exclude_keys = ["filename", "md5"]

        # adding custom metadata to each split
        page_content = [text.page_content for text in texts]
        metadata_temp = [text.metadata for text in texts]
        metadata = [
            {
                **d,
                "section": search_dict(page_section_mapping, d["page"]).lower()
                if len(page_section_mapping) != 0
                else "",
                "filename": pathlib.Path(file_path).name,
                "md5": md5_value,
                "chunk_no": idx,
                "page": d["page"] + 1,
                **{
                    key: value
                    for key, value in cust_md.items()
                    if key not in exclude_keys
                },
            }
            for idx, d in enumerate(metadata_temp)
        ]

        logger.info("deleting file..")
        del_file(file_path)

        return page_content, metadata

    except Exception as e:
        logger.error(f"Error while chunking the file: {str(e)}")
        raise Exception(f"Error while chunking the file: \n{str(e)}")


def get_vector_db(index, embedding_model="text-embedding-ada-002"):
    """
    Authenticate and access the vector_db

    Args:
        index (str): index of the vector db
        embedding_model (str): embedding model to be used; Default= text-embedding-ada-002

    Returns:
    vector_db: Vector database associated with the index
    """

    vector_db = OpenSearchVectorSearch(
        index_name=index,
        embedding_function=IASOpenaiEmbeddings(embedding_model),
        opensearch_url=OPENSEARCH_HOST,
        http_auth=(OPENSEARCH_USERNAME, OPENSEARCH_PASSWORD),
        is_aoss=False,
    )
    return vector_db


def upload_file_to_os(
    index, page_content, metadata, embedding_model="text-embedding-ada-002"
):
    """
    Uploads the split documents along with the metadata to the given index on opensearch db

    Args:
        index (str): index to which the documents are to be uploaded
        page_content (list[str]): split documents
        metadata (list[dict]): metadata for each split
        embedding_model: embedding model to be used; Default= text-embedding-ada-002

    Returns:
        vectors (list): list of ids from adding docs to the vectorstore

    """
    vector_db = get_vector_db(index, embedding_model)
    vectors = []
    # use batches to upload large files
    try:
        batch_size = 16
        for i in range(0, len(page_content), batch_size):
            vectors = vector_db.add_texts(
                texts=page_content[i : i + batch_size],
                metadatas=metadata[i : i + batch_size],
            )
        return vectors
    except Exception as e:
        print(e)
        logging.info("calling delete doc ml function..")
        md5 = metadata[0]["md5"]
        delete_doc(index,md5)
        raise e

def create_tempdb_from_docs(index, filter, embedding_model="text-embedding-ada-002"):
    """
    Creates a temporary vector database based on the filters provided

    Args:
        index (str): Index to search through
        filter (dict): Filters to be applied on the metadata;
        embedding_model (str): embedding model to be used; Default = 'text-embedding-ada-002'

    Returns:
        vector_db: the created vector database
    """
    # get the vector database from the index
    vector_db = get_vector_db(index, embedding_model)

    # create filter for query
    query = {
        "query": {
            "bool": {
                "filter": [
                    {"terms": {f"metadata.{key}": value}} for key, value in filter.items()
                ]
            }
        }
    }

    result = vector_db.client.search(index=index, body=query, size=500)

    if result['hits']['total']['value'] == 0:
        return None

    source_doc = result["hits"]["hits"]
    texts = [i["_source"]["text"] for i in source_doc]
    metadatas = [i["_source"]["metadata"] for i in source_doc]
    # create temp db

    batch_size = 16
    vector_db = FAISS.from_texts(
        texts=texts[0:16],
        embedding=IASOpenaiEmbeddings(embedding_model),
        metadatas=metadatas[0:16],
    )

    for i in range(16, len(texts), batch_size):
        vector_db.merge_from(
            FAISS.from_texts(
                texts=texts[i : i + batch_size],
                embedding=IASOpenaiEmbeddings(embedding_model),
                metadatas=metadatas[i : i + batch_size],
            )
        )

    return vector_db


def get_output_source_doc(
    query,
    index,
    filter={},
    k=5,
    search_type="similarity",
    embedding_model="text-embedding-ada-002",
):
    """
    Returns the document relevant to the query based on the parameters defined

    Args:
        query (str): Query to search through the embeddings
        index (str): Index to search through
        filter (dict): Filters to be applied on the metadata; Default = {}
        k (int): Max number of documents to return; Default = 5
        search_type (str): type of searching to be used('similartiy', 'mmr', 'similarity_score_threshold'); Default = 'similarity'
        embedding_model (str): embedding model to be used; Default = 'text-embedding-ada-002'

    Returns:
        List(langchain.schema.document): containing the relevant documents
    """
    if len(filter) == 0:
        vector_db = get_vector_db(index, embedding_model)
    else:
        vector_db = create_tempdb_from_docs(index, filter)

    if vector_db is None:
        return []
    result = vector_db.search(search_type=search_type, query=query, k=k, filter=filter)

    del vector_db

    result = [
        {"page_content": i.page_content, "metadata": json.dumps(i.metadata)}
        for i in result
    ]
    return result


def get_output_response_with_source(
    query,
    index,
    filter={},
    k=5,
    search_type="similarity",
    embedding_model="text-embedding-ada-002",
    chat_history=[],
):
    """
    fetch answer for user query from vector database along with the source documents

    Args:
        query (str): Query to search through the embeddings
        index (str): Index to search through
        filter (dict): Filters to be applied on the metadata; Default = {}
        k (int): Max number of documents to return; Default = 5
        search_type (str): type of searching to be used('similartiy', 'mmr', 'similarity_score_threshold'); Default = 'similarity'
        embedding_model (str): embedding model to be used; Default = 'text-embedding-ada-002'
        chat_history (List[(str, str)]): List of (query,answer) pairs which serve as the chat history; Default = []

    Returns:
        result (Dict): contains user query, answer and the source documents
    """

    if len(filter) == 0:
        vector_db = get_vector_db(index, embedding_model)
    else:
        vector_db = create_tempdb_from_docs(index, filter, embedding_model)

    if vector_db is None:
        return {}

    retriever = vector_db.as_retriever(
        search_type=search_type, search_kwargs={"k": k, "filter": filter}
    )

    qa = ConversationalRetrievalChain.from_llm(
        llm=IASOpenaiConversationalLLM(
            engine=LLM_ENGINE, max_tokens=4096, temperature=0
        ),
        retriever=retriever,
        return_source_documents=True,
    )

    result = qa({"question": query, "chat_history": chat_history})

    del vector_db
    del retriever

    result = {
        "query": result["question"],
        "result": result["answer"],
        "source_documents": [
            {"page_content": i.page_content, "metadata": json.dumps(i.metadata)}
            for i in result["source_documents"]
        ],
    }

    return result


def delete_index(index):
    """
    Deletes the specified index in the vector database

    Args:
        index (str): Index to be deleted

    Returns:
        Status : status of deletion(True if successfully deleted else returns (dict))
    """
    vector_db = get_vector_db(index)

    if vector_db.client.indices.exists(index=index):
        status = vector_db.client.indices.delete(index=index)
    else:
        return "Index does not exist."

    if status["acknowledged"] == True:
        return True
    else:
        return status


def delete_doc(index, md5):
    """
    Deletes the specific documents in the provided index of the vector database

    Args:
        index (str): Index present in the vector db
        md5 (str): MD5 value of the document to be deleted

    Returns:
        True if document is successfully deleted else False
    """
    vector_db = get_vector_db(index)

    query = {"query": {"bool": {"filter": {"term": {"metadata.md5": md5}}}}}

    status = vector_db.client.delete_by_query(index=index, body=query)

    if status["total"] == status["deleted"]:
        return True
    else:
        return False