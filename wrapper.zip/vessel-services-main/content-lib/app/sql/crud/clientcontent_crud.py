from app.sql import session
from app.sql.orm_models.models import ClientContentMappingORM
from app.commons.errors import get_err_json_response
from app.logs.logger_config import logger
from sqlalchemy import desc
import json

class CRUDContentContentMapping:
    def create(self, **kwargs):
        """[CRUD function to create a new user record]
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-client-content-mapping crud ...")
            client_content = ClientContentMappingORM(**kwargs)
            with session() as transaction_session:
                transaction_session.add(client_content)
                transaction_session.commit()
                transaction_session.refresh(client_content)
            return client_content.__dict__
        except Exception as e:
            logger.error("Error while adding to client-content-mapping table")
            return get_err_json_response(
            "Error while adding to client-content-mapping table",
            e.args,
            501,
        )

    def get_client_content_by_client_id(self, client_id):
        """[CRUD function to get client_content name by client_id]
        Args:
            client_id (int): The id of the client content .
        Returns:
            str: name of the client content .
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-client content crud ...")
            with session() as transaction_session:
                client_content = transaction_session.query(ClientContentMappingORM).filter(ClientContentMappingORM.client_id==client_id).all()
                client_content_list = []
                for client_content_data in client_content:
                    client_content_list.append(client_content_data.__dict__["content_id"])
                return client_content_list
        except Exception as e:
            logger.error("Error while fetching name from client-content-mapping table")
            return get_err_json_response(
                "Error while fetching name  from client-content-mapping table",
                e.args,
                501
            )
    def delete_by_content_index_id(self, content_index_id):
        """[CRUD function to delete client-content-mapping by content_index_id]
        Args:
            content_index_id (int)): The id of the content index .
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete-client-content-mapping crud ...")

            with session() as transaction_session:
                content_index = (transaction_session.query(ClientContentMappingORM)
                                    .filter(ClientContentMappingORM.content_id == content_index_id)
                                    .first())
                transaction_session.delete(content_index)
                transaction_session.commit()
                logger.info("deletion successfully done!")
        except Exception as e:
            logger.error("Error while deleting from client-content-mapping table")
            return get_err_json_response(
                "Error while deleting from client-content-mapping table",
                e.args,
                501
            )