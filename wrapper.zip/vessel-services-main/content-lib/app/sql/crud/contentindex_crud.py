from app.sql import session
from app.sql.orm_models.models import ContentIndexORM, DocumentORM
from app.commons.errors import get_err_json_response
from app.logs.logger_config import logger
from sqlalchemy import desc
import json

class CRUDContentIndex:
    def create(self, **kwargs):
        """[CRUD function to create a new user record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-content-index crud ...")
            content_index = ContentIndexORM(**kwargs)
            with session() as transaction_session:
                transaction_session.add(content_index)
                transaction_session.commit()
                transaction_session.refresh(content_index)
            return content_index.__dict__
        except Exception as e:
            logger.error("Error while adding to content-index table")
            return get_err_json_response(
            "Error while adding to content-index table",
            e.args,
            501,
        )

    def get_content_indexes_by_index_type(self,content_index_type):
        try:
            with session() as db:   
                content_indexes = db.query(ContentIndexORM).filter(ContentIndexORM.index_type == content_index_type).order_by(desc(ContentIndexORM.created_date)).all()
                content_index_dicts = []
                for content_index in content_indexes:
                    num_doc = db.query(DocumentORM).filter(DocumentORM.content_index_id == content_index.content_index_id).count()
                    content_index_dict = content_index.__dict__
                    content_index_dict['meta_tags'] = json.loads(content_index_dict['meta_tags'])
                    content_index_dict['num_doc'] = num_doc
                    content_index_dicts.append(content_index_dict)
            return content_index_dicts
        except Exception as e:
            logger.error("Error while fetching entry from content-index table")
            return get_err_json_response(
                "Error while fetching entry from content-index table",
                e.args,
                501
            ) 
        
    def get_all_content_index(self):
        """[CRUD function to get content-index entry by name]
        Returns:
            dict: return list of content_index entries.
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-all-content-index crud ...")
            # Assuming you have an SQLAlchemy ORM model for ContentIndex named ContentIndexORM
            with session() as transaction_session:
                content_index_list = transaction_session.query(ContentIndexORM).order_by(desc(ContentIndexORM.created_date)).all()
                for content_index in content_index_list:
                    content_index = content_index.__dict__
                    content_index['meta_tags'] = json.loads(content_index['meta_tags'])
                return content_index_list
        except Exception as e:
            logger.error("Error while fetching entry from content-index table")
            return get_err_json_response(
                "Error while fetching entry from content-index table",
                e.args,
                501
            )

    def get_by_content_index_name(self, content_index_name):
        """[CRUD function to get content-index entry by name]

        Args:
            content_index_name (str): The name of the content index to retrieve.

        Returns:
            dict: A dictionary representing the content index entry.

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-content-index crud ...")
            
            # Assuming you have an SQLAlchemy ORM model for ContentIndex named ContentIndexORM
            with session() as transaction_session:
                content_index = transaction_session.query(ContentIndexORM).filter(ContentIndexORM.content_index_name==content_index_name).first()
            if content_index:
                content_index = content_index.__dict__
                content_index['meta_tags'] = json.loads(content_index['meta_tags'])
                return content_index
            else:
                return None
        except Exception as e:
            logger.error("Error while fetching entry from content-index table")
            return get_err_json_response(
                "Error while fetching entry from content-index table",
                e.args,
                501
            )

    def get_content_index_by_id(self, content_index_id):
        """[CRUD function to get content-index name by id]
        Args:
            content_index_id (int): The id of the content index .
        Returns:
            str: name of the content index .
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-content-index crud ...")
            with session() as transaction_session:
                content_index = transaction_session.query(ContentIndexORM).filter(ContentIndexORM.content_index_id==content_index_id).first()
                if content_index:
                    content_index = content_index.__dict__
                    content_index['meta_tags'] = json.loads(content_index['meta_tags'])
                    return content_index
                else:
                    return None
        except Exception as e:
            logger.error("Error while fetching name from content-index table")
            return get_err_json_response(
                "Error while fetching name  from content-index table",
                e.args,
                501
            )

    def get_name_by_id(self, content_index_id):
        """[CRUD function to get content-index name by id]

        Args:
            content_index_id (int): The id of the content index .

        Returns:
            str: name of the content index .

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-content-index crud ...")
            
            # Assuming you have an SQLAlchemy ORM model for ContentIndex named ContentIndexORM
            with session() as transaction_session:
                content_index = transaction_session.query(ContentIndexORM).filter(ContentIndexORM.content_index_id==content_index_id).first()
                if content_index:
                    return content_index.__dict__["content_index_name"]
                else:
                    return None
        except Exception as e:
            logger.error("Error while fetching name from content-index table")
            return get_err_json_response(
                "Error while fetching name  from content-index table",
                e.args,
                501
            )
        
    def delete_by_name(self, content_index_name):
        """[CRUD function to delete content-index and all related docs by name]

        Args:
            content_index_name (str)): The name of the content index .

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete-content-index crud ...")

            with session() as transaction_session:
                content_index = (transaction_session.query(ContentIndexORM)
                                    .filter(ContentIndexORM.content_index_name == content_index_name)
                                    .first())
                transaction_session.delete(content_index)
                transaction_session.commit()
                logger.info("deletion successfully done!")
        except Exception as e:
            logger.error("Error while deleting from content-index table")
            return get_err_json_response(
                "Error while deleting from content-index table",
                e.args,
                501
            )