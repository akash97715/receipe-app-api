from app.sql import session
from app.sql.orm_models.models import ContentSplittingORM
from app.commons.errors import get_err_json_response
from app.logs.logger_config import logger

class CRUDContentSplitting:

    def create(self, **kwargs):
        """[CRUD function to create a new content splitting entry]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-content-splitting crud ...")
            user = ContentSplittingORM(**kwargs)
            with session() as transaction_session:
                transaction_session.add(user)
                transaction_session.commit()
                transaction_session.refresh(user)
            return user.__dict__
        except Exception as e:
            logger.error("Error while adding to content splitting table")
            return get_err_json_response(
            "Error while adding to user table",
            e.args,
            501,
        )

    def get_content_splitting_by_context_id(self, content_index_id: int):
        """[CRUD function to read splitting data by context id]

        Args:
            content_index_id (int): [context id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [context splitting records matching the criteria]
        """
        try:
            logger.info("executing get_by_content_index crud ...")
            with session() as transaction_session:
                obj: ContentSplittingORM = (
                        transaction_session.query(ContentSplittingORM)
                        .filter(ContentSplittingORM.content_index_id == content_index_id)
                        .first()
                    )
            if obj is not None:
                return obj
            else:
                return None
            
        except Exception as e:
            logger.error("error while filtering content splitting by context id.")
            return get_err_json_response(
            "Error while filtering content splitting table",
            e.args,
            501,
        )
    