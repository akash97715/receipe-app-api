### Steps to run Backend

1. run this command in backend folder: `pip install -r requirements.txt`
2. run `main.py` file which is present in `backend/app` folder.
3. open this link for swagger docs: http://localhost:7001/content-library/docs#/
4. 
