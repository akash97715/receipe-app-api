import os
import json
import boto3
from botocore.vendored import requests
from datetime import datetime
from collections import defaultdict
from collections import OrderedDict

# Setting Constants
REQUESTOR_LAMBDA_FUNCTION = os.environ["REQUESTOR_LAMBDA_FUNCTION"]
AWS_REGION = os.environ["AWS_REGION"]
DYNAMO_CAPACITY_TABLE = os.environ["DYNAMO_CAPACITY_TABLE"]

def check_pending_messages_in_queue(queue_name):
    """
    This Function is reponsible for scanning through the SQS queue metric and identifying the approximate number of messages available in the queue at existing point of time.
    Input Parameter : SQS Queue Name
    Returns : Approximate Number of Messages in the Queue
    """
    sqs_client = boto3.client("sqs", region_name=AWS_REGION)
    try:
        # Get the queue URL for the specified queue name
        response = sqs_client.get_queue_url(QueueName=queue_name)
        queue_url = response["QueueUrl"]

        # Get the number of pending messages in the queue
        response = sqs_client.get_queue_attributes(
            QueueUrl=queue_url, AttributeNames=["ApproximateNumberOfMessages"]
        )

        # Extract the number of pending messages
        approximate_number_of_messages = int(
            response["Attributes"]["ApproximateNumberOfMessages"]
        )
        if not approximate_number_of_messages:
            approximate_number_of_messages = 0

        return approximate_number_of_messages
    except Exception as e:
        print(
            f"Exception Encountered in function check_pending_messages_in_queue : {str(e)}"
        )
        return None


def update_request_consumption_using_dlqs(
    consumption_json, total_consumption_cap_for_lambda
):
    """
    This function does a 4 fold Job.
        1. Reads through the dictionary with existing capacity for each Queue which got calculated based on Total capacity and Queue's capacity percentage.
        2. Reads through the total capacity of Requestor Lambda as part of this iteration.
        3. Scan's through the DLQ SQS for each of the original SQSs, check's their pending Approximate message count and creates and updated JSON.
        4. If existing messages in the SQS queues are less compared to capacity we have provisioned for that queue, use the remaining capacity to prioritize next Queue's backlog.
    Input Parameter : Dictionary with Original SQS Queues and their predefined capacity, Requestor Lambda's Capacity
    Returns : Updated dicitionary with original and DQL SQS's accounted
    """

    # Creating empty dict(to hold updated values for each queue) and Ordered Dict to ensure Queue priority is retained
    updated_consumption_json = {}
    pending_messages_dict = OrderedDict()

    # Iterating through all the Queue and their defined capacities to generate final JSON with corresponding DLQ's capacity also adjusted
    for queue_name in consumption_json.keys():
        # Logic to calculate total messages in the Queue : Original Queue + DLQ
        number_of_messages_in_queue = check_pending_messages_in_queue(queue_name)
        # Generate name of DLQ based on original Queue Name
        dlq_queue_name = queue_name.split(".")[0] + "_dlq." + queue_name.split(".")[1]
        number_of_messages_in_dlq_queue = check_pending_messages_in_queue(
            dlq_queue_name
        )
        total_messages_in_queue = (
            number_of_messages_in_queue + number_of_messages_in_dlq_queue
        )

        # Logic to Evaluate if Total Message in Original + DLQ are More/Less/Equal to the Capacity Available for this Queue in the Dynamo DB Queue_Consumption Table
        if total_messages_in_queue < int(consumption_json[queue_name]):
            print(
                "All the messages for the original and dead letter queue can be consumed"
            )
            updated_consumption_json[queue_name] = number_of_messages_in_queue
            updated_consumption_json[dlq_queue_name] = number_of_messages_in_dlq_queue

        elif total_messages_in_queue >= int(consumption_json[queue_name]):
            # If Total Messages are more than Capacity then, Logic has been put up to prioritize DLQ's messages first before the Original Queue's messages.
            if number_of_messages_in_dlq_queue > int(consumption_json[queue_name]):
                print(
                    "Scenario where # of message in DLQ is also greater than overall consumption capacity"
                )
                updated_consumption_json[dlq_queue_name] = int(
                    consumption_json[queue_name]
                )

                # Pending Messages Dict keep a track here of remaining number of messages in each queue since these numbers can be leveraged later if overall capacity is leftover. In this case some of the DLQ messages can't be consumed, hence they are being tracked in pending_messages_dict
                pending_messages_dict[
                    dlq_queue_name
                ] = number_of_messages_in_dlq_queue - int(consumption_json[queue_name])

            elif number_of_messages_in_dlq_queue <= int(consumption_json[queue_name]):
                print(
                    "Scenario where consumption capacity is more but DLQ has less messages"
                )
                updated_consumption_json[
                    dlq_queue_name
                ] = number_of_messages_in_dlq_queue
                num_of_messages_eligible_from_original_queue = (
                    int(consumption_json[queue_name]) - number_of_messages_in_dlq_queue
                )
                print("Checking if Original Queue has these many messages or not")

                if (
                    num_of_messages_eligible_from_original_queue
                    > number_of_messages_in_queue
                ):
                    print(
                        "We can take all messages from the Original Queue and still be left with capacity"
                    )
                    updated_consumption_json[queue_name] = number_of_messages_in_queue

                elif (
                    num_of_messages_eligible_from_original_queue
                    <= number_of_messages_in_queue
                ):
                    print("We can take selective messages from the Original Queue")
                    updated_consumption_json[
                        queue_name
                    ] = num_of_messages_eligible_from_original_queue

                    # In this case some of the Original Queue messages can't be consumed, hence they are being tracked in pending_messages_dict
                    pending_messages_dict[queue_name] = (
                        number_of_messages_in_queue
                        - num_of_messages_eligible_from_original_queue
                    )

    # Print Statements to assist with Debugging
    print("Updated Consumption JSON is : " + str(updated_consumption_json))
    print(
        "Queues which have pending messages in order of priority"
        + str(pending_messages_dict)
    )

    # Checking if the existing # of Requests are Less than Lambda's total Capacity
    planned_messages_for_consumption = sum(updated_consumption_json.values())
    print(
        "Total Consumption Capacity of Lambda : "
        + str(total_consumption_cap_for_lambda)
    )
    print(
        "Planned Messages for Consumption based on Updated Dictionary : "
        + str(planned_messages_for_consumption)
    )
    remaining_capacity = (
        total_consumption_cap_for_lambda - planned_messages_for_consumption
    )

    # Check if Lambda's capacity is more, if so, refine the existing dict to incorporate messages from Queues which have backlog but ensure Priority of queue's is taken care off.
    if remaining_capacity > 0:
        for queue, pending_messages in pending_messages_dict.items():
            if remaining_capacity == 0:
                break
            print(
                f"Queue with messages: {queue}, Number of Pending Messages: {pending_messages}"
            )
            if pending_messages >= remaining_capacity:
                print(
                    "The Queue Have More Messages than remaining capacity, hence only few can be accomodated"
                )
                num_of_new_msgs_to_be_added_from_queue = remaining_capacity
                remaining_capacity = 0
                updated_consumption_json[queue] = (
                    updated_consumption_json[queue]
                    + num_of_new_msgs_to_be_added_from_queue
                )

            elif pending_messages < remaining_capacity:
                print(
                    "Lambda has more capacity pending than Queue's pending messages, hence all the messages can be accomodated."
                )
                num_of_new_msgs_to_be_added_from_queue = pending_messages
                remaining_capacity = remaining_capacity - pending_messages
                updated_consumption_json[queue] = (
                    updated_consumption_json[queue]
                    + num_of_new_msgs_to_be_added_from_queue
                )
            elif remaining_capacity > 0:
                continue
    else:
        print("No remaining Capacity available...!")

    print(
        "Updated Consumption JSON post evaluating remaining capacity : "
        + str(updated_consumption_json)
    )
    return updated_consumption_json


def handler(event, context):
    current_time = datetime.now()

    # Format the current time as a string with milliseconds
    current_time_str = current_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    # List for Holding records pulled up from Dynamo Table with Queue, Priority and Capacity details in addition to details of Lambda's capacity.
    results = []
    client = boto3.client("dynamodb", region_name=AWS_REGION)
    last_evaluated_key = None
    dynamo_table_name = DYNAMO_CAPACITY_TABLE

    # Iterating through all entries of the table
    while True:
        if last_evaluated_key:
            response = client.scan(
                TableName=dynamo_table_name, ExclusiveStartKey=last_evaluated_key
            )
        else:
            response = client.scan(TableName=dynamo_table_name)
        last_evaluated_key = response.get("LastEvaluatedKey")
        results.extend(response["Items"])

        if not last_evaluated_key:
            break

    # Sort the JSON array based on the "Priority_Num" key to ensure record with Highest Priority_Num comes first
    sorted_records_based_on_priority = sorted(
        results, reverse=True, key=lambda x: int(x["Priority_Num"]["N"])
    )

    # Publishing sorted Records in the Dynamo DB Table for Reference
    print(
        "Records in the Dynamo DB table sorted based on Priority_Num :"
        + str(sorted_records_based_on_priority)
    )

    # Extracting the Lambda Capacity from 1st Entry.
    total_request_consumption_capcacity = int(
        sorted_records_based_on_priority[0]["Lambda_Total_Req_Cap"]["N"]
    )

    # Creating an Ordered Dict to ensure the Priority of the SQS Queues aren't lost during further processing
    request_consumption_json = OrderedDict()

    # Calculate and populate the Queue - No. of Request JSON based upon the Dynamo Table Configs.
    for item in sorted_records_based_on_priority:
        queue_name = item["Queue_Name"]["S"]
        consumption_capacity = int(item["Consumption_Capacity"]["N"])
        lambda_total_req_cap = int(item["Lambda_Total_Req_Cap"]["N"])

        # Calculate the value as a percentage of Consumption_Capacity * Lambda_Total_Req_Cap
        value = (consumption_capacity * lambda_total_req_cap) / 100

        # Add the result to the output dictionary
        request_consumption_json[queue_name] = int(value)

    print("The value of request_consumption_json is : " + str(request_consumption_json))

    queue_requests_mapping = update_request_consumption_using_dlqs(
        request_consumption_json, total_request_consumption_capcacity
    )
    print(f"queue value is {queue_requests_mapping}")

    # Code to Invoke another Lambda with Queue Request Mapping
    # target_lambda_function_name = 'arn:aws:lambda:us-east-1:703160255746:function:requestorLambda'
    lambda_client = boto3.client("lambda", region_name=AWS_REGION)

    try:
        # Invoke the target Lambda function
        invocation_response = lambda_client.invoke(
            FunctionName=REQUESTOR_LAMBDA_FUNCTION,
            InvocationType="Event",  # Asynchronous invocation
            Payload=json.dumps(queue_requests_mapping),
        )
        invocation_status_code = invocation_response["ResponseMetadata"][
            "HTTPStatusCode"
        ]
        print(f"Response: {invocation_response['Payload'].read()}")
    except Exception as e:
        print(f"Error invoking Requestor Lambda function: {str(e)}")
        invocation_status_code = 500

    return {
        "statusCode": int(invocation_status_code),
        "body": json.dumps("Orchestrator Lambda Completed"),
    }
