"""Add_allowed_client_id_for_clientidmapping_table

Revision ID: c283fc765c7d
Revises: 98e0396a69e3
Create Date: 2024-01-25 19:45:25.382487

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy_utils import ScalarListType


# revision identifiers, used by Alembic.
revision: str = 'c283fc765c7d'
down_revision: Union[str, None] = '98e0396a69e3'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "clientidmappingtableias",
        sa.Column("alternate_client_ids", ScalarListType),
    )



def downgrade() -> None:
    op.drop_column("clientidmappingtableias", "alternate_client_ids")
