"""create document ingestion status table

Revision ID: d366799f82b4
Revises: d3f0462bd9f7
Create Date: 2023-11-10 13:07:46.673536

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision: str = "d366799f82b4"
down_revision: Union[str, None] = "d3f0462bd9f7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.create_table(
        "data_ingestion_status_table",
        sa.Column("request_id", sa.String, primary_key=True),
        sa.Column("client_id", sa.String, nullable=False),
        sa.Column("index", sa.String, nullable=False),
        sa.Column("document", sa.String, nullable=True),
        sa.Column("document_md5", sa.String, nullable=True),
        sa.Column("attached_metadata", sa.String, nullable=True),
        sa.Column("status", sa.String, nullable=False),
        sa.Column("error_message", sa.String, nullable=True),
        sa.Column("queued_ts", sa.DateTime(timezone=True), nullable=True),
        sa.Column("inprogress_ts", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_errored_ts", sa.DateTime(timezone=True), nullable=True),
    )


def downgrade():
    op.drop_table("data_ingestion_status_table")
