"""create_document_summary_table

Revision ID: ae324c199f4b
Revises: 14381c292667
Create Date: 2023-12-20 13:41:52.660108

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from datetime import datetime


# revision identifiers, used by Alembic.
revision: str = "ae324c199f4b"
down_revision: Union[str, None] = "14381c292667"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "document_summary",
        sa.Column("client_id", sa.String, nullable=False),
        sa.Column("request_id", sa.String, primary_key=True),
        sa.Column("index", sa.String, nullable=False),
        sa.Column("document_md5", sa.String, nullable=False),
        sa.Column("engine", sa.String, nullable=False),
        sa.Column("temperature", sa.Integer, nullable=False),
        sa.Column("summary", sa.String, nullable=True),
        sa.Column("total_tokens_llm", sa.Integer, nullable=True),
        sa.Column("status", sa.String, nullable=False),
        sa.Column("error_message", sa.String, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), default=datetime.utcnow),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            default=datetime.utcnow,
            onupdate=datetime.utcnow,
        ),
    )


def downgrade() -> None:
    op.drop_table("document_summary")
