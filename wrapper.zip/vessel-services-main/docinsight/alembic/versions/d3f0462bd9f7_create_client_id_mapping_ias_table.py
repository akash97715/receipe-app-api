"""create client_id_mapping_ias table

Revision ID: d3f0462bd9f7
Revises: 
Create Date: 2023-11-10 13:04:22.984170

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "d3f0462bd9f7"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    op.create_table(
        "clientidmappingtableias",
        sa.Column("client_id", sa.String, primary_key=True),
        sa.Column("usecase", sa.String, nullable=False),
        sa.Column("queue", sa.String, nullable=False),
        sa.Column("vectorDBdetails", sa.String, nullable=False),
        sa.Column("index", sa.String, nullable=True),
    )


def downgrade():
    op.drop_table("clientidmappingtableias")
