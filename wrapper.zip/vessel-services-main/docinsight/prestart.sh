#! /usr/bin/env bash
set -e
# Let the DB start
python backend_pre_start.py
 
sleep 10;
 
# Run migrations
alembic upgrade head
 
hypercorn main:app --bind 0.0.0.0:8000 --workers 3