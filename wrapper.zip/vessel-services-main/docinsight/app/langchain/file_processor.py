import os
import json
from langchain.document_loaders.csv_loader import CSVLoader
from langchain.document_loaders import (
    UnstructuredExcelLoader,
    PyPDFLoader,
    UnstructuredWordDocumentLoader,
    UnstructuredPowerPointLoader,
    UnstructuredFileLoader,
)
from langchain.text_splitter import RecursiveCharacterTextSplitter
import pathlib
from fastapi import HTTPException

from app.utils.custom_loguru import logger
from app.langchain.v1.helper import calculate_md5_hash
from typing import Optional, List


class ChunkingException(Exception):
    pass


class FileLoaderException(Exception):
    pass


class FileProcessor:
    def __init__(
        self,
        filename: str,
        chunk_size: int,
        chunk_overlap: int,
        cust_metadata: dict,
        separators: Optional[List[str]] = ["\n\n", "\n", " ", ""],
    ):
        self.filename = filename
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or ["\n\n", "\n", " ", ""]
        self.cust_metadata = cust_metadata
        self.file_type = self._filetype_identification()
        self.is_unstructured_loader_enabled = json.loads(os.getenv("UNSTRUCTURED_LOADER_ENABLED", "false").lower())

    def _filetype_identification(self):
        return pathlib.Path(self.filename).suffix

    def _updating_metadata_for_word(self, doc_list: list):
        """This function takes list of dict containing metadata as an input"""

        """returns an updated metadata containing page number in it"""
        final_list = []
        for index_number, item in enumerate(doc_list):
            item["page"] = index_number
            final_list.append(item)
        return final_list

    def _get_documents(self):
        """This function load the documents in list by taking filename as argument"""
        try:
            if self.file_type == ".xlsx":
                loader = UnstructuredExcelLoader(self.filename, mode="elements")
            elif self.file_type == ".csv":
                loader = CSVLoader(self.filename)
            elif self.file_type == ".pdf":
                loader = PyPDFLoader(self.filename, extract_images=False)
            elif self.file_type == ".docx":
                loader = UnstructuredWordDocumentLoader(self.filename)
            elif self.file_type == ".pptx":
                loader = UnstructuredPowerPointLoader(self.filename, mode="elements")
            else:
                raise FileLoaderException("Unsupported file format")

            pages = loader.load()
            documents = self._get_documents_chunk(pages)
            return documents

        except Exception as e:
            logger.error(str(e))
            raise FileLoaderException(f"Errored while loading the document: {str(e)}")

    def _table_title_merge(self, pages):
        """This function processes a list of pages, merging the content of pages labeled as 'Table' with the preceding 'Title' pages if they share the same page number."""
        
        i = 1
        while i < len(pages):
            current_page = pages[i]
            previous_page = pages[i - 1]

            current_page_number = current_page.metadata.get("page_number")
            previous_page_number = previous_page.metadata.get("page_number")

            if (
                current_page.metadata.get("category") == "Table"
                and previous_page.metadata.get("category") == "Title"
                and current_page_number == previous_page_number
            ):
                current_page.page_content = (
                    f"{previous_page.page_content} {current_page.page_content}"
                )
                current_page.metadata.pop("text_as_html", None)
                pages.pop(i - 1)
                i = max(0, i - 1)
            else:
                i += 1

        return pages

    def _get_table_text_elements(self, pages):
        """This function segregates pages into two lists, table_elements and text_elements, based on their category ('Table' or other)."""
        
        table_elements = []
        text_elements = []

        for page in pages:
            if page.metadata["category"] == "Table":
                table_elements.append(page)
            else:
                text_elements.append(page)

        return table_elements, text_elements

    def _process_and_refine_text_elements(self, text_elements):
        """This method processes a list of text elements, identifying consecutive pages with the same page number. If a page is categorized as "NarrativeText," it combines its content with the preceding page's content, excluding redundant occurrences. The method uses a set of indices to track and delete redundant pages while updating their metadata and content accordingly."""
        
        temptext = ""
        delete_indices = set([])

        for i in range(1, len(text_elements)):
            prev_page = text_elements[i - 1]
            current_page = text_elements[i]

            # condition to check the page_number of the previous and current page
            if current_page.metadata.get("page_number") == prev_page.metadata.get(
                "page_number"
            ):
                if (
                    current_page.metadata.get("category") == "NarrativeText"
                ):  # is a narrativeText
                    if prev_page.metadata.get("category") == "NarrativeText":
                        continue
                    else:  # prev not narrative
                        delete_indices.add(i - 1)

                        # Concatenate page content based on the existence of temptext
                        if temptext != "":
                            current_page.page_content = (
                                temptext + " " + current_page.page_content
                            )
                        else:
                            current_page.page_content = (
                                prev_page.page_content + " " + current_page.page_content
                            )
                        temptext = ""
                else:  # not a NarrativeText
                    delete_indices.add(i)

                    # Concatenate page content of both pages and add the index of the previous page to delete_indices set
                    if prev_page.metadata.get("category") == "NarrativeText":
                        temptext += (
                            prev_page.page_content + " " + current_page.page_content
                        )
                        delete_indices.add(i - 1)
                    else:
                        temptext += " " + current_page.page_content
            else:
                if temptext != "":
                    prev_page.metadata["category"] = "NarrativeText"
                    prev_page.page_content = temptext
                    temptext = ""
                    delete_indices.remove(i - 1)

        # Deleting indices which are not required
        delete_indices = list(delete_indices)
        delete_indices.sort(reverse=True)

        for index in delete_indices:
            del text_elements[index]

        return text_elements

    def _process_unstructured_metadata(self, text_elements, table_elements):
        """This code selectively retains only the desired keys in the metadata of both text_elements and table_elements"""

        desired_keys = ["source", "page_number", "category"]

        for element in text_elements:
            element.metadata = {
                key: element.metadata[key]
                for key in desired_keys
                if key in element.metadata
            }

        for element in table_elements:
            element.metadata = {
                key: element.metadata[key]
                for key in desired_keys
                if key in element.metadata
            }

        # Renaming 'page_number' as 'page'
        for page in text_elements:
            page.metadata["page"] = page.metadata.pop("page_number")
        for page in table_elements:
            page.metadata["page"] = page.metadata.pop("page_number")

        return text_elements, table_elements

    def _get_documents_from_unstructured_loader(self):
        """This function load the documents by taking filename as argument and processes them."""

        loader = UnstructuredFileLoader(
            self.filename, mode="elements", strategy="hi_res"
        )
        pages = loader.load()

        # Logic for adding previous Titles to tables if exists
        pages = self._table_title_merge(pages)

        # Logic to separating table and text elements
        table_elements, text_elements = self._get_table_text_elements(pages)

        # Logic for merging among text_elements
        text_elements = self._process_and_refine_text_elements(text_elements)

        # Cleaning metadata
        text_elements, table_elements = self._process_unstructured_metadata(
            text_elements, table_elements
        )

        # Chunking the text_elements
        documents = self._get_documents_chunk(text_elements)

        # Concatenating un-chunked table_elements to chunked text_elements
        documents.extend(table_elements)

        return documents

    def _get_documents_chunk(self, pages):
        "this function returns the chunks and metadata based on chunk size and overlap by taking list of document as argument"
        try:
            text_splitter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
                separators=self.separators,
            )
            return text_splitter.split_documents(pages)

        except Exception as e:
            logger.error(str(e))
            raise ChunkingException(f"Error while creating the chunks: {str(e)}")

    def _get_page_metadata(self, metadata, keys_to_exclude_for_ppt, batch=0):
        """This function returns the updated metadata by stacking the custom metadata received in the request"""
        updated_metadata = []

        for index, item in enumerate(metadata):
            custom_metadata = {}
            for key, value in item.items():
                if key in keys_to_exclude_for_ppt:
                    pass
                else:
                    if key == "page" and self.file_type in [".pdf", ".docx"]:
                        custom_metadata[key] = value + 1
                    elif key == "page_number" and self.file_type in [".pptx", ".ppt"]:
                        custom_metadata["page"] = value
                    else:
                        custom_metadata[key] = value

            custom_metadata = {
                **dict(custom_metadata.items()),
                **dict(self.cust_metadata.items()),
                "batch": batch,
                "chunk_no": index,
            }

            updated_metadata.append(custom_metadata)

        return updated_metadata

    async def process_files(self):
        """This function is the main function which is responsible to process the files and return the page contents and metadata
        with flag that says we need to ingest in loop or directly once"""
        try:

            documents = (
                self._get_documents_from_unstructured_loader()
                if self.is_unstructured_loader_enabled
                else self._get_documents()
            )

            large_file = False
            batch_size = 16
            len_texts = len(documents)
            keys_to_exclude_for_ppt = [
                "file_directory",
                "last_modified",
                "category",
                "filetype",
                "source",
                "text_as_html",
                "page_name",
            ]

            if len_texts <= batch_size:
                page_content = [document.page_content for document in documents]
                page_metadata = [document.metadata for document in documents]

                updated_metadata = (
                    self._updating_metadata_for_word(page_metadata)
                    if self.file_type == ".docx"
                    else page_metadata
                )

                metadata = self._get_page_metadata(
                    updated_metadata, keys_to_exclude_for_ppt
                )

            else:
                large_file = True
                page_content_list = [document.page_content for document in documents]
                page_metadata = [document.metadata for document in documents]
                page_content = [
                    page_content_list[i : i + 15]
                    for i in range(0, len(page_content_list), 15)
                ]
                metadata_sublists = [
                    page_metadata[i : i + 15] for i in range(0, len(page_metadata), 15)
                ]
                metadata = [
                    self._get_page_metadata(sublist, keys_to_exclude_for_ppt, batch=idx)
                    for idx, sublist in enumerate(metadata_sublists)
                ]

        except Exception as e:
            logger.error(e)
            raise ChunkingException(f"Error while chunking the file, {str(e)}")

        return page_content, metadata, large_file
