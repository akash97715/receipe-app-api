from sqlalchemy.orm import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os

db_username = os.getenv("DB_USERNAME", "null")
db_password = os.getenv("DB_PASSWORD", "null")
db_endpoint = os.getenv("DB_ENDPOINT", "null")
db_name = os.getenv("DB_NAME", "null")


db_conn = f"postgresql://{db_username}:{db_password}@{db_endpoint}:5432/{db_name}"
engine = create_engine(
    db_conn,
    echo=False,
)


Base = declarative_base()

SessionLocal = sessionmaker(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
