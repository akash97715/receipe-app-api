from pydantic import BaseModel, Field
from datetime import datetime


class Clientidmap(BaseModel):
    client_id: str
    usecase: str
    queue: str
    index: str
    openserachclusterdetail: str
    secretmanagerarn: str
    crossaccountrolearn: str


class Data_Ingestion_Status_Table(BaseModel):
    client_id: str
    request_id: str
    index: str
    document: str
    document_md5: str
    attached_metadata: str
    status: str
    error_message: str
    queued_ts: datetime.datetime
    inprogress_ts: datetime.date
    completed_errored_ts: datetime.date
