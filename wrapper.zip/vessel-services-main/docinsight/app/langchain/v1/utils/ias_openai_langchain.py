from typing import Any, List, Mapping, Optional

from langchain.llms.base import LLM
import json
import os
import backoff

from fastapi import HTTPException
import httpx
from langchain.embeddings.base import Embeddings
import requests

from app.utils.custom_loguru import logger
from app.utils.custom_httpx import CustomHttpX


httpx_client = CustomHttpX()

CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")
PINGFEDERATE_URL = os.environ.get("PINGFEDERATE_URL", "")
IAS_OPENAI_CHAT_URL = os.environ.get("IAS_OPENAI_CHAT_URL", "")
IAS_OPENAI_URL = os.environ.get("IAS_OPENAI_URL", "")
IAS_EMBEDDINGS_URL = os.environ.get("IAS_EMBEDDINGS_URL", "")
IAS_BEDROCK_URL = os.getenv("IAS_BEDROCK_URL")


# To Raise Generic OPENAI EMBEDDING ERROR
class GenericException(Exception):
    pass


def federate_auth() -> str:
    """Obtains auth access token for accessing GPT endpoints"""
    try:
        payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }
        response = requests.post(PINGFEDERATE_URL, headers=headers, data=payload)
        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI access token API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling OpenAI access token API: {response.status_code}, {response.json()}"
            )

        token = response.json()["access_token"]
        return token
    except httpx.TimeoutException as e:
        logger.error(f"Federate Auth Timeout {e}")
        raise HTTPException(status_code=408, detail=f"Error: Federate Auth Timeout")
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        raise e


@backoff.on_exception(backoff.expo, GenericException, max_tries=20, max_time=60)
def ias_openai_chat_completion(
    token: str,
    user_message: str,
    engine: str,
    temperature: float,
    max_tokens: int,
    system_message: str = None,
) -> str:
    """
    Generates a chat completion response for OpenAI model
    :param token: auth token
    :param user_message: user's prompt
    :param engine: model capable for chat completion i.e. gpt*
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :return: response from OpenAI model
    """
    try:
        payload = {
            "engine": engine,
            "messages": [
                {"role": "user", "content": user_message},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if system_message:
            payload["messages"].insert(0, {"role": "system", "content": system_message})

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }
        logger.info("Calling chat completion endpoint")
        response = requests.post(IAS_OPENAI_CHAT_URL, headers=headers, json=payload)

        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI chat completion  API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling OpenAI chat completion  API: {response.status_code}, {response.json()}"
            )

        logger.info("Recevied response from llm")
        logger.info(response.json())
        chat_completion = json.loads(response.json()["result"])["content"]

        return chat_completion
    except Exception as e:
        logger.error("Got the Exception", str(e))
        # raising backoff exception
        raise GenericException(e)


@backoff.on_exception(backoff.expo, GenericException, max_tries=20, max_time=60)
def ias_openai_completion(
    token: str, user_message: str, engine: str, temperature: float, max_tokens: int
) -> str:
    """
    Generates a completion response for OpenAI model
    :param token: auth token
    :param user_message: user's prompt
    :param engine: model capable for completion
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :return: response from OpenAI model
    """
    try:
        payload = {
            "engine": engine,
            "prompt": user_message,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

        response = requests.post(IAS_OPENAI_URL, headers=headers, json=payload)

        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI completion  API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling OpenAI completion  API: {response.status_code}, {response.json()}"
            )

        completion_resp = response.json()
        completion = completion_resp["result"]
        return completion
    except Exception as e:
        logger.error("Got the Exception", str(e))
        # raising backoff exception
        raise GenericException(e)


@backoff.on_exception(backoff.expo, GenericException, max_tries=20, max_time=60)
def ias_openai_embeddings(token: str, raw_text, engine: str):
    try:
        url = IAS_EMBEDDINGS_URL
        payload = {"input": raw_text, "engine": engine}
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
        }
        logger.info("Triggering embedding endpoint")
        response = requests.post(url, headers=headers, json=payload)

        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI embedding API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling OpenAI embedding API: {response.status_code}, {response.json()}"
            )

        embeddings = json.loads(response.json()["result"])
        logger.info("Recevied response from embedding endpoint")

        return embeddings
    except Exception as e:
        logger.error("Got the Exception", str(e))
        # raising backoff exception
        raise GenericException(e)


class IASOpenaiLLM(LLM):
    """Wrapper for IAS secured OpenAI completion API"""

    engine: str
    temperature: float
    max_tokens: int

    @property
    def _llm_type(self) -> str:
        return "IAS_OpenAI"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
    ) -> str:
        token = federate_auth()
        response = ias_openai_completion(
            token, prompt, self.engine, self.temperature, self.max_tokens
        )
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        params = {
            "engine": self.engine,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        return params


class IASOpenaiConversationalLLM(LLM):
    """Wrapper for IAS secured OpenAI chat API"""

    engine: str
    temperature: float
    max_tokens: int
    system_message: str = None

    @property
    def _llm_type(self) -> str:
        return "IAS_OpenAI"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
    ) -> str:
        token = federate_auth()
        response = ias_openai_chat_completion(
            token,
            prompt,
            self.engine,
            self.temperature,
            self.max_tokens,
            self.system_message,
        )
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        params = {
            "engine": self.engine,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        return params


class IASOpenaiEmbeddings(Embeddings):
    """Wrapper for IAS secured OpenAI embedding API"""

    engine = str

    def __init__(self, engine):
        self.engine = engine

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embeddings search docs."""
        # NOTE: to keep things simple, we assume the list may contain texts longer
        #       than the maximum context and use length-safe embedding function.

        token = federate_auth()

        response = ias_openai_embeddings(token, texts, self.engine)

        # Extract the embeddings
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings

    def embed_query(self, text: str) -> List[float]:
        """Embeddings  query text."""
        token = federate_auth()
        response = ias_openai_embeddings(token, text, self.engine)
        # print(response)

        # Extract the embeddings and total tokens
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings[0]


@backoff.on_exception(backoff.expo, GenericException, max_tries=20, max_time=60)
def ias_bedrock_completion(
    token: str,
    user_message: str,
    model: str,
    temperature: float,
    max_tokens: int,
    system_message: str = None,
) -> str:
    """
    Generates a completion response for Bedrock model
    :param token: auth token
    :param user_message: user's prompt
    :param model: model capable for completion
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :param system_message: system's prompt for instructions to the LLM
    :return: response from Bedrock model
    """
    try:
        if model.startswith("anthropic"):
            user_message = f"\n\nHuman:{user_message}\n\nAssistant:"
        elif model.startswith("amazon"):
            user_message = f"\n\nUser:{user_message}\n\nBot:"

        payload = {
            "model": model,
            "prompt": user_message,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if system_message:
            payload["prompt"] = " ".join([system_message, user_message])

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }
        logger.info("Calling IAS Bedrock completion API")
        response = requests.post(IAS_BEDROCK_URL, headers=headers, json=payload)

        if response.status_code != 200:
            logger.error(
                f"Error calling IAS Bedrock completion API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling IAS Bedrock completion API: {response.status_code}, {response.json()}"
            )

        logger.info("Completion created from IAS Bedrock completion API")
        completion_resp = response.json()
        completion = completion_resp["result"]
        return completion
    except Exception as e:
        logger.error(f"Exception calling IAS Bedrock Completion API: {str(e)}")
        raise GenericException(e)


class IASBedrockLLM(LLM):
    """Wrapper for IAS secured Bedrock completion API"""

    model: str
    temperature: float
    max_tokens: int
    system_message: str = None

    @property
    def _llm_type(self) -> str:
        return "IAS_Bedrock"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
    ) -> str:
        token = federate_auth()

        response = ias_bedrock_completion(
            token,
            prompt,
            self.model,
            self.temperature,
            self.max_tokens,
            self.system_message,
        )
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        params = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        return params
