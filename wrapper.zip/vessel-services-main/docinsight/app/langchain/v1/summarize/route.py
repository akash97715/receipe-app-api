from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    BackgroundTasks,
    Query,
    Request as fastapi_request,
)
from typing import Annotated
from sqlalchemy.orm import Session
import uuid
from app.langchain.v1.models import (
    SummarizeRequest,
    SummarizeResponse,
    Status,
    SummarizeStatusRequest,
)
from app.langchain.database import get_db
from app.utils.custom_loguru import logger, configure_logger
from app.langchain.v1.summarize.controller import SummarizeDocument, SummarizeStatus
from app.langchain.v1.helper import (
    client_id_info
)

from validator.decorators import async_token_validation_and_metering

router = APIRouter()


@router.post(
    "/summarize",
    status_code=200,
    tags=["Summarize Document"],
    description="This endpoint is used to summarize the given document",
)
@async_token_validation_and_metering()
async def summarize_document(
    request: fastapi_request,
    request_payload: SummarizeRequest,
    background_task: BackgroundTasks,
    db: Session = Depends(get_db),
):
    try:
        logger.info("Fetching request headers for /summarize endpoint")
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )

        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )
        
        flag = False
        if request_payload.index_document_map:
            if len(list(request_payload.index_document_map.values())[0]) > 1:
                flag = True

        if request_payload.metadata and request_payload.metadata.documentmd5:
            if len(request_payload.metadata.documentmd5) > 1:
                flag = True

        if request_payload.metadata and request_payload.metadata.document:
            if len(request_payload.metadata.document) > 1:
                flag = True

        if flag == True:
            raise HTTPException(
                status_code=400,
                detail="More than one document information is passed in request",
            )

        summarize_document = SummarizeDocument(client_id, request_payload, db)

        logger.info("Preparing final index md5 dict based on use case")
        final_index_md5_dict = summarize_document.get_indices_and_md5()

        if len(list(final_index_md5_dict.values())[0]) > 1:
            raise HTTPException(
                status_code=400,
                detail="More than one document information is passed in request",
            )

        summarize_document.assign_index_and_md5(final_index_md5_dict)
        request_id = str(uuid.uuid4())

        db_response = summarize_document.is_summary_exists()

        if (
            db_response["is_summary_info_present"] == True
            and "request_status" in db_response.keys()
            and db_response["request_status"] != "Error"
        ):
            logger.info("Returning Summary from db")
            return SummarizeResponse(
                status=Status.success,
                request_status=db_response["request_status"],
                llm_response=db_response["summary"],
                citation=[],
                requestid=request_id,  # Send the request id generated for this request
                totaltokensllm=db_response["total_tokens_llm"],
                totaltokensembedding=0,
            )

        else:
            logger.info("Adding summary request to db and summarizing the document")
            summarize_document.add_summarize_request_to_db(request_id)
            background_task.add_task(summarize_document.summarize)

            return SummarizeResponse(
                status=Status.success,
                request_status="InProgress",
                llm_response="",
                citation=[],
                requestid=request_id,
                totaltokensllm=0,
                totaltokensembedding=0,
            )

    except Exception as e:
        raise e


@router.post(
    "/summarization-status",
    status_code=200,
    tags=["API Module Service"],
    description="This endpoint is used to return the status of the summarization of the given document",
)
@async_token_validation_and_metering()
async def get_summarization_status(
    request: fastapi_request,
    request_payload: SummarizeStatusRequest,
    db: Session = Depends(get_db),
):
    try:
        logger.info("Fetching request headers for /summarization-status endpoint")
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )
        client_id_list=client_id_info(client_id=client_id,db=db)
        logger.info("Request received at summarization-status api", client_id)

        return SummarizeStatus.get_status(client_id_list, request_payload.request_ids, db)

    except Exception as e:
        raise e
