from opensearchpy import OpenSearch, OpenSearchException
from app.utils.custom_loguru import logger


def delete_documents(os_client: OpenSearch, document_info: dict):
    try:
        if document_info["status"] == "Completed":
            md5 = document_info["md5"]
            index = document_info["index"]
            query = {
                "query": {
                    "bool": {
                        "filter": {
                            "bool": {
                                "must": [{"match_phrase": {"metadata.md5": f"{md5}"}}]
                            }
                        }
                    }
                }
            }
            size = os_client.count(body=query, index=index)["count"]

            response = os_client.search(body=query, index=index, size=size)

            hits = response["hits"]["hits"]

            if hits:
                payload_list = [
                    {"index": hit["_index"], "id": hit["_id"]} for hit in hits
                ]
                bulk_request = [
                    {"delete": {"_index": doc["index"], "_id": doc["id"]}}
                    for doc in payload_list
                ]
                response = os_client.bulk(body=bulk_request)
                document_info["message"] = "Successfully deleted from Vectordb"
                document_info["status"] = True

                return document_info
            else:
                document_info["message"] = "Not Found in Vectordb"
                document_info["status"] = False
                return document_info
        else:
            document_info["message"] = "Not Found in Vectordb"
            document_info["status"] = False
            return document_info

    except Exception as e:
        logger.error(str(e))
        raise e
