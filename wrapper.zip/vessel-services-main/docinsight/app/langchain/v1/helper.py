import itertools
from urllib.error import HTTPError
from fastapi import HTTPException
from sqlalchemy.orm.session import Session
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sqlalchemy import func, and_

from app.langchain.v1.utils.ias_openai_langchain import (
    IASBedrockLLM,
    IASOpenaiConversationalLLM,
)
import time
from langchain.chains import (
    ConversationalRetrievalChain,
)
from langchain.vectorstores import OpenSearchVectorSearch
from langchain.schema import BaseRetriever
from sqlalchemy import func, and_
from sqlalchemy.orm import aliased
from opensearchpy import ImproperlyConfigured, OpenSearch, OpenSearchException
import ast
import boto3
import datetime
import uuid, hashlib, urllib
import os
from langchain.retrievers.merger_retriever import MergerRetriever
from app.langchain.models import DataIngestionStatusTableNew

from app.utils.custom_loguru import logger
from app.langchain.models import ClientMapping


def create_chat_history(context: list):
    try:
        chat_hist = []
        context_len = len(context)
        context.reverse()
        if context_len <= 1:
            return chat_hist
        else:
            for item in range(0, context_len - 1, 2):
                chat_hist.append((context[item], context[item + 1]))
        return chat_hist

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while creating chat history")


def calculate_consumed_token(llm_response):
    # calculate total tokens for questions
    try:
        tokens_in_questions = len(llm_response["question"].split())
        # calculate total tokens for answer
        tokens_in_answer = len(llm_response["answer"].split())
        # calculate total tokens for chat history
        token_in_history = sum(
            sum(len(itr) for itr in history) for history in llm_response["chat_history"]
        )
        # calculate total tokens for document chunks
        token_in_documents = sum(
            len(doc.page_content) for doc in llm_response["source_documents"]
        )
        # calculate total token consumed by adding all the token in questions history and documents, and return the same
        return [
            (token_in_history + tokens_in_questions + tokens_in_answer),
            token_in_documents,
        ]
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(
            status_code=500, detail="Error in calculating consumed token"
        )


def read_secret_manager_and_return_dict(SECRET_NAME: str, us: str, pw: str):
    secret_value = None
    try:
        secret_client = boto3.client("secretsmanager")

        secret_response = secret_client.get_secret_value(SecretId=SECRET_NAME)

        if "SecretString" in secret_response:
            secret_value = secret_response["SecretString"]

            finj = secret_value
            conv1 = ast.literal_eval(finj)
            pwd = conv1[pw]
            usd = conv1[us]

        return secret_value, pwd, usd

    except Exception as e:
        logger.error(str(e))
        raise e


def fetch_actual_doc(client_id: str, grabber: list, db: Session):
    try:
        val_to_fetch = grabber
        max_timestamp_subquery = (
            db.query(
                DataIngestionStatusTableNew.document,
                func.max(DataIngestionStatusTableNew.completed_errored_ts).label(
                    "max_timestamp"
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.document.in_(val_to_fetch),
                DataIngestionStatusTableNew.status == "Completed",
            )
            .group_by(DataIngestionStatusTableNew.document)
            .subquery()
        )
        files = (
            db.query(DataIngestionStatusTableNew)
            .join(
                max_timestamp_subquery,
                and_(
                    DataIngestionStatusTableNew.document
                    == max_timestamp_subquery.c.document,
                    DataIngestionStatusTableNew.completed_errored_ts
                    == max_timestamp_subquery.c.max_timestamp,
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.document.in_(val_to_fetch),
                DataIngestionStatusTableNew.status == "Completed",
            )
            .all()
        )

        if len(files) != 0:
            file_safe_values_custom = [file.document_md5 for file in files]
            return file_safe_values_custom
        else:
            logger.info("No Document Found")

        return []
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while fetching document")


def fetch_actual_md5(md5_list: list, indices: list, db: Session, client_id_list: list):

    try:

        # Filter for specific indexes
        files = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
                DataIngestionStatusTableNew.index.in_(indices),
                DataIngestionStatusTableNew.document_md5.in_(md5_list),
                DataIngestionStatusTableNew.status == "Completed",
            )
            .all()
        )

        if len(files):
            document_md5_list = list(set([file.document_md5 for file in files]))
            return document_md5_list
        else:
            logger.info("No Documents MD5 Found")

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while fetching actual md5")


def fetch_actual_meta_latest(client_id: str, grabber: dict, db: Session):
    try:
        val_to_fetch = grabber
        max_timestamp_subquery = (
            db.query(
                DataIngestionStatusTableNew.attached_metadata,
                func.max(DataIngestionStatusTableNew.completed_errored_ts).label(
                    "max_timestamp"
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.status == "Completed",
            )
            .group_by(DataIngestionStatusTableNew.attached_metadata)
            .subquery()
        )

        # Main query to join with the subquery and retrieve the latest record for the specified client_id and completed status
        files = (
            db.query(DataIngestionStatusTableNew)
            .join(
                max_timestamp_subquery,
                and_(
                    DataIngestionStatusTableNew.attached_metadata
                    == max_timestamp_subquery.c.attached_metadata,
                    DataIngestionStatusTableNew.completed_errored_ts
                    == max_timestamp_subquery.c.max_timestamp,
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.status == "Completed",
            )
            .all()
        )

        if len(files):
            mat_recrd = []
            justo = [file.attached_metadata for file in files]

            for dctnry in justo:
                conv = ast.literal_eval(dctnry)

                if any(k in conv and conv[k] == v for k, v in val_to_fetch.items()):
                    mat_recrd.append(conv.get("md5", None))

            return mat_recrd
        else:
            logger.info("No Documents meta")

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(
            status_code=500, detail="Error in fetching attached metadata"
        )


def extract_data(restui):
    try:
        for hit in restui["hits"]["hits"]:
            yield hit["_source"]["text"], hit["_source"]["metadata"]
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while yielding hits")


def request_generation():
    try:
        request_id = uuid.uuid4()
        return str(request_id)
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while generating request")


def index_generation():
    m = hashlib.md5(str(uuid.uuid4()).encode("UTF-8"))
    index_value = m.hexdigest()
    return index_value


def fetch_file_from_s3_using_purl(presigned_url):
    try:
        # Parse the URL
        parsed_url = urllib.parse.urlparse(presigned_url)
        # Extract the filename from the last segment of the path
        path_segments = parsed_url.path.split("/")
        filename_temp = path_segments[-1]
        # Decode the filename to handle special characters
        filename_temp = urllib.parse.unquote(filename_temp)
        current_timestamp = str(int(time.time()))
        filetype = os.path.splitext(filename_temp)[
            1
        ]  # Get the file extension, including the dot
        basename = os.path.splitext(filename_temp)[
            0
        ]  # Get the base filename (without extension
        filename = f"{basename}_{current_timestamp}{filetype}"

        with urllib.request.urlopen(presigned_url) as response:
            file_content = response.read()

        with open(filename, "wb") as local_file:
            local_file.write(file_content)

        logger.info(f"Document fetched and saved locally as {filename}")
        return filename, filename_temp
    except Exception as e:
        logger.error(f"Error fetching document from S3: {str(e)}")
        raise e


def calculate_md5_hash(filename, chunk_size=8192):
    try:
        logger.info(f"Calculating MD5 for {filename}")
        with open(filename, "rb") as f:
            md5_hash = hashlib.md5()
            while chunk := f.read(chunk_size):
                md5_hash.update(chunk)

        return md5_hash.hexdigest()
    except Exception as e:
        logger.error(str(e))
        logger.error("Error in calculating md5 hash value: ", exc_info=True)
        raise e


def insert_msg_in_sqs_queue(queue_name, msg_json):
    """
    Insert the message into the SQS Queue
    """
    try:
        sqs = boto3.client("sqs")

        response_get_url = sqs.get_queue_url(QueueName=queue_name)

        # Extract the queue URL from the response
        queue_url = response_get_url["QueueUrl"]

        # Insert Message in the Queue
        insert_response = sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=msg_json,
            MessageGroupId="DocInsightsGroup",
            MessageDeduplicationId=str(uuid.uuid4()),
        )
        if insert_response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(
                "Message Inserted Successfully in the Queue : " + str(queue_name)
            )
        else:
            raise Exception(
                "Improper HTTPResponseCode received while inserting message from SQS queue."
            )
    except Exception as e:
        raise e


def Validation_error():
    validation_dict = {}

    validation_dict[
        "src_document_path"
    ] = "src_document_path must not be empty and should contain presigned url value"
    validation_dict[
        "client_id"
    ] = "client_id should be integer and should not have empty space"
    validation_dict[
        "index"
    ] = "index can be empty for non VOX cases and must not contain empty space in it"
    validation_dict[
        "engine"
    ] = "engine is an optional field and if specified must contain text-embedding-ada-002"
    validation_dict[
        "document_chunk_size"
    ] = "document_overlap_size is an optional field and if passed must contain token less than 8197"
    validation_dict[
        "document_overlap_size"
    ] = "document_overlap_size is an optional field and if passed must be less than document_chunk_size 8197"
    validation_dict[
        "duplication"
    ] = "this index and md5 combination already exist please upload new document"
    validation_dict[
        "file_type"
    ] = "The supported documents formats are ['.pdf', '.docx', '.pptx']"
    return validation_dict


def create_retriever(
    index_doc_map,
    embeddings,
    AWS_OPENSEARCH_HOST,
    AWS_OPENSEARCH_USERNAME,
    AWS_OPENSEARCH_PASSWORD,
    no_of_doc,
):
    if len(index_doc_map) > 1:
        retrievers = [
            OpenSearchVectorSearch(
                index_name=index_name,
                embedding_function=embeddings if embeddings else None,
                opensearch_url=AWS_OPENSEARCH_HOST,
                http_auth=(AWS_OPENSEARCH_USERNAME, AWS_OPENSEARCH_PASSWORD),
                is_aoss=False,
            ).as_retriever(
                search_kwargs={
                    "filter": {"terms": {"metadata.md5": index_doc_map[index_name]}},
                    "k": no_of_doc,
                }
            )
            for index_name in index_doc_map.keys()
        ]
        return MergerRetriever(retrievers=retrievers)
    else:
        index_name = next(iter(index_doc_map.keys()))  # Get the first index name
        search_kwargs = {
            "filter": {"terms": {"metadata.md5": index_doc_map[index_name]}},
            "k": no_of_doc,
        }
        return OpenSearchVectorSearch(
            index_name=index_name,
            embedding_function=embeddings if embeddings else None,
            opensearch_url=AWS_OPENSEARCH_HOST,
            http_auth=(AWS_OPENSEARCH_USERNAME, AWS_OPENSEARCH_PASSWORD),
            is_aoss=False,
        ).as_retriever(search_kwargs=search_kwargs)


def get_llm_response(
    vector_db,
    llm_engine: str,
    temperature: float,
    max_tokens: int,
    context: list,
    user_query: str,
    num_of_citations: int,
    files_md5: list,
    system_message: str = None,
    filter_citations=True,
):
    try:
        if llm_engine.startswith("gpt"):
            qa = ConversationalRetrievalChain.from_llm(
                IASOpenaiConversationalLLM(
                    engine=llm_engine,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    system_message=system_message,
                ),
                chain_type="stuff",
                retriever=vector_db,
                return_source_documents=True,
            )
        elif llm_engine.startswith("amazon") or llm_engine.startswith("anthropic"):
            qa = ConversationalRetrievalChain.from_llm(
                IASBedrockLLM(
                    model=llm_engine,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    system_message=system_message,
                ),
                chain_type="stuff",
                retriever=vector_db,
                return_source_documents=True,
            )

        chat_history = create_chat_history(context)

        llm_response = qa({"question": user_query, "chat_history": chat_history})
        total_token = calculate_consumed_token(llm_response)

        if llm_response is None:
            raise HTTPException(
                status_code=400,
                detail="Some issue with Search API. Report to IAS please",
            )

        matching_texts = [
            {"text": doc.page_content, "metadata": doc.metadata}
            for doc in llm_response["source_documents"]
        ]

        #########ONE SCENARIO##########
        llm_answer = llm_response["answer"]
        PRESENT = False

        keywords = [
            "don't know",
            "no information",
            "no relevant text",
            "context does not mention anything",
            "context is not specified",
            "does not provide information",
            "not possible to determine",
            "does not provide any information",
            "sorry",
            "don't",
            "does not",
        ]

        if filter_citations:
            for string in keywords:
                if string in llm_answer:
                    PRESENT = True
                    break

        if PRESENT:
            citation_basic = []
            answer = llm_answer
        else:
            answer = llm_answer
            citation_basic = matching_texts[: int(num_of_citations)]

        return answer, citation_basic, total_token
    except Exception as e:
        logger.error("Failed while getting llm response")
        raise e


def get_vector_db_details(client_id: str, db):
    client_info = (
        db.query(ClientMapping)
        .filter(ClientMapping.client_id == f"{client_id}")
        .first()
    )

    if client_info is None:
        raise HTTPException(
            status_code=400,
            detail=f"Provided Client id -->{client_id} does not exist in mapping table, please provide the correct client_id to use search API.",
        )

    vector_db_details = client_info.vectorDBdetails
    db_info = ast.literal_eval(vector_db_details)
    AWS_OPENSEARCH_HOST = db_info["vectorDBAccessURL"]

    (
        _,
        AWS_OPENSEARCH_PASSWORD,
        AWS_OPENSEARCH_USERNAME,
    ) = read_secret_manager_and_return_dict(
        SECRET_NAME=db_info["Secretdetails"],
        us=db_info["UserNameVar"],
        pw=db_info["PasswordVar"],
    )

    return (
        AWS_OPENSEARCH_HOST,
        AWS_OPENSEARCH_USERNAME,
        AWS_OPENSEARCH_PASSWORD,
    )


def client_id_info(client_id, db):
    client_info = (
        db.query(ClientMapping)
        .filter(ClientMapping.client_id == f"{client_id}")
        .first()
    )
    if client_info.usecase.lower() == "vox":
        client_id_list = client_info.alternate_client_ids
    else:
        client_id_list = [client_id]
    return client_id_list

