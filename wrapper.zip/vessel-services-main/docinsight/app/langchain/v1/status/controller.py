from datetime import datetime
from fastapi import APIRouter, HTTPException

from app.langchain.v1.models import UpdateIngestionStatus

from app.langchain.models import DataIngestionStatusTableNew

from app.utils.custom_loguru import logger

router = APIRouter()


class UpdateIngestionTable:
    @staticmethod
    def update_ingestion_table(request_payload: UpdateIngestionStatus, db):
        try:
            client_id = request_payload.client_id
            request_id = request_payload.request_id
            error_msg = request_payload.error_message
            status = request_payload.status

            ingestion_info = (
                db.query(DataIngestionStatusTableNew)
                .filter(
                    DataIngestionStatusTableNew.client_id == client_id,
                    DataIngestionStatusTableNew.request_id == request_id,
                )
                .first()
            )

            if ingestion_info:
                if ingestion_info.status != "Error":
                    logger.info(
                        f"Updating Status for Client ID {client_id} with Request ID {request_id}"
                    )
                    db.query(DataIngestionStatusTableNew).filter(
                        DataIngestionStatusTableNew.client_id == client_id,
                        DataIngestionStatusTableNew.request_id == request_id,
                    ).update(
                        {
                            "status": status,
                            "error_message": error_msg,
                            "completed_errored_ts": datetime.datetime.utcnow(),
                        }
                    )

                    db.commit()

            else:
                raise HTTPException(
                    status_code=400,
                    detail=f"Given Client ID {client_id} and Request ID {request_id} not found in database",
                )

        except Exception:
            raise HTTPException(
                status_code=500,
                detail="Error in updating status in the database",
            )
