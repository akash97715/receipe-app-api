from enum import Enum
from typing import List, Optional, Union, Dict, Literal
from typing import Optional
from pydantic import BaseModel, Field, ConstrainedList, constr
from enum import Enum


from datetime import datetime


class Status(str, Enum):
    failure = "failure"
    success = "success"


class Order_By(str, Enum):
    ASC = "ASC"
    DESC = "DESC"


class metadata(BaseModel):
    same_metadata_key_1: str
    same_metadata_key_2: str


class metadata(BaseModel):
    document: Optional[List[str]]
    documentmd5: Optional[List[str]]
    metadata: Optional[Dict[str, str]]


class HealthCheckResponse(BaseModel):
    status: Status
    message: str


class QueryEmbeddingsRequest(BaseModel):
    user_query: str
    system_message: Optional[str]
    index_document_map: Optional[Dict[str, List[str]]]
    context: Optional[List[str]]
    temperature: Optional[float] = 0
    max_tokens: Optional[int]
    llm_engine: Optional[str] = "gpt-35-turbo-16k"
    embedding_engine: Optional[str] = "text-embedding-ada-002"
    llm_response_flag: Optional[bool] = Field(default=True)
    similarity_search_algo: Optional[str]
    metadata: Optional[metadata]
    num_of_citations: Optional[int] = Field(default=5)
    filter: Optional[str] = "post"
    with_score: Optional[bool] = Field(default=False)
    filter_citations: Optional[bool] = Field(default=True)


class QueryEmbeddingsResponse(BaseModel):
    status: Status
    llm_response: str
    citation: Union[List[dict], List[str]]
    requestid: str
    totaltokensllm: int
    totaltokensembedding: int


class DocumentIngestRequest(BaseModel):
    src_document_path: Optional[str]
    chunking_strategy: Optional[List[Literal["\n\n", "\n", " ", ""]]] = [
        "\n\n",
        "\n",
        " ",
        "",
    ]
    index: Optional[List[str]] = []
    engine: Optional[str] = "text-embedding-ada-002"
    metadata: Optional[Dict[str, str]] = None
    document_chunk_size: Optional[int] = 1000
    document_overlap_size: Optional[int] = 100
    custom_vector_db_params_json: Optional[str] = None


class DocumentIngestResponse(BaseModel):
    status: Status
    requestID: Optional[str] = None
    Failed_request_reason: Optional[str] = None
    client_id: Optional[str] = None
    request_status: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None
    queued_timestamp: Optional[datetime] = None


class DocumentEmbeddingsRequest(BaseModel):
    src_document_path: str
    chunking_strategy: Optional[List[Literal["\n\n", "\n", " ", ""]]] = [
        "\n\n",
        "\n",
        " ",
        "",
    ]
    client_id: str
    requestID: str
    engine: str = "text-embedding-ada-002"
    index: List[str] = []
    metadata: Optional[Dict[str, str]]
    document_chunk_size: int
    document_overlap_size: int


class DocumentEmbeddingsResponse(BaseModel):
    status: Status
    index: List[str]
    request_id: str


class DeleteRequest(BaseModel):
    request_ids: List[str]


class DeleteResponse(BaseModel):
    delete_status: List[Dict[str, str]]


class IngestionInfoResponse(BaseModel):
    request_id: str
    index: str
    document_name: str
    document_md5: str
    attached_metadata: str
    status: str
    error_msg: str
    is_file_deleted: bool


class UpdateIngestionStatus(BaseModel):
    client_id: str
    request_id: str
    status: str
    error_message: str


class SummarizeRequest(BaseModel):
    index_document_map: Optional[Dict[str, List[str]]]
    metadata: Optional[metadata]
    temperature: Optional[float] = 0
    max_tokens: Optional[int]
    llm_engine: Optional[str] = "gpt-35-turbo-16k"
    embedding_engine: Optional[str] = "text-embedding-ada-002"


class SummarizeResponse(BaseModel):
    status: Status
    request_status: str
    llm_response: str
    citation: Union[List[dict], List[str]]
    requestid: str
    totaltokensllm: int
    totaltokensembedding: int


class SummarizeStatusRequest(BaseModel):
    request_ids: List[str]


class SummarizeStatusRequest(BaseModel):
    request_ids: List[str]


class SummarizeStatusResponse(BaseModel):
    status: Status
    request_status: str
    error_message: str
    client_id: str
    request_id: str
    index: str
    document_md5: str
    engine: str
    temperature: float
    summary: str
    total_tokens_llm: int
