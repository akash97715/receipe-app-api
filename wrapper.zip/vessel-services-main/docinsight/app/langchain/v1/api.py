import pathlib
import time
from fastapi import Request as fastapi_request
from datetime import datetime
import json
import httpx
from typing import List, Dict, Optional, Union
import os
from fastapi import APIRouter, Depends
import ast
from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import desc
from langchain.vectorstores import OpenSearchVectorSearch
from opensearchpy import ImproperlyConfigured, OpenSearch, OpenSearchException
import uuid
from app.langchain.file_processor import (
    FileProcessor,
    ChunkingException,
    FileLoaderException,
)
from app.langchain.database import get_db

from app.langchain.v1.helper import (
    fetch_actual_doc,
    fetch_actual_md5,
    fetch_actual_meta_latest,
    insert_msg_in_sqs_queue,
    Validation_error,
    request_generation,
    index_generation,
    fetch_file_from_s3_using_purl,
    calculate_md5_hash,
    get_llm_response,
    get_vector_db_details,
    create_retriever,
    client_id_info,
)

from app.langchain.v1.index_helper import delete_documents

from app.langchain.v1.models import (
    Status,
    HealthCheckResponse,
    QueryEmbeddingsRequest,
    QueryEmbeddingsResponse,
    DocumentIngestRequest,
    DocumentIngestResponse,
    DocumentEmbeddingsRequest,
    DocumentEmbeddingsResponse,
    DeleteRequest,
    DeleteResponse,
    IngestionInfoResponse,
    Order_By,
)

from app.langchain.models import ClientMapping, DataIngestionStatusTableNew
from app.langchain.v1.utils.ias_openai_langchain import (
    IASOpenaiEmbeddings,
    IASOpenaiConversationalLLM,
)
from app.utils.custom_loguru import logger, configure_logger

from validator.decorators import async_token_validation_and_metering

Failed_validation = Validation_error()
router = APIRouter()


GEN_VEC_DB = os.environ.get("GEN_VEC_DB_DET", "")
ENV = os.environ.get("ENV", "")


@router.get(
    "/health",
    status_code=200,
    tags=["Health check"],
)
async def health_check():
    return HealthCheckResponse(status=Status.success, message="Healthy")


@router.post(
    "/search",
    status_code=200,
    tags=["text embeddings"],
    description="This performs the similarity search on opensearch vectordb and returns the best N results from the stored documents on an Index",
    response_model=QueryEmbeddingsResponse,
)
@async_token_validation_and_metering(uom=7)
async def search(
    request: fastapi_request, rw: QueryEmbeddingsRequest, db: Session = Depends(get_db)
):
    try:
        logger.info("Fetching request headers for /search endpoint")
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )

        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        logger.info(
            "req_received at search api",
            client_id,
            rw.index_document_map,
            rw.llm_engine,
            rw.embedding_engine,
            type(rw.index_document_map),
            rw.max_tokens,
        )

        logger.info("Fetching vectorDB details from database")

        client_info = (
            db.query(ClientMapping)
            .filter(ClientMapping.client_id == f"{client_id}")
            .first()
        )
        client_id_list = client_info.alternate_client_ids
        if client_info is None:
            raise HTTPException(
                status_code=400,
                detail=f"Provided Client id-->{client_id} does not exist in mapping table, please provide the correct client_id to use search API",
            )

        logger.info("Reading secret manager details")

        (
            AWS_OPENSEARCH_HOST,
            AWS_OPENSEARCH_USERNAME,
            AWS_OPENSEARCH_PASSWORD,
        ) = get_vector_db_details(client_id, db)

        request_id = str(uuid.uuid4())

        if client_info.usecase.lower() != "vox":
            logger.info(f"Assigning index for Non-VOX use-case: {client_info.index}")
            non_vox_index = client_info.index
        try:
            if client_info.usecase.lower() == "vox":
                logger.info("Assigning index for VOX use-case")
                index_look_up = rw.index_document_map
                md5_list = [
                    value for values in index_look_up.values() for value in values
                ]
                indices = list(index_look_up.keys())
                doc_md5_list = fetch_actual_md5(
                    client_id_list=client_id_list,
                    md5_list=md5_list,
                    indices=indices,
                    db=db,
                )

                if doc_md5_list is None:
                    raise HTTPException(
                        status_code=400,
                        detail="Provided Document MD5 does not exist in clientid Index mapping table. Please look into the request and make sure you are passing the correct MD5 of doc to include. Try with existing MD5",
                    )

                final_index_dict = {
                    index_name: [md5 for md5 in md5_list_lookup if md5 in doc_md5_list]
                    for index_name, md5_list_lookup in index_look_up.items()
                }

                logger.info("Final dict after db match", final_index_dict)

                vector_db_retreiver = create_retriever(
                    index_doc_map=final_index_dict,
                    embeddings=IASOpenaiEmbeddings(engine=rw.embedding_engine),
                    AWS_OPENSEARCH_HOST=AWS_OPENSEARCH_HOST,
                    AWS_OPENSEARCH_USERNAME=AWS_OPENSEARCH_USERNAME,
                    AWS_OPENSEARCH_PASSWORD=AWS_OPENSEARCH_PASSWORD,
                    no_of_doc=rw.num_of_citations,
                )
                answer, citation_basic, total_token = get_llm_response(
                    vector_db=vector_db_retreiver,
                    llm_engine=rw.llm_engine,
                    temperature=rw.temperature,
                    max_tokens=rw.max_tokens,
                    system_message=rw.system_message,
                    context=rw.context,
                    user_query=rw.user_query,
                    num_of_citations=rw.num_of_citations,
                    files_md5=doc_md5_list,
                    filter_citations=rw.filter_citations,
                )

            else:
                cus_meta = rw.metadata
                generic_index = non_vox_index
                generic_indices = [generic_index]
                # always be post filter
                file_to_include = []
                client_id_list = [client_id]

                if cus_meta.document:
                    val_to_fetch = cus_meta.document
                    act_doc = fetch_actual_doc(
                        client_id=client_id, grabber=val_to_fetch, db=db
                    )

                    if act_doc != None:
                        file_to_include.extend(act_doc)

                if cus_meta.documentmd5:
                    md5_list = cus_meta.documentmd5
                    act_doc_md5 = fetch_actual_md5(
                        client_id_list=client_id_list,
                        md5_list=md5_list,
                        indices=generic_indices,
                        db=db,
                    )

                    if act_doc_md5 != None:
                        file_to_include.extend(act_doc_md5)

                if cus_meta.metadata:
                    val_to_fetch = cus_meta.metadata

                    # Create a subquery to find the maximum timestamp for each unique metadata value
                    meta_list_street = fetch_actual_meta_latest(
                        client_id=client_id, grabber=val_to_fetch, db=db
                    )

                    if meta_list_street != None:
                        file_to_include.extend(meta_list_street)

                remote_index = generic_index
                final_index_dict = {}
                search_kwargs = None

                if len(file_to_include):
                    final_index_dict = {generic_index: list(set(file_to_include))}
                    search_kwargs = {
                        "terms": {"metadata.md5": final_index_dict[generic_index]}
                    }

                try:
                    vector_db = OpenSearchVectorSearch(
                        index_name=remote_index,
                        embedding_function=IASOpenaiEmbeddings(
                            engine=rw.embedding_engine
                        ),
                        opensearch_url=AWS_OPENSEARCH_HOST,
                        http_auth=(AWS_OPENSEARCH_USERNAME, AWS_OPENSEARCH_PASSWORD),
                        is_aoss=False,
                    )
                except Exception as e:
                    logger.error(
                        f"Error while creating OS Vector search object for '{remote_index}' index"
                    )
                    raise e

                if (
                    rw.llm_response_flag == False
                    and rw.filter in ["post", "pre"]
                    and rw.with_score == False
                ):
                    qa = vector_db.similarity_search(
                        query=rw.user_query, k=rw.num_of_citations, filter=search_kwargs
                    )
                    citation_basic = [
                        {"text": doc.page_content, "metadata": doc.metadata}
                        for doc in qa
                    ]

                    answer = "Vector db response is not passed to LLM. Below are the Simmilarity search results"
                    total_token = [0, 0]
                elif (
                    rw.llm_response_flag == False
                    and rw.filter in ["post", "pre"]
                    and rw.with_score == True
                ):
                    qa = vector_db.similarity_search_with_score(
                        query=rw.user_query, k=rw.num_of_citations, filter=search_kwargs
                    )
                    citation_basic = [
                        {
                            "page_content": doc[0].page_content,
                            "metadata": doc[0].metadata,
                            "score": doc[1],
                        }
                        for doc in qa
                    ]

                    answer = "Vector db response is not passed to LLM. Below are the Simmilarity search results"
                    total_token = [0, 0]
                elif (
                    rw.filter == "post" or rw.filter == "pre"
                ) and rw.llm_response_flag == True:
                    start_time = time.time()

                    vector_db_retreiver = create_retriever(
                        index_doc_map=final_index_dict,
                        embeddings=IASOpenaiEmbeddings(engine=rw.embedding_engine),
                        AWS_OPENSEARCH_HOST=AWS_OPENSEARCH_HOST,
                        AWS_OPENSEARCH_USERNAME=AWS_OPENSEARCH_USERNAME,
                        AWS_OPENSEARCH_PASSWORD=AWS_OPENSEARCH_PASSWORD,
                        no_of_doc=rw.num_of_citations,
                    )
                    process_time = time.time() - start_time
                    logger.error(
                        f"Pre filter Retreiver Time: {process_time} seconds - "
                    )
                    answer, citation_basic, total_token = get_llm_response(
                        vector_db=vector_db_retreiver,
                        llm_engine=rw.llm_engine,
                        temperature=rw.temperature,
                        max_tokens=rw.max_tokens,
                        system_message=rw.system_message,
                        context=rw.context,
                        user_query=rw.user_query,
                        num_of_citations=rw.num_of_citations,
                        files_md5=file_to_include,
                        filter_citations=rw.filter_citations,
                    )

        except Exception as e:
            raise e

        return QueryEmbeddingsResponse(
            status=Status.success,
            llm_response=answer,
            citation=citation_basic,
            requestid=request_id,
            totaltokensllm=total_token[0],
            totaltokensembedding=total_token[1],
        )

    except Exception as e:
        raise e


@router.get("/status", status_code=200, tags=["API Module Service"])
@async_token_validation_and_metering()
async def get_status(
    request: fastapi_request, request_id: str, db: Session = Depends(get_db)
):
    try:
        logger.info("Fetching headers for /status endpoint")
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )

        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        logger.info("Fetching database details for status endpoint")
        client_id_list = client_id_info(client_id=client_id, db=db)

        ingestion_status = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.request_id == request_id,
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
            )
            .first()
        )

        if ingestion_status:
            request_id_data = ingestion_status.request_id
            request_client_id_data = ingestion_status.client_id
            request_index_data = ingestion_status.index
            request_document_name_data = ingestion_status.document
            request_document_md5_data = ingestion_status.document_md5
            request_metadata_data = ingestion_status.attached_metadata
            request_last_index_timestamp_data = ingestion_status.completed_errored_ts
            request_status_data = ingestion_status.status
            request_error_message_data = ingestion_status.error_message
            request_current_status_timestamp_data = ingestion_status.queued_ts
            request_inprogress_ts_status_timestamp_data = ingestion_status.inprogress_ts
            request_completed_errored_ts = ingestion_status.completed_errored_ts

            status_info = {
                "request_id": request_id_data,
                "client_id": request_client_id_data,
                "index": request_index_data,
                "document_name": request_document_name_data,
                "document_md5": request_document_md5_data,
                "metadata_attached": request_metadata_data,
                "status": request_status_data,
            }
            if ingestion_status.status == "Error":
                return {
                    **status_info,
                    "error_message": request_error_message_data,
                    "completed_errored_ts": request_completed_errored_ts,
                }
            elif ingestion_status.status == "InProgress":
                return {
                    **status_info,
                    "current_status_timestamp": request_inprogress_ts_status_timestamp_data,
                }
            elif ingestion_status.status == "Queued":
                return {
                    **status_info,
                    "current_status_timestamp": request_current_status_timestamp_data,
                }
            else:
                return {
                    **status_info,
                    "last_index_timestamp": request_last_index_timestamp_data,
                }
        else:
            logger.error(
                f"request_id - {request_id} or client_id - {client_id} is not found in RDS table"
            )
            return {"message": "request_id or client_id is not found in RDS table "}
    except Exception as e:
        raise e


@router.get("/read_metadata", status_code=200, tags=["API Module Service"])
@async_token_validation_and_metering()
async def read_metadata(
    request: fastapi_request,
    request_id: str,
    document: str,
    db: Session = Depends(get_db),
):
    logger.info("Fetching headers for /read_metadata endpoint")

    try:
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )
        client_id_list = client_id_info(client_id=client_id, db=db)

        logger.info("Started processing the request")
        ingestion_info= (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.request_id == request_id,
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
                DataIngestionStatusTableNew.document == document,
            )
            .first()
        )

        if ingestion_info:
            return {
                "request_id": ingestion_info.request_id,
                "client_id": ingestion_info.client_id,
                "document_name": ingestion_info.document,
                "metadata_attached": ingestion_info.attached_metadata,
            }
        else:
            return {
                "message": "request_id or client_id or document is not found in RDS table.."
            }
    except Exception as e:
        raise e


@router.post(
    "/ingest",
    status_code=200,
    tags=["data ingestion"],
    description="This is to ingest the document",
    response_model=DocumentIngestResponse,
)
@async_token_validation_and_metering()
async def data_ingestion(
    request: fastapi_request, rw: DocumentIngestRequest, db: Session = Depends(get_db)
):
    logger.info("Fetching headers for /ingest endpoint")
    try:
        file_name = ""
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        src_document_path = rw.src_document_path

        logger.info(f"Fetching client info for {client_id}")

        client_info = (
            db.query(ClientMapping)
            .filter(ClientMapping.client_id == f"{client_id}")
            .first()
        )

        requestID = request_generation()

        if client_info is None:
            vector = f'{{"vectorDBAccessURL":"{GEN_VEC_DB}","vectorDBType":"OpenSearch","UserNameVar": "uc-os-username", "PasswordVar": "usecaseospassword","Secretdetails": "{ENV}-vsl-docinsight-secrets"}}'
            queue = f"{ENV}-vsl-docinsight-generic_queue.fifo"
            new_item = ClientMapping(
                client_id=f"{client_id}",
                usecase="non_vox",
                queue=queue,
                vectorDBdetails=vector,
                index="",
            )
            db.add(new_item)
            db.commit()
            db.refresh(new_item)

        if client_info.usecase.lower() == "vox":
            logger.info("Index not generated since its a VOX usecase")
            indices = rw.index
            index = indices[0]
        elif client_info.usecase.lower() != "vox" and client_info.index == "":
            logger.info("Generating index and storing for Non-VOX usecase")
            index = index_generation()
            client_info.index = index
            indices = [index]
            db.commit()
        else:
            index = client_info.index
            indices = [index]

        document_chunk_size = rw.document_chunk_size

        if document_chunk_size <= 8197 and type(document_chunk_size) == int:
            logger.info("Document_chunk_size is validated")
        else:
            return DocumentIngestResponse(
                status=Status.failure,
                requestID=requestID,
                Failed_request_reason=Failed_validation["document_chunk_size"],
            )

        document_overlap_size = rw.document_overlap_size

        if (
            document_overlap_size <= document_chunk_size
            and type(document_overlap_size) == int
        ):
            logger.info("document_overlap_size is validated")
        else:
            return DocumentIngestResponse(
                status=Status.failure,
                requestID=requestID,
                Failed_request_reason=Failed_validation["document_overlap_size"],
            )

        engine = rw.engine
        custom_metadata = rw.metadata
        request_status = "Queued"

        try:
            file_name, file_temp = fetch_file_from_s3_using_purl(
                presigned_url=src_document_path
            )
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail="Unable to read the file from the provided path. Please validate the pre-signed URL",
            )

        file_type = pathlib.Path(file_temp).suffix

        if file_type.lower() not in [".pdf", ".docx", ".pptx", ".xlsx", ".csv"]:
            raise HTTPException(status_code=400, detail=Failed_validation["file_type"])

        document_md5 = calculate_md5_hash(file_name)
        logger.info(f"Md5 of the given file {file_name}: {document_md5}")

        if "filename" in custom_metadata:
            custom_metadata["filename"] = file_temp
        if "md5" in custom_metadata:
            custom_metadata["md5"] = document_md5
        else:
            custom_metadata["filename"] = file_temp
            custom_metadata["md5"] = document_md5

        files = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.document_md5.in_([document_md5]),
                DataIngestionStatusTableNew.index == index,
                DataIngestionStatusTableNew.is_file_deleted == False,
                DataIngestionStatusTableNew.status != "Error",
            )
            .all()
        )

        if not len(files):
            queued_timestamp = datetime.utcnow()

            logger.info("Generating request_id in Generic queue")
            processed_responsed = {
                "src_document_path": src_document_path,
                "index": indices,
                "client_id": client_id,
                "requestID": requestID,
                "document_chunk_size": document_chunk_size,
                "document_overlap_size": document_overlap_size,
                "metadata": custom_metadata,
                "engine": engine,
            }
            processed_response = json.dumps(processed_responsed)

            queue_name_row = (
                db.query(ClientMapping).filter_by(client_id=client_id).first()
            )
            queue_name = queue_name_row.queue
            insert_msg_in_sqs_queue(queue_name=queue_name, msg_json=processed_response)

            logger.info("Inserting info into DataIngestionStatusTableNew table")
            data_to_insert = DataIngestionStatusTableNew(
                request_id=requestID,
                client_id=client_id,
                index=index,
                document=file_temp,
                document_md5=document_md5,
                attached_metadata=str(custom_metadata),
                status=request_status,
                error_message="",
                queued_ts=queued_timestamp,
            )
            db.add(data_to_insert)
            db.commit()
            logger.info("Posting the response from  queue and for brand new document")
            if file_name and os.path.exists(file_name):
                os.remove(file_name)

            return DocumentIngestResponse(
                status=Status.success,
                requestID=requestID,
                client_id=client_id,
                request_status=request_status,
                metadata=custom_metadata,
                queued_timestamp=queued_timestamp,
            )
        else:
            logger.info(
                "Posting the response from generic queue for already existing document"
            )
            if file_name and os.path.exists(file_name):
                os.remove(file_name)

            return DocumentIngestResponse(
                status=Status.failure,
                requestID=requestID,
                Failed_request_reason=Failed_validation["duplication"],
            )

    except Exception as exc:
        if file_name and os.path.exists(file_name):
            os.remove(file_name)
        raise exc


@router.post(
    "/process_endpoint",
    status_code=200,
    tags=["text embeddings"],
    description="Creates chunks of the uploaded data and provides embeddings",
    response_model=DocumentEmbeddingsResponse,
)
async def process_file(rw: DocumentEmbeddingsRequest, db: Session = Depends(get_db)):
    try:
        s3_path_uri = rw.src_document_path
        separators = rw.chunking_strategy
        chunk = rw.document_chunk_size
        overlap = rw.document_overlap_size
        req_id = rw.requestID
        client_id = rw.client_id
        index = rw.index
        filename = ""
        cust_md = {} if rw.metadata is None else rw.metadata

        logger.info(
            f"Ingesting the document for the client_id: {client_id} and req_id: {req_id}"
        )

        """ Update status 'InProgress' in database """
        index_detail = (
            db.query(DataIngestionStatusTableNew)
            .filter_by(request_id=req_id, client_id=client_id)
            .first()
        )

        if index_detail is None:
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Request ID not found in the database"
            )
            raise HTTPException(
                status_code=400, detail="Request ID not found in the database"
            )

        index_detail.status = "InProgress"
        index_detail.inprogress_ts = datetime.utcnow()
        db.commit()

        if overlap > chunk:
            index_detail.status = "Error"
            index_detail.error_message = "Overlap size should be less than chunk size"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Overlap size should be less than chunk size"
            )
            raise HTTPException(
                status_code=428, detail="Overlap size should be less than chunk size"
            )

        """ Fetch file from S3 """
        try:
            filename, _ = fetch_file_from_s3_using_purl(s3_path_uri)
        except Exception as e:
            filename = "docinsight-error-1.pdf"
            index_detail.status = "Error"
            index_detail.error_message = f"Error in fetching document from S3: {str(e)}"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Error while fetching document from S3: {str(e)}"
            )
            raise HTTPException(
                status_code=400, detail="Error while fetching the document from S3"
            )

        """ Determine file type (pdf/docx) """
        file_type = pathlib.Path(filename).suffix
        file_supported_type = [".docx", ".pptx", ".pdf", ".xlsx", ".csv"]
        try:
            if file_type.lower() in file_supported_type:
                processor = FileProcessor(
                    filename=filename,
                    separators=separators,
                    chunk_size=chunk,
                    chunk_overlap=overlap,
                    cust_metadata=cust_md,
                )

                page_content, metadata, large_file = await processor.process_files()
                logger.info(
                    f"For client_id: {client_id} and req_id: {req_id} - chunked the given file: {filename}"
                )

            else:
                error_message = f"Requested file format not supported: {file_type}"
                logger.error(error_message)
                page_content = ["No page_content"]
                metadata = ["No metadata"]
                index_detail.status = "Error"
                index_detail.error_message = error_message
                index_detail.completed_errored_ts = datetime.utcnow()
                db.commit()
                logger.error(
                    f"For client_id: {client_id} and req_id: {req_id} - Requested file format not supported: {file_type}"
                )
                raise HTTPException(status_code=400, detail=error_message)
        except ChunkingException as e:
            index_detail.status = "Error"
            index_detail.error_message = f"Error while chunking the file: {str(e)}"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Error while chunking the file: {str(e)}"
            )
            raise e
        except FileLoaderException as e:
            index_detail.status = "Error"
            index_detail.error_message = f"Error while loading the file: {str(e)}"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Error while loading the file: {str(e)}"
            )
            raise e

        except Exception as e:
            index_detail.status = "Error"
            index_detail.error_message = f"Error while loading the file: {str(e)}"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Error while processing the file: {str(e)}"
            )
            raise HTTPException(
                status_code=500, detail="Error in processing the uploaded file"
            )

        (
            AWS_OPENSEARCH_HOST,
            AWS_OPENSEARCH_USERNAME,
            AWS_OPENSEARCH_PASSWORD,
        ) = get_vector_db_details(rw.client_id, db)

        try:
            for idx in index:
                logger.info(
                    f"For client_id: {client_id} and req_id: {req_id} - Creating embeddings and ingesting into opensearch"
                )
                vector_db = OpenSearchVectorSearch(
                    index_name=idx,
                    embedding_function=IASOpenaiEmbeddings(engine=rw.engine),
                    opensearch_url=AWS_OPENSEARCH_HOST,
                    http_auth=(AWS_OPENSEARCH_USERNAME, AWS_OPENSEARCH_PASSWORD),
                    is_aoss=False,
                )

                if large_file:
                    for i in range(0, len(page_content)):
                        vectors = vector_db.add_texts(
                            texts=page_content[i], metadatas=metadata[i]
                        )
                else:
                    vectors = vector_db.add_texts(
                        texts=page_content, metadatas=metadata
                    )

                index_detail.status = "Completed"
                index_detail.error_message = ""
                index_detail.completed_errored_ts = datetime.utcnow()
                db.commit()
                logger.info(
                    f"For client_id: {client_id} and req_id: {req_id} - Ingested the embeddings into opensearch"
                )

        except Exception as e:
            index_detail.status = "Error"
            index_detail.error_message = (
                f"Langchain document embeddings error: {str(e)}"
            )
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()

            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Langchain document embeddings error: {str(e)}"
            )
            raise HTTPException(
                status_code=500, detail="Langchain document embeddings error"
            )

        if filename and os.path.exists(filename):
            os.remove(filename)

        return DocumentEmbeddingsResponse(
            status=Status.success, index=index, request_id=req_id
        )
    except Exception as e:
        if filename and os.path.exists(filename):
            os.remove(filename)

        logger.error(
            f"For client_id: {client_id} and req_id: {req_id} - Failed to process the request: {str(e)}"
        )
        raise e


@router.post(
    "/delete-files",
    status_code=200,
    tags=["Delete Document"],
    description="This endpoint deletes the document from VectorDB and docinsight RDS",
    response_model=DeleteResponse,
)
@async_token_validation_and_metering()
async def delete_file(
    request: fastapi_request, rw: DeleteRequest, db: Session = Depends(get_db)
):
    try:
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )

        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        # UPDATE
        (
            AWS_OPENSEARCH_HOST,
            AWS_OPENSEARCH_USERNAME,
            AWS_OPENSEARCH_PASSWORD,
        ) = get_vector_db_details(client_id, db)

        logger.info("Creating OS client")
        try:
            opensearch_client = OpenSearch(
                hosts=[AWS_OPENSEARCH_HOST],
                http_auth=(AWS_OPENSEARCH_USERNAME, AWS_OPENSEARCH_PASSWORD),
            )
        except ImproperlyConfigured as e:
            logger.error("The config passed to the client is inconsistent or invalid")
            raise e

        except OpenSearchException as e:
            logger.error("Couldn't create opensearch client")
            raise e

        client_id_list = client_id_info(client_id=client_id, db=db)

        ingestion_info = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
                DataIngestionStatusTableNew.request_id.in_(rw.request_ids),
            )
            .all()
        )

        if len(ingestion_info):
            db.query(DataIngestionStatusTableNew).filter(
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
                DataIngestionStatusTableNew.request_id.in_(rw.request_ids),
            ).update({"is_file_deleted": True})
            db.commit()
            md5_info = [
                {
                    "request_id": row.request_id,
                    "index": row.index,
                    "md5": row.document_md5,
                    "status": row.status,
                }
                for row in ingestion_info
            ]
            documents_info = [
                {
                    "request_id": request_id,
                    "status": True,
                    "message": "Found in Database",
                }
                if request_id in {item["request_id"] for item in md5_info}
                else {
                    "request_id": request_id,
                    "status": False,
                    "message": "Not Found in Database",
                }
                for request_id in rw.request_ids
            ]
            deleted_documents = [
                delete_documents(os_client=opensearch_client, document_info=item)
                for item in md5_info
            ]
            merged_dict = {}

            for document in documents_info:
                request_id = document["request_id"]
                message = document["message"]
                status_bool = document["status"]
                delete_doc_req_item = list(
                    filter(lambda x: x["request_id"] == request_id, deleted_documents)
                )

                del_doc_msg = ""
                if len(delete_doc_req_item):
                    del_doc_msg = f",{delete_doc_req_item[0]['message']}"

                merged_dict[request_id] = {
                    "request_id": request_id,
                    "message": f"{message}  {del_doc_msg}",
                    "status": status_bool,
                }

            # Convert the merged dictionary to a list of dictionaries
            merged_list = list(merged_dict.values())
            for obj in ingestion_info:
                obj.vec_db_deletion_status = "Deleted"
                db.add(obj)
                db.commit()

        else:
            msg = f"Provided Request ids: {rw.request_ids} not present in DB"
            logger.error(msg)
            raise HTTPException(
                status_code=400, detail="Please check the request payload"
            )

        return DeleteResponse(delete_status=merged_list)

    except Exception as e:
        raise e


@router.get(
    "/ingestion-info",
    status_code=200,
    tags=["API Module Service"],
    description="This endpoint provides the list of documents used by the given client",
    response_model=Dict[str, Union[List[IngestionInfoResponse], int, str]],
)
@async_token_validation_and_metering()
async def get_ingestion_info(
    request: fastapi_request,
    db: Session = Depends(get_db),
    page_limit: Optional[int] = 25,
    page_number: Optional[int] = 1,
    sort_order: Order_By = Order_By.ASC,
):
    try:
        logger.info("Fetching client header")
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        if page_number >= 1:
            if page_number > 1 and page_limit is None:
                logger.error("Page limit is also required with page number")
                raise HTTPException(
                    status_code=400,
                    detail="Page limit is also required with page number",
                )
            elif page_limit is not None and page_limit <= 0:
                logger.error("Page limit cannot be less than 1")
                raise HTTPException(
                    status_code=400, detail="Page limit cannot be less than 1"
                )
        elif page_number < 1:
            logger.error("Page number cannot be less than 1")
            raise HTTPException(
                status_code=400, detail="Page number cannot be less than 1"
            )

        # Apply ordering and sorting
        order_column = DataIngestionStatusTableNew.modified_ts
        if sort_order == Order_By.DESC:
            order_column = desc(order_column)
        
        client_id_list = client_id_info(client_id=client_id, db=db)
        query = (
            db.query(DataIngestionStatusTableNew)
            .filter(DataIngestionStatusTableNew.client_id.in_(client_id_list))
            .order_by(order_column)
        )
        total_count = query.count()

        # Calculate total number of pages based on page_limit and total_count
        page_size = -(
            -total_count // page_limit
        )  # Ceiling division to get a positive integer

        # Apply pagination
        if page_limit is not None:
            start_index = (page_number - 1) * page_limit
            end_index = start_index + page_limit
            query = query.offset(start_index).limit(page_limit)

        ingestion_info = query.all()
        ingestion_data = []

        if len(ingestion_info):
            logger.info(f"Fetching details containing {total_count} entries")
            for row in ingestion_info:
                ingestion_data.append(
                    IngestionInfoResponse(
                        request_id=row.request_id,
                        index=row.index,
                        document_name=row.document,
                        document_md5=row.document_md5,
                        attached_metadata=row.attached_metadata,
                        status=row.status,
                        error_msg=row.error_message,
                        is_file_deleted=row.is_file_deleted,
                    )
                )
        else:
            logger.error("No records found in DB")

        # Check if requested page_number exceeds page_size
        if page_number > page_size:
            logger.error("Requested page_number exceeds available page_size.")
            raise HTTPException(
                status_code=400,
                detail="Requested page_number exceeds available page_size.",
            )

        # Return a dictionary containing both ingestion data and pagination information
        return {
            "ingestion_data": ingestion_data,
            "total_count": total_count,
            "page_number": page_number,
            "page_limit": page_limit,
            "page_size": page_size,
        }
    except Exception as e:
        raise e
