from sqlalchemy import Column, Boolean, String, DateTime, Integer, Float
from app.langchain.database import Base
from datetime import datetime
from sqlalchemy_utils import ScalarListType

class ClientMapping(Base):
    __tablename__ = "clientidmappingtableias"
    client_id = Column(String, primary_key=True)
    usecase = Column(String)
    queue = Column(String)
    vectorDBdetails = Column(String)
    index = Column(String)
    alternate_client_ids = Column(ScalarListType,nullable=True)


class DataIngestionStatusTableNew(Base):
    __tablename__ = "data_ingestion_status_table"

    client_id = Column(String, nullable=False)
    request_id = Column(String, primary_key=True)
    index = Column(String, nullable=False)
    document = Column(String, nullable=True)
    document_md5 = Column(String, nullable=True)
    attached_metadata = Column(String, nullable=True)
    status = Column(String, nullable=False)
    error_message = Column(String, nullable=True)
    queued_ts = Column(DateTime(timezone=True))
    inprogress_ts = Column(DateTime(timezone=True))
    completed_errored_ts = Column(DateTime(timezone=True))
    vec_db_deletion_status = Column(String, nullable=True)
    is_file_deleted = Column(Boolean, default=False)
    created_ts = Column(DateTime(timezone=True), default=datetime.utcnow)
    modified_ts = Column(
        DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow
    )


class DocumentSummary(Base):
    __tablename__ = "document_summary"
    client_id = Column(String, nullable=False)
    request_id = Column(String, primary_key=True)
    index = Column(String, nullable=False)
    document_md5 = Column(String, nullable=False)
    engine = Column(String, nullable=False)
    temperature = Column(Float, nullable=False)
    summary = Column(String, nullable=True)
    total_tokens_llm = Column(Integer, nullable=True)
    status = Column(String, nullable=False)
    error_message = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(
        DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow
    )
