import sys
from loguru import logger
from fastapi import Request

logger.remove()
logger.add(
    sys.stderr,
    format="{time:MMMM D, YYYY > HH:mm:ss!UTC} | {level} | {name}:{function}:{line} | {message} ",
    colorize=True,
)


async def configure_logger(request: Request):
    if request:
        request_body = {}

        if len(await request.body()):
            request_body = await request.json()

        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else ""
        )

        if not client_id:
            client_id = request_body.get("client_id", "")

        request_id = ""
        if request_body.get("request_id", None):
            request_id = request_body.get("request_id")

        if request_body.get("requestid", None):
            request_id = request_body.get("request_id")

        if request_body.get("requestID", None):
            request_id = request_body.get("requestID")

        md5 = ""
        filename = ""
        if request_body.get("metadata", None):
            metadata = request_body.get("metadata")
            md5 = metadata.get("md5", "")
            filename = metadata.get("filename", "")

        index = request_body.get("index", "")

        if not index:
            index_map = request_body.get("index_document_map", "")
            if index_map:
                index = list(index_map.keys())
                if not md5:
                        for item in index_map.values():
                            md5 += "".join([f" {str(md5)}" for md5 in item])

        logger.configure(
            extra={
                "client_id": client_id,
                "request_id": request_id,
                "index": index,
                "md5": md5,
                "filename": filename,
            }
        )

        logger.remove()
        logger.add(
            sys.stderr,
            format="{time:MMMM D, YYYY > HH:mm:ss!UTC} | {level} | Client id: {extra[client_id]} | {name}:{function}:{line} | Request id: {extra[request_id]} | Index: {extra[index]} | MD5: {extra[md5]} Filename: {extra[filename]} | {message} ",
            colorize=True,
        )
    return True
