import httpx
import time
from app.utils.custom_loguru import logger
from app.utils.config_vars import REQUEST_TIMEOUT_SECONDS


class CustomHttpX(httpx.AsyncClient):
    def __init__(self, *args, **kwargs):
        # Set a connection timeout of 10 seconds and read timeout of 60 seconds
        timeout = httpx.Timeout(10.0, read=REQUEST_TIMEOUT_SECONDS)

        # Initialize the parent class with the custom timeout
        super().__init__(*args, timeout=timeout, **kwargs)

    async def request(self, *args, **kwargs):
        try:
            start_time = time.time()  # Record the time before making the request

            # Log the HTTP method and URL of the request
            if len(args) > 1:
                logger.info(f"Performing external {args[0]} request to: {args[1]}")

            # Make the request and get the response
            response = await super().request(*args, **kwargs)

            end_time = time.time()  # Record the time after receiving the response

            duration = end_time - start_time  # Calculate the duration of the request
            logger.info(f"External request took {duration} seconds - {args[1]}")

            # If the response indicates an unsuccessful status, raise an error
            response.raise_for_status()  # Raises HTTPStatusError for non-2xx status codes

        except Exception as e:
            end_time = time.time()
            duration = end_time - start_time  # Calculate the duration of the request
            logger.info(
                f"External request failed and took {duration} seconds - {args[1]}"
            )
            # re-raise to handle at a higher level
            raise e

        else:
            # If no error was raised, return the response
            return response
