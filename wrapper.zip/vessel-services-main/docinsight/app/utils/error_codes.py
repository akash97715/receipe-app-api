import random

status_codes_msg = {
    400: "Oops, our server didn't quite understand your request. Could you double-check your info and try again?",
    401: "Hmm, it appears you're not on the guest list. Make sure you have the right credentials to access this.",
    402: "Just like at a fancy restaurant, payment is required to proceed. Kindly settle the bill and give it another go.",
    403: "It seems you're in the wrong club. Make sure you've got the right membership to use this feature.",
    404: "Looks like a game of hide and seek, but the resource you're looking for is hiding too well. Check your URL and try again.",
    405: "Our server's being a little picky right now. It doesn't like the method you used. Could you try a different one?",
    406: "Oh no, our server doesn't speak the format you requested. Let's try a different language.",
    407: "You need a special pass to go through our proxy. Please flash your credentials.",
    408: "Our server's been waiting for a response, but it seems to have missed its call. Check your connection and try again.",
    409: "There seems to be a small argument happening over resource state. Resolve the conflict and try again.",
    410: "The resource you're looking for moved out. It left no forwarding address.",
    411: "'Content-Length' header is missing. It's like sending a letter without postage. Please provide it.",
    412: "Our server couldn't meet your high standards. Double-check the requirements and let's give it another shot.",
    413: "Whoa, your request is way too large. Could you make it a bit lighter?",
    414: "Your URL is longer than a winter night. Can we shorten it a bit?",
    415: "Our server can't play the media type you sent. Could we try a different tune?",
    416: "The range you requested is a bit out of reach. Let's bring it a little closer.",
    417: "Our server just couldn't live up to your 'Expect' header. Maybe we should lower our expectations a bit.",
    418: "I'm a teapot. Not much good for web requests, but great at brewing tea.",
    421: "Looks like there's been a mix-up with the server resource. Our bad.",
    422: "Our server didn't quite get what you meant. Could you check your request and try again?",
    423: "The resource you want is currently locked away. Could you come back later?",
    424: "Your request has a sidekick that couldn't show up. Fix the dependency and give it another go.",
    425: "Our server is currently unwilling to fulfill the request. Try again after a short break.",
    426: "You'll need to switch lanes to a different protocol for this request.",
    428: "Our server has set some ground rules for this request. Please meet the preconditions.",
    429: "Slow down, speedy! You're exceeding the word limit per minute. Take a breather and try again.",
    431: "Your header size is bigger than our server's capacity. Can we shrink it down a bit?",
    451: "Legal constraints are keeping this resource off-limits. It's not you, it's the law.",
    500: "Our server is experiencing some turbulence. Please fasten your seat belt and try again later.",
    501: "Our server is a bit old-school. It doesn't know the feature you're asking for. Could you try another?",
    502: "Yikes! There's trouble upstream. Hold tight, we'll sort it out.",
    503: "Our server is on a short coffee break. Please wait a bit and try again later.",
    504: "Timeout! Our server's been left hanging by an upstream server.",
    505: "Our server can't handle the HTTP version you're speaking. Could we try a different dialect?",
    506: "A little mix-up in our server's internals. We're on it!",
    507: "Our server's storage is packed to the rafters. Could you free up some space?",
    508: "Our server's stuck in an infinite loop. Like a dog chasing its tail.",
    510: "Our server needs some extra gear to fulfill the request. Let's get in touch with the server admin.",
    511: "You need a pass to get network access. Show us your credentials, please.",
}

custom_msgs = {
    "AUTH_HEADER_MISSING": "Please provide an Authorization header.",
    "MALFORMED_AUTH_HEADER": "The Authorization header is not properly formatted.",
    "TOKEN_EXCEEDED_MODEL_LIMIT": "The message you submitted was too long, please reload the conversation and submit something shorter.",
    "MODEL_DEPLOYMENT_ID_UNAVAILABLE": "The AI Model is not available right now. Please wait a moment and try again.",
    "OLD_TOKEN": "We couldn't verify your access. It's possible your session has ended. Please refresh the page or open the app in a new tab to continue.",
}

msg_suffix = "If the problem persists, please email a description and a screenshot (if possible) to <DL-IAS-Platform-Operations@pfizer.com>."

prefixes = [
    "Apologies",
    "Sorry",
    "Uh-oh",
    "Error",
    "Oopsie",
    "Yikes",
    "Whoops",
    "My bad",
    "Oh no",
    "Excuse me",
]

suffixes = [
    "We're here to help you!",
    "Ready to serve you at any time!",
    "Happy to assist you further!",
    "Eager to make your experience better!",
    "We're with you every step of the way!",
    "We're always ready to support you!",
    "Here to make things easier for you!",
    "Your satisfaction is our priority!",
    "Always here to lend a helping hand!",
    "Ready to provide any assistance you need!",
    "We're all ears for your feedback!",
    "Excited to continue serving you!",
    "We're just a click away for your needs!",
    "We're on standby for your convenience!",
    "Happy to be a part of your journey!",
    "We're committed to providing you the best service!",
    "We're here for you 24/7!",
    "Eager to hear from you again!",
    "Always ready to jump in for your help!",
]


openai_unreachable_messages = [
    "Oh dear, it seems our AI is taking a quick nap. We'll wake it up as soon as possible. Please try again in a few moments!",
    "At the moment, we're teaching our AI some new tricks. Service will be back once school is out. Please check back in a bit!",
    "Whoops! Our servers are having a little hiccup. We've got our best people working on it. Rest assured, normal service will resume soon!",
    "Looks like our AI has gone on a coffee break. Once it's back, fully caffeinated, we'll be right back online!",
    "Oops, our AI seems to be daydreaming. As soon as it snaps back to reality, we'll be back up. Poke us again in a few moments!",
    "Even AIs need a break. We're taking a brief pause in service, but we promise, our AI is preparing for its spectacular comeback!",
    "Currently, our AI is out exploring the digital universe. As soon as it returns, service will resume. Check back in a little while!",
    "Aw snap! Our servers are doing the robot dance. Once they've finished their routine, we'll be back to normal. Hang tight!",
    "Our AI has gone fishing in the data stream. As soon as it reels in a big one, we'll be back online. Please try again later.",
    "Oops! Our AI is lost in thought. As soon as it finds its way back, we'll be up and running again. Please bear with us!",
]

error_messages_500 = [
    "Oops! Something went off course. Our service is plotting a new route. Please try again later.",
    "Heads up! Something jumbled our codes. Our AI is unscrambling it. Please retry now or later.",
    "Yikes! A wild error appeared. Our server is in a battle. Please try again in a bit.",
    "Oh no! Something shook our matrix. Our service is realigning it. Please retry later.",
    "Uh-oh! A byte went rogue. Our server is chasing it down. Please retry now or later.",
    "Hang on! Something threw our gears off. Our AI is oiling them up. Please retry in a bit.",
    "Whoops! A bug flew into our system. Our service is gently shooing it away. Please try again later.",
    "Zoinks! Something rattled our server. It's shaking it off. Please retry now or later.",
    "Oopsie! We hit a logic pothole. Our AI is patching it up. Please retry later.",
    "Well, that's odd. Something skewed our data. Our server is straightening it out. Please retry now or later.",
    "Bummer! Our AI got a puzzle it can't solve. It's learning more to fix it. Please retry in a bit.",
    "Whoa! We hit a digital speed bump. Our service is smoothing it out. Please try again later.",
    "Aha! Something's made our server ponder. It's deep in thought. Please retry now or later.",
    "Hold on! Something's not clicking. Our service is searching for the right button. Please retry later.",
    "Eek! A glitch in the matrix. Our server is patching the code. Please retry now or later.",
]

error_messages_429 = [
    "Whoa, you're on fire! Let's cool down a bit, shall we? Try again later.",
    "Easy tiger, you're sending requests too fast! Take a pause and try again later.",
    "Hang on, speed racer! You've hit the limit. Please coast for a bit and try again later.",
    "Wow, you're quick! But our server needs a second. Catch your breath and try again later.",
    "Hey speedy, you've outpaced our server! Take a pit stop and try again later.",
    "Hold your horses! You're exceeding the limit. Take a break and try again later.",
    "Slow down, turbo! You've reached your limit. Please recharge and try again later.",
    "Slow your roll! You're moving too fast. Please idle for a while and try again later.",
    "Hey Flash, you're too quick for us! Take a coffee break and try again later.",
    "Whoa there, lightning! Let's take it easy and try again in a bit.",
    "Too many clicks, too soon! Please give your mouse a break and try again later.",
    "Hey roadrunner, slow down! Take a breather and retry later.",
    "Hold up, sprinter! Our server's tying its shoelaces. Take a pause and retry later.",
    "Hey, Usain Bolt! Let's take a water break, shall we? Try again later.",
    "You're clicking faster than light! Let's give physics a break, and try again later.",
    "Eager beaver! Let's give the server a moment to catch up. Try again later.",
]


def get_human_status_code_msg(status_code, message=None, upstream_msg=None):
    conditions_to_avoid = [None, "", " ", "Forbidden"]
    if message not in conditions_to_avoid:
        return status_code, f"{random.choice(prefixes)}! {str(message)}"

    # special cases to alter the msg to the user
    if upstream_msg:
        # 1) 400 error thrown by the fedarate server shd default to 401 error
        federate_msgs = [
            "{'error_description': 'unknown, invalid, or expired refresh token', 'error': 'invalid_grant'}",
            "{'error_description': 'token not found, expired or invalid', 'error': 'invalid_grant'}",
        ]
        if upstream_msg in federate_msgs:
            return (
                401,
                # f"{random.choice(prefixes)}! {custom_msgs['OLD_TOKEN']} {msg_suffix} {random.choice(suffixes)}",
                f"{random.choice(prefixes)}! {custom_msgs['OLD_TOKEN']}",
            )

        # 2) when models token lenght is exceeded - vsl sent 400 error with custom msg.
        if upstream_msg.startswith(
            '{\'detail\': \'Error: {\\n  "error": {\\n    "message": "This model\\\'s maximum context'
        ):
            return (
                400,
                # f"{random.choice(prefixes)}! {custom_msgs['TOKEN_EXCEEDED_MODEL_LIMIT']} {msg_suffix} {random.choice(suffixes)}",
                f"{random.choice(prefixes)}! {custom_msgs['TOKEN_EXCEEDED_MODEL_LIMIT']}",
            )

        # 3) when deployment id is wrong or not available or used an old id
        if upstream_msg == (
            "{'detail': 'Error: The API deployment for this resource does not exist. If you created the deployment within the last 5 minutes, please wait a moment and try again.'}"
        ):
            return (
                400,
                # f"{random.choice(prefixes)}! {custom_msgs['MODEL_DEPLOYMENT_ID_UNAVAILABLE']} {msg_suffix} {random.choice(suffixes)}",
                f"{random.choice(prefixes)}! {custom_msgs['MODEL_DEPLOYMENT_ID_UNAVAILABLE']}",
            )

    # when vsl openai service is give 429 errors - just adding couple of msgs to not send generic always.
    if status_code == 429:
        return (
            status_code,
            f"{random.choice(error_messages_429)}",
        )

    # 500 errors - just adding couple of msgs to not send generic always.
    if status_code == 500:
        return (
            status_code,
            f"{random.choice(error_messages_500)}",
        )

    # when vsl openai service is unavailable it(AWS ALB) raises 503
    if status_code == 503:
        return (
            status_code,
            f"{random.choice(openai_unreachable_messages)}",
        )

    if status_code in status_codes_msg:
        return (
            status_code,
            # f"{random.choice(prefixes)}! {status_codes_msg[status_code]} {msg_suffix} {random.choice(suffixes)}",
            f"{random.choice(prefixes)}! {status_codes_msg[status_code]}",
        )
    else:
        return status_code, f"Unknown Error! {msg_suffix} {random.choice(suffixes)}"
