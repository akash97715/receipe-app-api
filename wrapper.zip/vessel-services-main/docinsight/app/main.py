from fastapi import FastAPI
from app.langchain.v1.api import router as langchain_v1
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware

from fastapi import FastAPI, Request

from starlette.status import HTTP_408_REQUEST_TIMEOUT


import asyncio
import time
from .utils.universal_exceptions import (
    httpx_exception_handler,
    generic_exception_handler,
    http_exception_handler,
    validation_exception_handler,
)

load_dotenv()
from .utils.custom_loguru import logger

REQUEST_TIMEOUT_SECONDS = 90
PREFIX_V1 = "/docinsight"
TAGS_METADATA = [
    {
        "name": "DocInsight Services",
        "description": """DocInsight Services""",
    },
]


app = FastAPI(
    title="DocInsight Services",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
)

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


async def timeout_middleware(request: Request, call_next):
    logger.info(f"{request.method}: {request.url.path}")
    url_path = request.url.path

    try:
        start_time = time.time()
        response = await asyncio.wait_for(
            call_next(request), timeout=REQUEST_TIMEOUT_SECONDS
        )
    except asyncio.TimeoutError as exc:
        process_time = time.time() - start_time
        logger.info(f"Human Request Timeout: {process_time} seconds - {url_path}")
        exc.status_code = 408
        return http_exception_handler(exc)
    except RuntimeError as exc:
        if await request.is_disconnected() and str(exc) == "No response returned.":
            logger.warning(
                "Error `No response returned` detected. "
                "At the same time we know that the client is disconnected "
                "and not waiting for a response."
                f"Human Request Timeout: {process_time} seconds - {url_path}"
            )
        return http_exception_handler(exc)
    except Exception as exc:
        process_time = time.time() - start_time
        logger.info(
            f"Main Exception - Human Request Timeout: {process_time} seconds - {url_path}"
        )
        exc.status_code = 408
        return http_exception_handler(exc)
    else:
        process_time = time.time() - start_time
        logger.info(f"Human Request Complete: {process_time} seconds - {url_path}")
        return response


# async def catch_exceptions_middleware(request: Request, call_next):
#     try:
#         return await call_next(request)
#     except Exception as e:
#         logging.getLogger().error(str(e))
#         raise HTTPException(status_code=400, detail=f"Error: {str(e)}")

# app.middleware('http')(catch_exceptions_middleware)

app.include_router(langchain_v1, prefix=PREFIX_V1)
