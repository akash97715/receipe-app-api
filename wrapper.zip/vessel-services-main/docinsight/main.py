from fastapi import FastAPI, Request, HTTPException, Depends
from dotenv import load_dotenv
from fastapi.middleware.cors import CORSMiddleware
import os
import uvicorn
import asyncio
import time
from starlette.status import HTTP_408_REQUEST_TIMEOUT
import httpx
from fastapi.exceptions import RequestValidationError

load_dotenv()

from app.utils.universal_exceptions import (
    httpx_exception_handler,
    generic_exception_handler,
    http_exception_handler,
    validation_exception_handler,
)

from app.utils.custom_loguru import logger, configure_logger

from app.langchain.v1.api import router as langchain_v1
from app.langchain.v1.status.route import router as update_ingestion_status_api
from app.langchain.v1.summarize.route import router as summarize_api


REQUEST_TIMEOUT_SECONDS = 90
PREFIX_V1 = os.getenv("ROOT_API_PATH", "/docinsight")
TAGS_METADATA = [
    {
        "name": "DocInsight Services",
        "description": """DocInsight Services""",
    },
]

app = FastAPI(
    title="DocInsight Services",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
)

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# handle all validation errors here with its exc traceback
@app.exception_handler(RequestValidationError)
async def new_validation_exception_handler(request, exc):
    return validation_exception_handler(exc, request)


@app.exception_handler(httpx.HTTPStatusError)
async def new_httpx_exception_handler(request, exc):
    return httpx_exception_handler(exc, request)


@app.exception_handler(HTTPException)
async def new_http_exception_handler(request, exc):
    return http_exception_handler(exc, request)


@app.exception_handler(Exception)
async def new_generic_exception_handler(request, exc):
    return generic_exception_handler(exc, request)


@app.middleware("http")
async def timeout_middleware(request: Request, call_next):
    if "/health" not in request.url.path:
        logger.info(f"{request.method}: {request.url.path}")

    url_path = request.url.path
    try:
        start_time = time.time()
        response = await asyncio.wait_for(
            call_next(request), timeout=REQUEST_TIMEOUT_SECONDS
        )

    except asyncio.TimeoutError as exc:
        process_time = time.time() - start_time
        logger.error(f"Human Request Timeout: {process_time} seconds - {url_path}")
        exc.status_code = 408
        return http_exception_handler(exc, request)

    except RuntimeError as exc:
        if await request.is_disconnected() and str(exc) == "No response returned.":
            logger.warning(
                "Error `No response returned` detected. "
                "At the same time we know that the client is disconnected "
                "and not waiting for a response."
                f"Human Request Timeout: {process_time} seconds - {url_path}"
            )
        return http_exception_handler(exc, request)

    except Exception as exc:
        process_time = time.time() - start_time
        logger.error(
            f"Main Exception - Human Request Error: {process_time} seconds - {url_path}"
        )
        exc.status_code = 500
        return generic_exception_handler(exc, request)

    else:
        process_time = time.time() - start_time
        if "/health" not in request.url.path:
            logger.info(f"Human Request Complete: {process_time} seconds - {url_path}")

        return response


logger.info(f"Root path: {PREFIX_V1}")
app.include_router(
    langchain_v1, prefix=PREFIX_V1, dependencies=[Depends(configure_logger)]
)
app.include_router(
    update_ingestion_status_api,
    prefix=PREFIX_V1,
    dependencies=[Depends(configure_logger)],
)
app.include_router(
    summarize_api, prefix=PREFIX_V1, dependencies=[Depends(configure_logger)]
)
