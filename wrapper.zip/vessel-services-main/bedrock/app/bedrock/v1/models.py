from enum import Enum
from pydantic import BaseModel, Field
from typing import List, Optional


class Status(str, Enum):
    failure = "failure"
    success = "success"


class HealthCheckResponse(BaseModel):
    status: Status
    message: str


class Models(BaseModel):
    id: str
    model: str
    provider: str
    input_modalities: List[str]
    output_modalities: List[str]
    response_streaming_support: bool
    max_tokens: Optional[int] = 0
    description: Optional[str] = "No description available"
    use_cases: Optional[str] = "No use cases available"
    completion: Optional[bool] = False
    chat: Optional[bool] = False
    embeddings: Optional[bool] = False
    image: Optional[bool] = False


class CompletionRequest(BaseModel):
    prompt: str
    model: str
    max_tokens: int
    temperature: float = Field(0, ge=0, le=1)


class CompletionResponse(BaseModel):
    status: Status
    result: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


# TODO: check if prompt can support list of strings, same as openai
class EmbeddingsRequest(BaseModel):
    prompt: str
    model: str


class EmbeddingsResponse(BaseModel):
    status: Status
    embedding: list
    prompt_tokens: int
    total_tokens: int


class ImageRequest(BaseModel):
    prompt: str
    model: str
    cfg_scale: int = Field(0, ge=0, le=30)
    seed: int = Field(0, ge=10)
    generation_steps: int = Field(0, ge=0, le=150)
    style_preset: str


class ImageResponse(BaseModel):
    status: Status
    image: str
