import json

from anthropic import Anthropic

# Antropic official client which is used for counting tokens
anthropic_client = Anthropic()

# Based on Anthropic documentation this is how they handle context
ANTHROPIC_HUMAN = "\n\nHuman:"
ANTHROPIC_ASSISTANT = "\n\nAssistant:"


def merge_models_metadata(models, metadata):
    # Helper function. Gets 2 lists of deployed models and metadata and merges their data
    models_dict = {model["id"]: model for model in models}
    for data in metadata:
        if data["id"] in models_dict:
            models_dict[data["id"]].update(data)
    return list(models_dict.values())


async def define_completion_model_response(model_id, body, response):
    response_body = json.loads(response.get("body").read())
    if model_id.startswith("amazon"):
        text_completion = response_body.get("results")[0].get("outputText")
        prompt_tokens = response_body["inputTextTokenCount"]
        completion_tokens = response_body["results"][0]["tokenCount"]
    elif model_id.startswith("anthropic"):
        text_completion = response_body.get("completion")
        prompt_tokens = anthropic_client.count_tokens(json.loads(body).get("prompt"))
        completion_tokens = anthropic_client.count_tokens(
            response_body.get("completion")
        )
    elif model_id.startswith("ai21"):
        text_completion = response_body.get("completions")[0].get("data").get("text")
        prompt_tokens = len(
            response_body["prompt"]["tokens"]
        )  # TODO: find out how tokens are counted for ai21
        completion_tokens = len(
            response_body["completions"][0]["data"]["tokens"]
        )  # TODO: find out how tokens are counted for ai21
    elif model_id.startswith("cohere"):
        text_completion = response_body.get("generations")[0].get("text")
        prompt_tokens = (
            0  # TODO: find out how we can distinguish prompt and completion tokens
        )
        completion_tokens = len(
            response_body.get("generations")[0].get("token_likelihoods")
        )
    total_tokens = prompt_tokens + completion_tokens
    return completion_tokens, prompt_tokens, text_completion, total_tokens


async def define_embedding_model_response(response):
    response_body = json.loads(response.get("body").read())
    embedding = response_body.get("embedding")
    prompt_tokens = response_body["inputTextTokenCount"]
    total_tokens = prompt_tokens
    return embedding, prompt_tokens, total_tokens


async def anthropic_completion_body(request):
    # Append necessary prefix if missing
    # if not request.prompt.startswith(ANTHROPIC_HUMAN):
    #     request.prompt = f"{ANTHROPIC_HUMAN}{request.prompt}"
    # Append necessary suffix if missing
    if not request.prompt.endswith(ANTHROPIC_ASSISTANT):
        request.prompt = f"{request.prompt}{ANTHROPIC_ASSISTANT}"
    # Structure anthropic body
    body = json.dumps(
        {
            "prompt": request.prompt,
            "max_tokens_to_sample": request.max_tokens,
            "temperature": request.temperature,
        }
    )

    return body


async def define_model_body(model_id, request):
    # Define the necessary payload per provider
    if model_id.startswith("amazon"):
        body = json.dumps(
            {
                "inputText": request.prompt,
                "textGenerationConfig": {
                    "maxTokenCount": request.max_tokens,
                    "temperature": request.temperature,
                },
            }
        )
    elif model_id.startswith("anthropic"):
        body = await anthropic_completion_body(request)
    elif model_id.startswith("ai21"):
        body = json.dumps(
            {
                "prompt": request.prompt,
                "maxTokens": request.max_tokens,
                "temperature": request.temperature,
            }
        )
    elif model_id.startswith("cohere"):
        body = json.dumps(
            {
                "prompt": request.prompt,
                "max_tokens": request.max_tokens,
                "temperature": request.temperature,
                "return_likelihoods": "ALL",
            }
        )
    else:
        return None
    return body


def valid_model(model_id, metadata, modality):
    # Checks if given model id exists and is allowed for use for a specific operation
    if not any(model["id"] == model_id and model.get(modality) for model in metadata):
        return False
    return True


def enabled_model(model_id, metadata):
    # Checks if given model id exists and is enabled
    if not any(model["id"] == model_id and model.get("enabled") for model in metadata):
        return False
    return True


def log_error_with_client_id(client_id, endpoint, error_message):
    # Helper function to log errors with client id
    return f"Client: {client_id} | Endpoint: {endpoint} | Error: {error_message}"
