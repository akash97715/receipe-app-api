import json
import os

MODELS_METADATA = json.load(open("app/bedrock/v1/utils/models-metadata.json"))


ENV = os.environ.get("ENV", "dev")
