import json
from collections import defaultdict
from typing import List, Literal, Union, Optional
import os
import boto3
import logging
from fastapi import Request as fastapi_request
from fastapi import APIRouter, HTTPException
from starlette.responses import JSONResponse

from app.bedrock.v1.config import settings
from app.bedrock.v1.models import (
    HealthCheckResponse,
    Status,
    Models,
    CompletionRequest,
    CompletionResponse,
    EmbeddingsResponse,
    EmbeddingsRequest,
    ImageRequest,
    ImageResponse,
    ImageRequest,
    ImageResponse,
)
from app.bedrock.v1.utils.env_vars import ENV, MODELS_METADATA
from app.bedrock.v1.utils.audit import audit

from app.bedrock.v1.utils.helper_functions import (
    enabled_model,
    log_error_with_client_id,
    merge_models_metadata,
    valid_model,
    define_model_body,
    define_completion_model_response,
    define_embedding_model_response,
)

from validator.decorators import async_token_validation_and_metering

router = APIRouter()
logger = logging.getLogger()
logger.setLevel(settings.log_level)

# TODO: Put region in env variable and in secret manager for multi region
aws_region = os.environ.get("AWS_REGION", "")  # picks region from config file (secret)
print("Region name -- ", aws_region)


# Create connection with bedrock
bedrock = boto3.client(service_name="bedrock", region_name=aws_region)
bedrock_runtime = boto3.client(service_name="bedrock-runtime", region_name=aws_region)


# Health check
@router.get(
    "/health",
    status_code=200,
    tags=["Health check"],
)
async def health_check():
    return HealthCheckResponse(status=Status.success, message="Healthy")


@router.get(
    "/models",
    status_code=200,
    tags=["Bedrock models"],
    description="Lists all the available bedrock models",
    response_model=List[Models],
)
@router.get(
    "/models/{modality}",
    status_code=200,
    tags=["Bedrock models"],
    description="Lists all the available bedrock models based on the modality",
    response_model=List[Models],
)
@async_token_validation_and_metering()
async def models(
    request: fastapi_request,
    modality: Optional[
        Union[Literal["chat", "completion", "embeddings", "image"], None]
    ] = None,
):
    try:
        # Get all foundation models
        response = bedrock.list_foundation_models()
        # Structure response
        foundation_models = response.get("modelSummaries")

        models = map(
            lambda d: dict(
                {
                    "id": d.get("modelId"),
                    "model": d.get("modelName"),
                    "provider": d.get("providerName"),
                    "input_modalities": d.get("inputModalities"),
                    "output_modalities": d.get("outputModalities"),
                    "response_streaming_support": d.get(
                        "responseStreamingSupported", False
                    ),
                }
            ),
            foundation_models,
        )

        # Get models metadata
        metadata = MODELS_METADATA

        models_w_metadata = merge_models_metadata(list(models), metadata)

        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            models_w_metadata = [
                model for model in models_w_metadata if model.get("enabled")
            ]

        if modality:
            models_modality = [
                model for model in models_w_metadata if model.get(modality)
            ]
            return models_modality

        return models_w_metadata
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Models Error: {error_text}"
        )


@router.post(
    "/completion",
    status_code=200,
    tags=["Bedrock completion"],
    description="Completion inference using bedrock foundation models",
    response_model=CompletionResponse,
)
@audit()
@async_token_validation_and_metering(uom=6)
async def completion(request: fastapi_request, req: CompletionRequest):
    try:
        model_id = req.model
        if not valid_model(model_id, MODELS_METADATA, "completion") and not valid_model(
            model_id, MODELS_METADATA, "chat"
        ):
            error_message = (
                f"Model {model_id} is not supported for completion operation"
            )
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            if not enabled_model(model_id, MODELS_METADATA):
                error_message = f"Model {model_id} is not enabled yet"
                # Log error with client id if exists
                logger.error(
                    log_error_with_client_id(
                        request.headers.get("x-agw-client_id", None),
                        request.url.path,
                        error_message,
                    )
                )
                return JSONResponse(
                    status_code=400,
                    content={"status": Status.failure, "detail": error_message},
                )
        body = await define_model_body(model_id, req)
        if not body:
            error_message = (
                f"Model {model_id} is not supported for completion operation"
            )
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        response = bedrock_runtime.invoke_model(body=body, modelId=model_id)
        (
            completion_tokens,
            prompt_tokens,
            text_completion,
            total_tokens,
        ) = await define_completion_model_response(model_id, body, response)

        return CompletionResponse(
            status=Status.success,
            result=text_completion,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Completion Error: {error_text}"
        )


@router.post(
    "/embeddings",
    status_code=200,
    tags=["Bedrock embeddings"],
    description="Embeddings creation using bedrock foundation models",
    response_model=EmbeddingsResponse,
)
@async_token_validation_and_metering(uom=6)
async def embeddings(request: fastapi_request, req: EmbeddingsRequest):
    try:
        model_id = req.model
        if not valid_model(model_id, MODELS_METADATA, "embeddings"):
            error_message = (
                f"Model {model_id} is not supported for embeddings operation"
            )
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            if not enabled_model(model_id, MODELS_METADATA):
                error_message = f"Model {model_id} is not enabled yet"
                # Log error with client id if exists
                logger.error(
                    log_error_with_client_id(
                        request.headers.get("x-agw-client_id", None),
                        request.url.path,
                        error_message,
                    )
                )
                return JSONResponse(
                    status_code=400,
                    content={"status": Status.failure, "detail": error_message},
                )
        body = json.dumps({"inputText": req.prompt})
        response = bedrock_runtime.invoke_model(body=body, modelId=model_id)
        embedding, prompt_tokens, total_tokens = await define_embedding_model_response(
            response
        )
        return EmbeddingsResponse(
            status=Status.success,
            embedding=embedding,
            prompt_tokens=prompt_tokens,
            total_tokens=total_tokens,
        )
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Embeddings Error: {error_text}"
        )


@router.post(
    "/image",
    status_code=200,
    tags=["Bedrock image"],
    description="Image creation using bedrock foundation models",
    response_model=ImageResponse,
)
@async_token_validation_and_metering()
async def image(request: fastapi_request, req: ImageRequest):
    try:
        model_id = req.model
        if not valid_model(model_id, MODELS_METADATA, "image"):
            error_message = f"Model {model_id} is not supported for image generation"
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            if not enabled_model(model_id, MODELS_METADATA):
                error_message = f"Model {model_id} is not enabled yet"
                # Log error with client id if exists
                logger.error(
                    log_error_with_client_id(
                        request.headers.get("x-agw-client_id", None),
                        request.url.path,
                        error_message,
                    )
                )
                return JSONResponse(
                    status_code=400,
                    content={"status": Status.failure, "detail": error_message},
                )
        body = json.dumps(
            {
                "text_prompts": [{"text": req.prompt}],
                "cfg_scale": req.cfg_scale,
                "seed": req.seed,
                "steps": req.generation_steps,
                "style_preset": req.style_preset,
            }
        )

        response = bedrock_runtime.invoke_model(body=body, modelId=model_id)
        response_body = json.loads(response.get("body").read())
        base_64_img_str = response_body["artifacts"][0].get("base64")
        return ImageResponse(status=Status.success, image=base_64_img_str)
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Image Error: {error_text}"
        )
