from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.bedrock.v1.api import router as bedrock_v1

PREFIX_V1 = "/bedrock"
TAGS_METADATA = [
    {
        "name": "Bedrock Services",
        "description": """Bedrock Services""",
    },
]

# Remove docs_url for hiding swagger
app = FastAPI(
    title="Bedrock Services",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
    docs_url="/bedrock/docs",
    openapi_url="/bedrock/openapi.json",
)

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(bedrock_v1, prefix=PREFIX_V1)
