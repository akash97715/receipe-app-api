from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_get():
    """Test Fargate app1 get"""
    response = client.get("/fargate_app1/v1/get")
    assert response.status_code == 200