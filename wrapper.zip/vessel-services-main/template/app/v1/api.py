import logging

from fastapi import APIRouter
from sample.foo import bar

from app.app1.v1.config import settings


router = APIRouter()

logger = logging.getLogger()
logger.setLevel(settings.log_level)


APP = "Fargate 1"


@router.get("/get", status_code=200)
async def get():
    return f"Hello World! -- {APP}"


@router.post("/post", status_code=200)
async def post():
    return {"message": f"Hello World! -- {APP}", "lib": bar(APP)}
