# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import abc
import json
import os
import logging
import uuid
import json
import datetime

import boto3

# from metering_svc_db_accessor import MeteringSvcDbAccessor
import requests

aws_access_key_id = os.environ.get("DYNAMO_DB_AWS_ACCESS_KEY_ID", "DYNAMO_DB_AWS_ACCESS_KEY_ID")
aws_secret_access_key = os.environ.get("DYNAMO_DB_AWS_SECRET_ACCESS_KEY", "DYNAMO_DB_AWS_SECRET_ACCESS_KEY")
aws_region = os.environ.get("DYNAMO_DB_AWS_REGION", "us-east-1")


# DynamoDB accessor that implements MeteringSvcDbAccessor protocol
class DynamoDBAccessor():
    g_aicore_sess = None

    # Handle transient errors using exponential backoff with Jitter
    # Wait 2^i * 100 ms, on the i-th retry | wait 20 second per try maximum
    # (TODO: Move these values to Configuration)
    @staticmethod
    def get_db_session(force_reset=False):
        # VESSEL_DB_HOST env contain the DB host
        #

        try:
            session = boto3.Session(
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
            )
            DynamoDBAccessor.g_aicore_sess = session.resource('dynamodb', region_name=aws_region)

            return DynamoDBAccessor.g_aicore_sess
        except Exception as ex:
            DynamoDBAccessor.g_aicore_sess = None
            logging.warning('Error in Opening a Dynamodb Connection. It will be Retried. %s', str(ex))
            raise


    @staticmethod
    def save_contract_details(svc_req):
        try:
            aicore_sess = DynamoDBAccessor.get_db_session()
            

            svc = aicore_sess.Table("vessel-{env}-contract-details".format(env='dev'))

            response = svc.put_item(
                Item={
                    'contract_id': svc_req["contract_id"],
                    'client_id': svc_req['client_id'],
                    'project_name': svc_req['project_name'],
                    'api_id':  svc_req['api_id'],
                    'business_email':  svc_req['business_email'],
                    'support_email': svc_req["support_email"]

                }
            )
            print(response) 
            return "success"
        except Exception as ex:
            logging.warn('Error occured in Vessel:DynamoDBAccessor. %s', str(ex))
            return "failure"
