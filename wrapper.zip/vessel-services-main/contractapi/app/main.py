from fastapi import FastAPI, Request
from validator.decorators import async_token_validation_and_metering
from .dynamodb_accessor import DynamoDBAccessor

app = FastAPI()

@app.get("/health")
def health():
    return {"message": "I'm healthy"}


@app.post("/contractapi/create_contract")
@async_token_validation_and_metering()
async def contract_api(request: Request=None):
    json = await request.json()
    print("testing 4",json)
    status = DynamoDBAccessor.save_contract_details(json["service_request"]["data"][0])
    
    if status != "success":
        return {"service_response":{"success":"0","message": "Failed to acknowledge"}}
    return {"service_response":{"success":"1","message": "Acknowledged"}}
