import unittest
import logging
from unittest.mock import patch

import fastapi
import openai
import pytest
import httpx
from httpx import AsyncClient
from fastapi.testclient import TestClient
from fastapi import APIRouter, HTTPException
import json
from app.main import app
from unittest import mock
import asyncio
from dotenv import load_dotenv
from app.azure_openai.v1.models import (
    Model,
    Deploy,
    Response,
    Request,
    Status,
    HealthCheckResponse,
    ChatMessage,
    ChatRequest,
    EmbeddingsRequest,
)
from _pytest.monkeypatch import MonkeyPatch

# from openai import util

# load_dotenv()

from utils.libzip.validator.decorators import async_token_validation_and_metering

client = TestClient(app)

print(client)

print("Test file called")

base_url = "https://vsl-dev.pfizer.com/openai"

loop = asyncio.get_event_loop()

logging.error(loop)


class Testing(unittest.IsolatedAsyncioTestCase):
    pass

    # test for health check

    def test_health_check(self):
        # client = TestClient(app)

        res = client.get("openai/health_check")

        data = res.json()

    def test_missing_payload(self):
        """Requests missing a payload should be rejected"""

        response = client.post("openai/vessel_completion")

        logging.info("Response from  Missing_payload function", response)

        assert response.status_code == 422

    # test for vessel_completion

    # @mock.patch("openai.Completion.acreate")
    # @mock.patch("os.environ.get", return_value="API_VERSION_STABLE/2023-05-15")
    # # @pytest.mark.asyncio
    # async def test_vessel_completion_with_payload(self, mock_os, mock_op):
    #     post_data = {
    #         "prompt": "what is the capital of India??",
    #         "engine": "text-davinci-003",
    #         "max_tokens": 5,
    #         "temperature": 0
    #     }
    #     mock_op.return_value = util.convert_to_openai_object({
    #         "choices": [
    #             {
    #                 "finish_reason": "length",
    #                 "index": 0,
    #                 "logprobs": None,
    #                 "text": " food\n\nFrance is famous for its rich and varied cuisine, which is"
    #             }
    #         ],
    #         "created": 1673038824,
    #         "id": "cmpl-6Vo76GH3SqNxx801VtVMmyWupzbKD",
    #         "model": "text-davinci-003",
    #         "object": "text_completion",
    #         "usage": {
    #             "completion_tokens": 15,
    #             "prompt_tokens": 5,
    #             "total_tokens": 20
    #         }
    #     }
    #     )
    #     mock_response = client.post("/openai/vessel_completion", data=json.dumps(post_data))
    #     print("Mock response --- ", mock_response)

    # test for vessel_chat completion

    @mock.patch(
        "app.azure_openai.v1.api.vessel_chatcompletion",
        return_value={
            "status": "success",
            "result": '{"role": "assistant", "content": "A virus is a tiny infectious agent that can only replicate inside the cells of living organisms. It consists of genetic material (either DNA or RNA) surrounded by a protein coat, and sometimes an outer envelope. Viruses can cause a wide range of diseases in humans, animals, and plants, including the common cold, flu, HIV/AIDS, and COVID-19."}',
            "totalTokens": 100,
        },
    )
    @mock.patch(
        "app.azure_openai.v1.models.Response",
        return_value={
            "status": "success",
            "result": '{"role": "assistant", "content": "A virus is a tiny infectious agent that can only replicate inside the cells of living organisms. It consists of genetic material (either DNA or RNA) surrounded by a protein coat, and sometimes an outer envelope. Viruses can cause a wide range of diseases in humans, animals, and plants, including the common cold, flu, HIV/AIDS, and COVID-19."}',
            "totalTokens": 100,
        },
    )
    @mock.patch("openai.ChatCompletion.acreate")
    @mock.patch("os.environ.get", return_value="API_VERSION_STABLE/2023-05-15")
    async def test_chatcompletion_with_payload(
        self, mock_os, mock_op, mock_res, mock_vcc
    ):
        post_data = {
            "engine": "text-davinci-003",
            "messages": [
                {
                    "role": "system",
                    "content": "You are a digital assistant for Pfizer Inc",
                },
                {"role": "user", "content": "what is virus ? ? ?"},
            ],
            "temperature": 0,
            "max_tokens": 1000,
        }
        response = await openai.ChatCompletion.acreate(
            {
                "engine": "text-davinci-003",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a digital assistant for Pfizer Inc",
                    },
                    {"role": "user", "content": "what is virus ? ? ?"},
                ],
                "temperature": 0,
                "max_tokens": 1000,
            }
        )
        mock_response = client.post(
            "/openai/vessel_chatCompletion", data=json.dumps(post_data)
        )
        mock_op.return_value = response
        print("Response from :test chat completion_with_payload  --- ", response)

    # @mock.patch("openai.Completion.acreate", return_value='')
    # def test_summarize_with_payload(mock_openai):  # ,mock_http):
    #
    #     """Requests missing a payload should be rejected"""
    #
    #     post_data = {
    #
    #         "prompt": "explain antibody",
    #
    #         "max_tokens": 30,
    #
    #         "temperature": 0.1,
    #
    #         "engine": "text-davinci-003"
    #
    #     }
    #
    #     response = client.post("/openai/summarize", data=json.dumps(post_data))
    #
    #     print(response)

    @mock.patch("app.azure_openai.v1.util.audit")
    @mock.patch("utils.libzip.validator.decorators.async_token_validation_and_metering")
    def test_completion(self, mock_meter, mock_audit):
        mock_meter = Response(
            status="success",
            result='{"role": "assistant", "content": "The headquarters of Pfizer Inc. is located in New York City, United States."}',
            totalTokens=46,
        )
        mock_audit = Response(
            status="success",
            result='{"role": "assistant", "content": "The headquarters of Pfizer Inc. is located in New York City, United States."}',
            totalTokens=46,
        )
        mock_audit.status = mock_meter.status
        mock_audit.result = mock_meter.result
        mock_audit.totalTokens = mock_meter.totalTokens
        post_data = {
            "prompt": "what is the capital of India??",
            "engine": "gpt-35-turbo",
            "max_tokens": 5,
            "temperature": 0,
        }
        header = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer 00019zOiOl5T3BgXCmZoBa0L1hIP",
        }
        print(mock_audit)
        response = client.post(
            "/openai/completion", headers=header, json=json.dumps(post_data)
        )

    # test for async def deployments():

    @mock.patch(
        "app.azure_openai.v1.api.deployments",
        return_value=[
            {
                "id": "text-ada-001",
                "model": "text-ada-001",
                "status": "succeeded",
                "owner": "organization-owner",
            },
            {
                "id": "text-curie-001",
                "model": "text-curie-001",
                "status": "succeeded",
                "owner": "organization-owner",
            },
        ],
    )
    @mock.patch(
        "app.azure_openai.v1.models.Deploy",
        return_value={
            "id": "text-ada-001",
            "model": "text-ada-001",
            "status": "succeeded",
            "owner": "organization-owner",
        },
    )
    @mock.patch("openai.Deployment.list")
    @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    def test_deployments(self, mock_os, mock_dp, mock_md, mock_d):
        deployments = openai.Deployment.list()
        mock_dp.return_value = deployments
        response = client.get("openai/deployments")
        print("Response from deployments-- ", response)

    # test for completion deployments
    # @mock.patch("app.azure_openai.v1.api.completion_deployments", return_value=[
    #     {
    #         "id": "text-ada-001",
    #         "model": "text-ada-001",
    #         "status": "succeeded",
    #         "owner": "organization-owner"
    #     },
    #     {
    #         "id": "text-curie-001",
    #         "model": "text-curie-001",
    #         "status": "succeeded",
    #         "owner": "organization-owner"
    #     }])
    # @mock.patch("app.azure_openai.v1.models.Deploy", return_value={
    #     "id": "text-ada-001",
    #     "model": "text-ada-001",
    #     "status": "succeeded",
    #     "owner": "organization-owner"
    # })
    # @mock.patch("openai.Deployment.list")
    # @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    # def test_completion_deployments(self, mock_os, mock_dp, mock_md, mock_d):
    #     deployments = openai.Deployment.list()
    #     mock_dp.return_value = deployments
    #     response = client.get('openai/deployments/completion')
    #     print("Response from completion deployments-- ", response)

    # test for chat completion deployments
    @mock.patch(
        "app.azure_openai.v1.api.chat_deployments",
        return_value=[
            {
                "id": "text-ada-001",
                "model": "text-ada-001",
                "status": "succeeded",
                "owner": "organization-owner",
            },
            {
                "id": "text-curie-001",
                "model": "text-curie-001",
                "status": "succeeded",
                "owner": "organization-owner",
            },
        ],
    )
    @mock.patch(
        "app.azure_openai.v1.models.Deploy",
        return_value={
            "id": "text-ada-001",
            "model": "text-ada-001",
            "status": "succeeded",
            "owner": "organization-owner",
        },
    )
    @mock.patch("openai.Deployment.list")
    @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    def test_chat_deployments(self, mock_os, mock_dp, mock_md, mock_d):
        deployments = openai.Deployment.list()
        mock_dp.return_value = deployments
        response = client.get("openai/deployments/chat")
        print("Response from chat deployments-- ", response)

    # test for embeddings deployments
    # @mock.patch("app.azure_openai.v1.api.embeddings_deployments", return_value=[
    #     {
    #         "id": "text-ada-001",
    #         "model": "text-ada-001",
    #         "status": "succeeded",
    #         "owner": "organization-owner"
    #     },
    #     {
    #         "id": "text-curie-001",
    #         "model": "text-curie-001",
    #         "status": "succeeded",
    #         "owner": "organization-owner"
    #     }])
    # @mock.patch("app.azure_openai.v1.models.Deploy", return_value={
    #     "id": "text-ada-001",
    #     "model": "text-ada-001",
    #     "status": "succeeded",
    #     "owner": "organization-owner"
    # })
    # @mock.patch("openai.Deployment.list")
    # @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    # def test_embeddings_deployments(self, mock_os, mock_dp, mock_md, mock_d):
    #     deployments = openai.Deployment.list()
    #     mock_dp.return_value = deployments
    #     response = client.get('openai/deployments/embeddings')
    #     print("Response from embeddings deployments-- ", response)

    # test for deployment

    @mock.patch("openai.Deployment.retrieve")
    @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    def test_deployment(self, mock_os, mock_md):
        mock_md.return_value = [
            Deploy(id="1234", model="abcd", status="success", owner="abcd")
        ]
        response = client.get("openai/deployment")
        print("Response from  deployments-- ", response)

    # test for rate limit

    def test_rate_limit(self):
        res = client.get("openai/rate_limit")

        data = res.json()

    # test for get models

    # @mock.patch("openai.Model.list")
    # def test_models(self, mock_dp):
    #     deployments = openai.Model.list()
    #     mock_dp.return_value = util.convert_to_openai_object({
    #         "data": [
    #             {
    #                 "capabilities": {
    #                     "fine_tune": True,
    #                     "inference": True,
    #                     "completion": True,
    #                     "chat_completion": False,
    #                     "embeddings": False
    #                 },
    #                 "lifecycle_status": "generally-available",
    #                 "deprecation": {
    #                     "fine_tune": 1677662127,
    #                     "inference": 1709284527
    #                 },
    #                 "id": "curie",
    #                 "status": "succeeded",
    #                 "created_at": 1646126127,
    #                 "updated_at": 1646127311,
    #                 "object": "model"
    #             },
    #             {
    #                 "model": "curie",
    #                 "fine_tune": "ft-72a2792ef7d24ba7b82c7fe4a37e379f",
    #                 "capabilities": {
    #                     "fine_tune": False,
    #                     "inference": True,
    #                     "completion": True,
    #                     "chat_completion": False,
    #                     "embeddings": False
    #                 },
    #                 "lifecycle_status": "generally-available",
    #                 "deprecation": {
    #                     "inference": 1709284527
    #                 },
    #                 "id": "curie.ft-72a2792ef7d24ba7b82c7fe4a37e379f",
    #                 "status": "succeeded",
    #                 "created_at": 1646126127,
    #                 "updated_at": 1646127311,
    #                 "object": "model"
    #             }
    #         ],
    #         "object": "list"
    #     })
    #     print("------ ", deployments)
    #     response = client.get('/openai/models')
    #     print("Response from /models-- ", response)

    @mock.patch("utils.libzip.validator.decorators.async_token_validation_and_metering")
    @mock.patch("app.azure_openai.v1.util.audit")
    @mock.patch("app.azure_openai.v1.api.completion")
    @mock.patch(
        "app.azure_openai.v1.models.Response",
        return_value={
            "status": "success",
            "result": '{"role": "assistant", "content": "A virus is a tiny infectious agent that can only replicate inside the cells of living organisms. It consists of genetic material (either DNA or RNA) surrounded by a protein coat, and sometimes an outer envelope. Viruses can cause a wide range of diseases in humans, animals, and plants, including the common cold, flu, HIV/AIDS, and COVID-19."}',
            "totalTokens": 100,
        },
    )
    @mock.patch("os.environ.get", return_value="MULESOFT_COMPLETION_ENDPOINT/3.0")
    @mock.patch("os.environ.get", return_value="API_VERSION_STABLE/2023-05-15")
    async def test_completion(
        self, mock_os_api, mock_os_mule, mock_rs, mock_ch, mock_meter, mock_audit
    ):
        mock_meter = Response(
            status="success",
            result='{"role": "assistant", "content": "The headquarters of Pfizer Inc. is located in New York City, United States."}',
            totalTokens=46,
        )
        mock_audit = Response(
            status="success",
            result='{"role": "assistant", "content": "The headquarters of Pfizer Inc. is located in New York City, United States."}',
            totalTokens=46,
        )
        mock_audit.status = mock_meter.status
        mock_audit.result = mock_meter.result
        mock_audit.totalTokens = mock_meter.totalTokens
        post_data = {
            "prompt": "what is the capital of India??",
            "engine": "gpt-35-turbo",
            "max_tokens": 5,
            "temperature": 0,
            "api-version": "2023-05-15",
        }
        header = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer 00019zOiOl5T3BgXCmZoBa0L1hIP",
        }
        # with mock.patch('client.post',return_value=mock_audit):
        # print(audit)
        # assert audit.__wrapped__() == mock_audit
        # http://mule4api-comm-amer-stg.pfizer.com/azure-openai-compl-lb-v1/openai/deployments/3.0/completions?api-version=2023-05-15
        # response = client.post('http://mule4api-comm-amer-stg.pfizer.com/azure-openai-compl-lb-v1/openai/deployments/4/completions?api-version=2023-05-15',headers=header, json=json.dumps(post_data), timeout=120)
        response = client.post("/vessel-openai-api-v1/completion")

    @mock.patch(
        "openai.Completion.acreate",
        side_effect=fastapi.exceptions.HTTPException(status_code=401),
    )
    @mock.patch("os.environ.get", return_value="API_VERSION_STABLE/2023-05-15")
    def test_vessel_completion_exception(self, mock_os, mock_op):
        with self.assertRaises(Exception):
            post_data = {
                "prompt": "explain antibody",
                "max_tokens": "30",
                "temperature": "0.1",
                "engine": "text-davinci-100",
            }
            mock_response = client.post(
                "/openai/vessel_completion", headers={}, json=post_data
            )
            print("Mock response --- ", mock_response)

    @mock.patch(
        "openai.ChatCompletion.acreate",
        side_effect=fastapi.exceptions.HTTPException(status_code=401),
    )
    @mock.patch("os.environ.get", return_value="API_VERSION_STABLE/2023-05-15")
    def test_vessel_chatcompletion_exception(self, mock_os, mock_op):
        with self.assertRaises(Exception):
            post_data = {
                "engine": "text-davinci-003",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a digital assistant for Pfizer Inc",
                    },
                    {"role": "user", "content": "what is virus ? ? ?"},
                ],
                "temperature": 0,
                "max_tokens": 1000,
            }
            mock_response = client.post(
                "/openai/vessel_chatCompletion", headers={}, json=post_data
            )
            print("Mock response --- ", mock_response)

    @mock.patch(
        "openai.Model.list",
        side_effect=fastapi.exceptions.HTTPException(status_code=401),
    )
    def test_models_exception(self, mock_dp):
        with self.assertRaises(Exception):
            response = client.get("/openai/models", headers={})
            print("Response from /models-- ", response)

    # deployments exception

    @mock.patch(
        "openai.Deployment.list",
        side_effect=fastapi.exceptions.HTTPException(status_code=401),
    )
    @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    def test_deployments_exception(self, mock_os, mock_dp):
        with self.assertRaises(Exception):
            response = client.get("openai/deployments", headers={})
            print("Response from deployments-- ", response)

    # completion deployment exception

    @mock.patch(
        "openai.Deployment.list",
        side_effect=fastapi.exceptions.HTTPException(status_code=401),
    )
    @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    def test_completion_deployments_exception(self, mock_os, mock_dp):
        with self.assertRaises(Exception):
            response = client.get("openai/deployments/completion", headers={})
            print("Response from completion deployments-- ", response)

    # chat completion deployment exception

    @mock.patch(
        "openai.Deployment.list",
        side_effect=fastapi.exceptions.HTTPException(status_code=401),
    )
    @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    def test_chat_deployments_exception(self, mock_os, mock_dp):
        with self.assertRaises(Exception):
            response = client.get("openai/deployments/chat")
            print("Response from chat deployments-- ", response)

    # embeddings deployment exception

    @mock.patch(
        "openai.Deployment.list",
        side_effect=fastapi.exceptions.HTTPException(status_code=401),
    )
    @mock.patch("os.environ.get", return_value="API_VERSION_LEGACY/2022-12-01")
    def test_embeddings_deployments_exception(self, mock_os, mock_dp):
        with self.assertRaises(Exception):
            response = client.get("openai/deployments/embeddings")
            print("Response from embeddings deployments-- ", response)

    @patch(
        "app.azure_openai.v1.api.httpx.AsyncClient.post",
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {
                        "object": "embedding",
                        "index": 0,
                        "embedding": [-0.037301734, -0.0013668785, -0.023709593],
                    }
                ],
                "model": "ada",
                "usage": {"prompt_tokens": 6, "total_tokens": 6},
            },
        ),
    )
    @mock.patch("os.environ.get", return_value="MULESOFT_COMPLETION_ENDPOINT/3.0")
    @mock.patch("os.environ.get", return_value="API_VERSION_STABLE/2023-05-15")
    async def test_embeddings_main(self, mock_1, mock_2, mock_resp):
        post_data = {
            "input": ["hello there", "how are you?"],
            "engine": "text-embedding-ada-002",
        }
        header = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": "Bearer 00019zOiOl5T3BgXCmZoBa0L1hIP",
        }
        async with AsyncClient(app=app, base_url="http://test") as ac:
            response = await ac.post(
                "/openai/embeddings", headers=header, json=post_data
            )

            assert response.status_code == 200
