from fastapi import FastAPI, HTTPException
from fastapi.middleware.gzip import GZipMiddleware
import logging
from starlette.requests import Request
from app.azure_openai.v1.api import router as openai_v1
from app.azure_openai.v1.config import settings
import os
import requests
import json
import openai

PREFIX_V1 = "/openai"
TAGS_METADATA = [
    {
        "name": "Azure OpenAI Services",
        "description": """Azure OpenAI Services.""",
    },
]

app = FastAPI(
    title="Vessel Azure OpenAI Services",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
)
# async def catch_exceptions_middleware(request: Request, call_next):
#     try:
#         return await call_next(request)
#     except Exception as e:
#         logging.getLogger().error(str(e))
#         raise HTTPException(status_code=400, detail=f"Error: {str(e)}")

# app.middleware('http')(catch_exceptions_middleware)

app.include_router(openai_v1, prefix=PREFIX_V1)
app.add_middleware(GZipMiddleware, minimum_size=500)


@app.on_event("startup")
async def startup_event():
    logging.getLogger().warning("Start up !")
    # taskUrl = "{0}/task".format(os.environ.get('ECS_CONTAINER_METADATA_URI_V4'))
    # res = requests.get(taskUrl)
    # availabilityZone = json.loads(res.content)['AvailabilityZone']
    # logging.getLogger().warning(availabilityZone)
    # regions = json.loads(os.environ.get('OPENAI_REGIONS'))
    # openai.api_key = regions[availabilityZone]['api_key']
    # openai.api_base = regions[availabilityZone]['api_base']
    # logging.getLogger().warning(regions)
    # logging.getLogger().warning(openai.api_base)
    # logging.getLogger().warning(openai.api_key)
