import logging
import os

# # openai_lib_path = " /Library/Frameworks/Python.framework/Versions/3.9/lib/python3.9/site-packages/openai"
# openai_lib_path = sys.path[1]
# print("00000 ", openai_lib_path)
# sys.path.insert(0, os.path.abspath("/Users/kritikarao/Documents/vsl-services-0408/vessel-services/venv/lib/python3.9/site-packages/openai/"))
# print(sys.path)
# sys.path.append(os.path.abspath("/Users/kritikarao/Documents/vsl-services-0408/vessel-services/venv/lib/python3.9/site-packages/openai/"))
# print("appended ---- ", sys.path)
# # openai_spec = importlib.util.spec_from_file_location('openai', openai_lib_path)
# # print("open ai spec ", openai_spec)
# # openai_module = importlib.util.module_from_spec(openai_spec)
# # openai_spec.loader.exec_module(openai_module)

import openai
import json
import backoff
import requests
import base64
import httpx
from typing import List
from typing import Any, Union
from fastapi import Request as fastapi_request
import tiktoken

from fastapi import APIRouter, HTTPException
from app.azure_openai.v1.config import settings
from app.azure_openai.v1.models import (
    Model,
    Deploy,
    Response,
    Request,
    Status,
    HealthCheckResponse,
    ChatMessage,
    ChatRequest,
    EmbeddingsRequest,
    ImageRequest,
)

from validator.decorators import async_token_validation_and_metering
from app.azure_openai.v1.util import audit
from fastapi.responses import StreamingResponse

router = APIRouter()
logger = logging.getLogger()
logger.setLevel(settings.log_level)
openai.api_type = "azure"
openai.api_base = os.environ.get("OPENAI_API_BASE", "")

openai.api_key = os.environ.get("OPENAI_API_KEY", "")

mulesoft_username = os.environ.get("MULESOFT_USERNAME", "")
mulesoft_password = os.environ.get("MULESOFT_PASSWORD", "")

client = httpx.AsyncClient(timeout=120)


@router.get(
    "/health_check",
    status_code=200,
    tags=["Health check"],
)
async def health_check():
    print("health check -- ")
    return HealthCheckResponse(
        status=Status.success, message="health_check completed successfully"
    )


# Vessel Completion endpoint


@router.post(
    "/vessel_completion", status_code=200, tags=["Completion"], response_model=Response
)
async def vessel_completion(request: fastapi_request, req: Request):
    try:
        print("requestttttttttt ", req.prompt)
        openai.api_version = os.environ.get("API_VERSION_STABLE")
        response = await openai.Completion.acreate(
            engine=req.engine,
            prompt=req.prompt,
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        )
        print("RRRRRRR from Vc -- ", response)
        return Response(
            status=Status.success,
            result=response.choices[0].text,
            totalTokens=response.usage.total_tokens,
        )
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.post(
    "/completion", status_code=200, tags=["Completion"], response_model=Response
)
@audit()
@async_token_validation_and_metering(uom=6)
async def completion(request: fastapi_request, req: Request):
    try:
        headers = {}
        if "Authorization" in request.headers:
            headers["Authorization"] = request.headers["Authorization"]
        if "x-agw-client_id" in request.headers:
            headers["x-agw-client_id"] = request.headers["x-agw-client_id"]
        payload = {
            "prompt": req.prompt,
            "max_tokens": req.max_tokens,
            "temperature": req.temperature,
        }
        url = os.environ.get("MULESOFT_COMPLETION_ENDPOINT").format(
            req.engine, os.environ.get("API_VERSION_STABLE")
        )
        # logger.warning("{0}\n{1}\n{2}".format(url, payload, headers))
        response = await client.post(
            url=url, json=payload, headers=headers, timeout=120
        )
        response.raise_for_status()
        result = response.json()

        return Response(
            status=Status.success,
            result=result["choices"][0]["text"],
            totalTokens=result["usage"]["total_tokens"],
        )
    except httpx.TimeoutException as e:
        logger.error(f"MuleSoft Completion Timeout: {e}")
        raise HTTPException(
            status_code=408, detail=f"Error: MuleSoft Completion Timeout"
        )
    except Exception as e:
        logger.error(f"ERROR completion: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error completion: {error_text}"
        )


@router.post(
    "/vessel_chatCompletion",
    status_code=200,
    tags=["chatCompletion"],
    response_model=Response,
)
async def vessel_chatcompletion(request: fastapi_request, req: ChatRequest):
    try:
        openai.api_version = os.environ.get("API_VERSION_STABLE")

        # Use acreate for async
        response = await openai.ChatCompletion.acreate(
            engine=req.engine,
            messages=req.messages,
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        )
        print("RRRRRRR from Vcc ", response)
        # response = OpenAIObject(response.id)
        return Response(
            status=Status.success,
            result=(str)(response.choices[0]["message"]),
            totalTokens=response.usage.total_tokens,
        )

    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.post(
    "/chatCompletion", status_code=200, tags=["chatCompletion"], response_model=Response
)
@audit()
# decorator for metering
@async_token_validation_and_metering(uom=6)
async def chatcompletion(request: fastapi_request, req: ChatRequest):
    try:
        headers = {}
        if "Authorization" in request.headers:
            headers["Authorization"] = request.headers["Authorization"]
        if "x-agw-client_id" in request.headers:
            headers["x-agw-client_id"] = request.headers["x-agw-client_id"]
        payload = {
            "messages": req.messages,
            "max_tokens": req.max_tokens,
            "temperature": req.temperature,
        }
        url = os.environ.get("MULESOFT_CHAT_ENDPOINT").format(
            req.engine, os.environ.get("API_VERSION_STABLE")
        )
        # logger.warning("{0}\n{1}\n{2}".format(url, payload, headers))
        response = await client.post(
            url=url, json=payload, headers=headers, timeout=120
        )
        response.raise_for_status()
        result = response.json()

        return Response(
            status=Status.success,
            result=json.dumps(result["choices"][0]["message"]),
            totalTokens=result["usage"]["total_tokens"],
        )
    except httpx.TimeoutException as e:
        logger.error(f"MuleSoft chatCompletion Timeout: {e}")
        raise HTTPException(
            status_code=408, detail=f"Error: MuleSoft chatCompletion Timeout"
        )
    except Exception as e:
        logger.error(f"ERROR chatCompletion: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error chatCompletion: {error_text}"
        )


@router.post(
    "/summarize", status_code=200, tags=["Completion"], response_model=Response
)
@audit()
@async_token_validation_and_metering(uom=6)
# @backoff.on_exception(backoff.expo, openai.error.RateLimitError)
async def summarize(request: fastapi_request, req: Request):
    try:
        openai.api_version = os.environ.get("API_VERSION_STABLE")
        response = await openai.Completion.acreate(
            engine=req.engine,
            prompt="Provide a summary of the text below that captures its main idea.{0}".format(
                req.prompt
            ),
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        )

        return Response(
            status=Status.success,
            result=response.choices[0].text,
            totalTokens=response.usage.total_tokens,
        )
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.post(
    "/press_release", status_code=200, tags=["Completion"], response_model=Response
)
@audit()
@async_token_validation_and_metering(uom=6)
async def press_release(request: fastapi_request, req: Request):
    try:
        openai.api_version = os.environ.get("API_VERSION_STABLE")
        response = await openai.Completion.acreate(
            engine=req.engine,
            prompt="Create a press release for the following product : {0}. Use professional tone and be as detailed as possible.An example of press release for a product is the following {1} ".format(
                req.prompt, open("CLEAR_eHLT_PressRelease.txt").readlines()
            ),
            temperature=req.temperature,
            max_tokens=req.max_tokens,
        )

        return Response(
            status=Status.success,
            result=response.choices[0].text,
            totalTokens=response.usage.total_tokens,
        )
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.get("/models", status_code=200, tags=["Models"], response_model=List[Model])
async def models():
    try:
        openai.api_version = os.environ.get("API_VERSION_STABLE")
        models = openai.Model.list()
        data = []
        models_metadata = json.load(open("models-metadata.json"))
        for item in models.data:
            metadata = next((x for x in models_metadata if x["id"] == item.id), None)
            model = Model(
                id=item.id,
                lifecycle_status=item.lifecycle_status,
                fine_tune=item.capabilities.fine_tune,
                inference=item.capabilities.inference,
                completion=item.capabilities.completion,
                embeddings=item.capabilities.embeddings,
            )
            if metadata:
                model.max_tokens = metadata["max_tokens"]
                model.description = metadata["description"]
                model.training_data = metadata["training_data"]
                model.chatCompletion = metadata["chatCompletion"]
                model.use_cases = metadata["use_cases"]
                model.family = metadata["family"]

            data.append(model)

        return data
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.get(
    "/deployments", status_code=200, tags=["Deployments"], response_model=List[Deploy]
)
async def deployments():
    try:
        openai.api_version = os.environ.get("API_VERSION_LEGACY")
        deployments = openai.Deployment.list()
        print("Deployments -----  ", deployments)
        data = []
        print("Deploy data ", deployments["data"])
        for item in deployments.data:
            print("item is----", item)
            data.append(
                Deploy(
                    id=item.id, model=item.model, status=item.status, owner=item.owner
                )
            )

        return data
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


def find_deployed_models(deployments, all_models):
    deployed_models = []
    for deployment in deployments:
        for model in all_models:
            if model["id"].startswith(deployment["id"]):
                deployed_models.append(
                    Deploy(
                        id=deployment["id"],
                        model=deployment["model"],
                        status=deployment["status"],
                        owner=deployment["owner"],
                    )
                )
                break
    return deployed_models


def define_completion_models(deployments, models):
    # Find all available completion models
    all_completion_models = [
        model
        for model in models
        if model["capabilities"]["completion"]
        or model["capabilities"]["inference"]
        and not model["capabilities"]["embeddings"]
    ]
    # Find which of the deployed models support completion
    deployed_models = find_deployed_models(deployments, all_completion_models)
    return deployed_models


@router.get(
    "/deployments/completion",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
)
async def completion_deployments():
    try:
        openai.api_version = os.environ.get("API_VERSION_LEGACY")
        deployments = openai.Deployment.list()
        models = openai.Model.list()
        data = define_completion_models(deployments.data, models.data)
        return data
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.get(
    "/deployments/chat",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
)
async def chat_deployments():
    try:
        openai.api_version = os.environ.get("API_VERSION_LEGACY")
        deployments = openai.Deployment.list()
        data = []

        models_metadata = json.load(open("models-metadata.json"))
        for item in deployments.data:
            metadata = next((x for x in models_metadata if x["id"] == item.model), None)

            if metadata and metadata["chatCompletion"]:
                data.append(
                    Deploy(
                        id=item.id,
                        model=item.model,
                        status=item.status,
                        owner=item.owner,
                    )
                )
        return data
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


def define_embeddings_models(deployments, models):
    # Find all available embeddings models
    all_embeddings_models = [
        model for model in models if model["capabilities"]["embeddings"]
    ]
    # Find which of the deployed models support embeddings
    deployed_models = find_deployed_models(deployments, all_embeddings_models)
    return deployed_models


@router.get(
    "/deployments/embeddings",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
)
async def embeddings_deployments():
    try:
        openai.api_version = os.environ.get("API_VERSION_LEGACY")
        deployments = openai.Deployment.list()
        models = openai.Model.list()
        data = define_embeddings_models(deployments.data, models.data)
        return data
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.get("/deployment", status_code=200, tags=["Deployments"], response_model=Deploy)
async def deployment(deployment_id: str):
    try:
        openai.api_version = os.environ.get("API_VERSION_LEGACY")
        item = openai.Deployment.retrieve(deployment_id)
        print("item from deployment ", item)
        return Deploy(
            id=item.id, model=item.model, status=item.status, owner=item.owner
        )
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")


@router.get("/rate_limit", status_code=429)
def rate_limit():
    return HTTPException(
        status_code=429,
        detail="You exceeded your current quota, please check your plan and billing details",
    )


@router.post(
    "/vessel_embeddings", status_code=200, tags=["Embeddings"], response_model=Response
)
@audit()
@async_token_validation_and_metering(uom=6)
async def vessel_embeddings(request: fastapi_request, req: EmbeddingsRequest):
    try:
        openai.api_version = os.environ.get("API_VERSION_STABLE")
        response = await openai.Embedding.acreate(
            deployment_id=req.engine, input=req.input
        )

        return Response(
            status=Status.success,
            result=json.dumps(response["data"]),
            totalTokens=response.usage.total_tokens,
        )
    except Exception as e:
        logger.error(f"ERROR embeddings: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error embeddings: {error_text}"
        )


@router.post(
    "/embeddings", status_code=200, tags=["Embeddings"], response_model=Response
)
@audit()
@async_token_validation_and_metering(uom=6)
async def embeddings(request: fastapi_request, req: EmbeddingsRequest):
    try:
        headers = {}
        if "Authorization" in request.headers:
            headers["Authorization"] = request.headers["Authorization"]
        if "x-agw-client_id" in request.headers:
            headers["x-agw-client_id"] = request.headers["x-agw-client_id"]
        payload = {"input": req.input}
        url = os.environ.get("MULESOFT_EMBEDDINGS_ENDPOINT").format(
            req.engine, os.environ.get("API_VERSION_STABLE")
        )
        # logger.warning("{0}\n{1}\n{2}".format(url, payload, headers))
        response = await client.post(
            url=url, json=payload, headers=headers, timeout=120
        )
        response.raise_for_status()
        result = response.json()

        return Response(
            status=Status.success,
            result=json.dumps(result["data"]),
            totalTokens=result["usage"]["total_tokens"],
        )
    except httpx.TimeoutException as e:
        logger.error(f"MuleSoft Embeddings Timeout: {e}")
        raise HTTPException(
            status_code=408, detail=f"Error: MuleSoft embeddings Timeout"
        )
    except Exception as e:
        logger.error(f"ERROR embeddings: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error embeddings: {error_text}"
        )


@router.post("/streaming/completion", tags=["Completion"], status_code=200)
@async_token_validation_and_metering(uom=6)
async def stream_completion(request: fastapi_request, req: Request):
    tokens = 0

    def get_streaming_completion(req: Request):
        nonlocal tokens
        try:
            openai.api_version = os.environ.get("API_VERSION_STABLE")
            response = openai.Completion.create(
                engine=req.engine,
                prompt=req.prompt,
                temperature=req.temperature,
                max_tokens=req.max_tokens,
                stream=True,
            )
            encoding = tiktoken.encoding_for_model(req.engine)
            total_tokens = len(encoding.encode(req.prompt))
            total_content = ""
            for chunk in response:
                # logging.getLogger().warning(chunk)
                current_content = chunk["choices"][0]["text"]
                total_tokens += len(encoding.encode(current_content))
                total_content += current_content
                res = Response(
                    status=Status.success,
                    result=current_content
                    if chunk["choices"][0]["finish_reason"] is None
                    else total_content,
                    totalTokens=0
                    if chunk["choices"][0]["finish_reason"] is None
                    else total_tokens,
                )
                # logging.getLogger().warning(res)
                tokens = res.totalTokens
                yield (f"{json.dumps(res.dict())}\n")

        except Exception as e:
            logger.error(e)

            raise HTTPException(status_code=e.http_status, detail=f"Error: {str(e)}")

    data = get_streaming_completion(req)

    headers = {"totalTokens": (str)(tokens)}
    logging.getLogger().warning(headers)
    return StreamingResponse(data, media_type="application/x-ndjson", headers=headers)


@router.post("/streaming/chatCompletion", tags=["chatCompletion"], status_code=200)
# @async_token_validation_and_metering(uom=6)
async def stream_chatcompletion(req: ChatRequest):
    def get_streaming_chatcompletion(req: ChatRequest):
        try:
            total_tokens = 0
            openai.api_version = os.environ.get("API_VERSION_STABLE")

            # Use acreate for async
            response = openai.ChatCompletion.create(
                engine=req.engine,
                messages=req.messages,
                temperature=req.temperature,
                max_tokens=req.max_tokens,
                stream=True,
            )
            encoding = tiktoken.encoding_for_model(req.engine)
            for message in req.messages:
                for key, value in message.items():
                    total_tokens += len(encoding.encode(value))

            total_content = ""
            for chunk in response:
                logging.getLogger().warning(chunk)
                current_content = chunk["choices"][0]["delta"].get("content", "")
                total_tokens += len(encoding.encode(current_content))
                total_content += current_content
                res = Response(
                    status=Status.success,
                    result=current_content
                    if chunk["choices"][0]["finish_reason"] is None
                    else total_content,
                    totalTokens=0
                    if chunk["choices"][0]["finish_reason"] is None
                    else total_tokens,
                )
                logging.getLogger().warning(res)
                yield (f"{json.dumps(res.dict())}\n")

        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

    data = get_streaming_chatcompletion(req)
    return StreamingResponse(data, media_type="application/x-ndjson")


@router.post("/image", status_code=200, tags=["Image"], response_model=Response)
@audit()
@async_token_validation_and_metering(uom=8)
async def image_generation(request: fastapi_request, req: ImageRequest):
    try:
        openai.api_version = os.environ.get("API_VERSION_PREVIEW")
        response = await openai.Image.acreate(prompt=req.prompt, size=req.size, n=req.n)

        if req.response_format == "b64_json":
            for img_item in response["data"]:
                img_content = await client.get(url=img_item["url"])

                img_item["b64_json"] = base64.b64encode(img_content.content)
                img_item["b64_json"] = img_item["b64_json"].decode("utf-8")

                img_item.pop("url", None)

        return Response(
            status=Status.success,
            result=json.dumps(response["data"]),
            totalTokens=0,
        )
    except Exception as e:
        logger.error(f"ERROR Image: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


# @router.post("/deployment",
#             status_code=201,
#             tags=["Deployments"],
#             response_model=Deploy
#             )
# @async_token_validation_and_metering()
# async def deployment(request: fastapi_request , model:Model):
#     try:
#         item  = openai.Deployment.create( model=model.id, scale_settings={"scale_type":"standard"} )
#         return (Deploy(id= item.id,
#                                 model=item.model,
#                                 status=item.status,
#                                 owner=item.owner))
#     except Exception as e:
#         raise HTTPException(status_code=400, detail=f"Error: {str(e)}")

# @router.delete("/deployment",
#             status_code=200,
#             tags=["Deployments"]
#             )
# @async_token_validation_and_metering()
# async def deployment(request: fastapi_request ,item :Deploy):
#     try:
#         openai.Deployment.delete(sid=item.id)
#         return "Deployment {0} has been  deleted.".format(item.id)
#     except Exception as e:
#         raise HTTPException(status_code=400, detail=f"Error: {str(e)}")
