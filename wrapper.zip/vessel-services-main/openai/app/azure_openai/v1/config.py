import json
import logging
from os import environ
from base64 import b64decode

from pydantic import BaseSettings


class Settings(BaseSettings):
    log_level: int = logging.WARNING


settings = Settings()
