from enum import Enum
from typing import List, Optional, Union, Dict

from pydantic import BaseModel, Field


class Status(str, Enum):
    failure = "failure"
    success = "success"


class HealthCheckResponse(BaseModel):
    status: Status
    message: str


class Request(BaseModel):
    prompt: str
    max_tokens: int = Field(default_factory=2048)
    temperature: float = Field(0, ge=0, le=1)
    engine: str


class EmbeddingsRequest(BaseModel):
    input: Union[str, List[str]]
    engine: str


class Response(BaseModel):
    status: Status
    result: str
    totalTokens: int

    def __getitem__(self, item):
        return getattr(self, item)


class Model(BaseModel):
    id: str
    lifecycle_status: str
    fine_tune: bool
    inference: bool
    completion: bool
    embeddings: bool
    max_tokens: Optional[int]
    description: Optional[str]
    training_data: Optional[str]
    use_cases: Optional[str]
    chatCompletion: Optional[bool]
    family: Optional[str]


class Deploy(BaseModel):
    id: str
    model: str
    status: str
    owner: str


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    engine: str
    messages: List[Dict[str, str]]
    temperature: float
    max_tokens: int


class ImageRequest(BaseModel):
    prompt: str
    size: str
    n: int
    response_format: str = "url"
