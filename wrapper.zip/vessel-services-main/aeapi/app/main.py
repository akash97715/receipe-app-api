import sparknlp_jsl
from fastapi import FastAPI

from app.adverse_event.v1.api import router as ae_v1
from app.adverse_event.v1.config import settings
from app.adverse_event.v1.pipeline import Pipeline


PREFIX_V1 = "/aeapi"
TAGS_METADATA = [
    {
        "name": "Detect Adverse Events",
        "description": """Detects adverse events in an array of text entries. 
            If 'detailed' is set to true in the request, relationships between adverse 
            events and drugs are included as well.""",
    },
]

app = FastAPI(
    title="Vessel AE Services",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
)

app.include_router(ae_v1, prefix=PREFIX_V1)


@app.on_event("startup")
async def startup_event():
    # Initialize spark and the JSL pretrained pipeline at startup
    print("settings.secret",settings.secret)
    print("settings.key",settings.key)
    spark = sparknlp_jsl.start(settings.secret, params=settings.spark_params)
    Pipeline(spark)
