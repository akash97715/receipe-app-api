from enum import Enum
from typing import List, Optional

from pydantic import BaseModel


class Request(BaseModel):
    detailed: bool = False
    text: List[str]


class Status(str, Enum):
    failure = "failure"
    success = "success"


class AdverseEvent(BaseModel):
    found: bool
    confidence: float


class EntityType(str, Enum):
    adverse_event = "Adverse Event"
    drug = "Drug"
    amount = "Amount"
    route = "Route"
    other = "Other"


class Entity(BaseModel):
    type: EntityType
    text: str


class Relationship(BaseModel):
    related: bool
    confidence: float
    entity_1: Entity


class Result(BaseModel):
    adverse_event: AdverseEvent
    details: Optional[List[Relationship]] = None
    text: str


class Response(BaseModel):
    status: Status
    message: str
    results: List[Result]
    
class HealthCheckResponse(BaseModel):
    status: Status
    message: str
