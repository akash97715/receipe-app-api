import logging
import json
import pandas as pd
import re
from pathlib import Path
import pyspark.sql.functions as F
from typing import List
import pandas as pd
import re as regexr
from fastapi import Request as Request1

from fastapi import APIRouter, HTTPException

from app.adverse_event.v1.config import settings
from app.adverse_event.v1.models import (
    AdverseEvent,
    Entity,
    EntityType,
    Relationship,
    Request,
    Response,
    Result,
    Status,
    HealthCheckResponse
)
from app.adverse_event.v1.pipeline import Pipeline

from validator.decorators import async_token_validation_and_metering


router = APIRouter()
logger = logging.getLogger()
logger.setLevel(settings.log_level)



@router.get(
    "/health_check",
    status_code=200,
    tags=["Adverse Events"],
)
async def health_check():
    return HealthCheckResponse(
            status=Status.success,
            message="health_check completed successfully"
        )



@router.post(
    "/detect_adverse_events",
    status_code=200,
    tags=["Adverse Events"],
)
@async_token_validation_and_metering(uom=2)
async def detect_adverse_events(request: Request1,req: Request):
    try:
        print("entering inside function")
        print(req)
        results: List[Result] = []
        # Regex load
        path = str(Path(__file__).parent / "resources/ignore_list.txt")
        ignore_list = list(pd.read_csv(path, sep = '\t', header = None)[0])
        ignore_list = "(" + ")|(".join(ignore_list) + ")"
        ignore_list = regexr.compile(ignore_list, regexr.IGNORECASE)

        keywords = str(Path(__file__).parent / "resources/keywords.txt")
        keywords = list(pd.read_csv(keywords, sep = '\t', header = None)[0])
        
        for text in req.text:

            # Two JSL pipelines - ensemble approach for AE & NER detection and confidence
            annotations = Pipeline().jsl_light_model.fullAnnotate(text)
            adverse_event_detection = Pipeline().ade_ner_clf_pipeline.fullAnnotate(text)
            
            chunks = []
            entities = []
            sentence = []
            begin = []
            end = []
            confidence = []

            # Get the confidence value for an AE present in the text passage
            ae_confidence = None
            if "ner_chunk" in adverse_event_detection[0]:
                for anno in adverse_event_detection[0]["ner_chunk"]:
                    if "ADE" in str(anno):
                        if ignore_list.search(anno.result):
                            pass
                        else:
                            if ae_confidence is None:
                                ae_confidence = anno.metadata["confidence"]
                            elif anno.metadata["confidence"] > ae_confidence:
                                ae_confidence = anno.metadata["confidence"]

            # Parse and organize the jsl chunk annotations
            for n in annotations[0]["jsl_ner_chunk"]:
                if ignore_list.search(n.result): # here
                    pass
                else:
                    begin.append(n.begin)
                    end.append(n.end)
                    chunks.append(n.result)
                    entities.append(n.metadata["entity"])
                    sentence.append(n.metadata["sentence"])
                    confidence.append(n.metadata["confidence"])

            # jsl_df = pd.DataFrame(
            #     {
            #         "chunks": chunks,
            #         "begin": begin,
            #         "end": end,
            #         "sentence_id": sentence,
            #         "entities": entities,
            #         "confidence": confidence,
            #     }
            # )

            # if ae is found use the max confidence, otherwise use the baseline ae confidence metadata
            if ae_confidence is not None:
                ae_found = True
                confidence = ae_confidence
            else:
                for key_word in keywords:
                    match = regexr.search(key_word, text, regexr.IGNORECASE) # here
                    if match is not None:
                        ae_found = True
                        ae_confidence = 1
                        break
                    else:
                        ae_found = False
                        ae_confidence = adverse_event_detection[0]["class"][0].metadata["False"]

            # prepare the json payload if the detailed flag is set to true
            if req.detailed:
                results.append(
                    Result(
                        adverse_event=AdverseEvent(
                            found=ae_found, confidence=ae_confidence
                        ),
                        details=get_details(
                            annotations, adverse_event_detection, ae_confidence, ignore_list
                        ),
                        text=text,
                    )
                )
            else:
                results.append(
                    Result(
                        adverse_event=AdverseEvent(
                            found=ae_found, confidence=ae_confidence
                        ),
                        text=text,
                    )
                )

        return Response(
            status=Status.success,
            message="Adverse event detection completed successfully",
            results=results,
        )

    except Exception as e:
        print(str(e))
        raise HTTPException(status_code=400, detail=f"Error: {str(e)}")





def get_details(
    annotations, adverse_event_detection, ae_confidence, ignore_list
) -> List[Relationship]:
    details = []

    # create a dictionary to store entities and confidences
    ner_dict = {}

    if "ner_chunk" in adverse_event_detection[0]:
        for anno in adverse_event_detection[0]["ner_chunk"]:
            if ignore_list.search(anno.result): # here
                pass
            else:
                ner_dict[anno.result] = {}
                ner_dict[anno.result]["confidence"] = anno.metadata["confidence"]
                ner_dict[anno.result]["entity"] = anno.metadata["entity"]

    # for identified entities - choose the maximum confidence from the two chunkers
    for relation in annotations[0]["jsl_ner_chunk"]:
        det_confidence = relation.metadata["confidence"]
        if ignore_list.search(relation.result):
            pass
        else:
            if relation.result in ner_dict:
                det_confidence = max(
                    det_confidence, ner_dict[relation.result]["confidence"]
                )

            if relation.metadata["entity"] == "Symptom":
                entity = Entity(type=EntityType.adverse_event, text=relation.result)
            elif relation.metadata["entity"] == "Strength":
                entity = Entity(type=EntityType.amount, text=relation.result)
            elif "Route" in relation.metadata["entity"]:
                entity = Entity(type=EntityType.route, text=relation.result)
            elif "Drug" in relation.metadata["entity"]:
                entity = Entity(type=EntityType.drug, text=relation.result)
            else:
                entity = Entity(type=EntityType.other, text=relation.result)
                if relation.result in ner_dict:
                    entity = Entity(type=EntityType.adverse_event, text=relation.result)

        details.append(
            Relationship(
                related=True,
                confidence=det_confidence,
                entity_1=entity,
            )
        )

    return details