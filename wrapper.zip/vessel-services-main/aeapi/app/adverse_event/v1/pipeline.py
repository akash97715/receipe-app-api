from pyspark.ml import Pipeline as PysparkPipeline
from sparknlp_jsl.annotator import (
    SentenceDetectorDLModel,
    WordEmbeddingsModel,
    Tokenizer,
    MedicalNerModel,
    NerConverter,
)
from sparknlp.annotator import *
from sparknlp_jsl.annotator import *
from sparknlp.base import *

from pathlib import Path

class Pipeline(object):
    """Singleton that initializes the Pipeline only once"""

    _instance = None

    def __new__(cls, spark=None):
        if cls._instance is None:
            cls._instance = super(Pipeline, cls).__new__(cls)

            document_assembler = (
                DocumentAssembler().setInputCol("text").setOutputCol("document")
            )

            sentence_detector = (
                SentenceDetectorDLModel.pretrained(
                    "sentence_detector_dl_healthcare", "en", "clinical/models"
                )
                .setInputCols(["document"])
                .setOutputCol("sentence")
            )

            tokenizer = Tokenizer().setInputCols(["sentence"]).setOutputCol("token")

            word_embeddings = (
                WordEmbeddingsModel.pretrained(
                    "embeddings_clinical", "en", "clinical/models"
                )
                .setInputCols(["sentence", "token"])
                .setOutputCol("embeddings")
            )

            jsl_ner = (
                MedicalNerModel.pretrained("ner_jsl", "en", "clinical/models")
                .setInputCols(["sentence", "token", "embeddings"])
                .setOutputCol("jsl_ner")
            )

            jsl_ner_converter = (
                NerConverter()
                .setInputCols(["sentence", "token", "jsl_ner"])
                .setOutputCol("jsl_ner_chunk")
            )
            # full pipeline is assembled from John Snow Labs atomic elements
            jsl_ner_pipeline = PysparkPipeline(
                stages=[
                    document_assembler,
                    sentence_detector,
                    tokenizer,
                    word_embeddings,
                    jsl_ner,
                    jsl_ner_converter,
                ]
            )

            empty_data = spark.createDataFrame([[""]]).toDF("text")
            jsl_ner_model = jsl_ner_pipeline.fit(empty_data)

            # class object save the complete light model to be called for full annotation
            cls.jsl_light_model = LightPipeline(jsl_ner_model)

            # Additional set of elements are intialized for the 2nd pipeline - ensemble approach is leveraged for detection and NER
            documentAssembler_ade = (
                DocumentAssembler().setInputCol("text").setOutputCol("sentence")
            )

            tokenizer_ade = Tokenizer().setInputCols(["sentence"]).setOutputCol("token")

            bert_embeddings_ade = (
                BertEmbeddings.pretrained("biobert_pubmed_base_cased")
                .setInputCols(["sentence", "token"])
                .setOutputCol("embeddings")
            )

            ade_ner = (
                MedicalNerModel.pretrained("ner_ade_biobert", "en", "clinical/models")
                .setInputCols(["sentence", "token", "embeddings"])
                .setOutputCol("ner")
                .setStorageRef("biobert_pubmed_base_cased")
            )

            ner_converter = (
                NerConverter()
                .setInputCols(["sentence", "token", "ner"])
                .setOutputCol("ner_chunk")
            )

            assertion_ner_converter = (
                NerConverter()
                .setInputCols(["sentence", "token", "ner"])
                .setOutputCol("ass_ner_chunk")
                .setWhiteList(["ADE"])
            )

            biobert_assertion = (
                AssertionDLModel.pretrained(
                    "assertion_dl_biobert", "en", "clinical/models"
                )
                .setInputCols(["sentence", "ass_ner_chunk", "embeddings"])
                .setOutputCol("assertion")
            )

            embeddingsSentence = (
                SentenceEmbeddings()
                .setInputCols(["sentence", "embeddings"])
                .setOutputCol("sentence_embeddings")
                .setPoolingStrategy("AVERAGE")
                .setStorageRef("biobert_pubmed_base_cased")
            )

            classsifierdl = (
                ClassifierDLModel.pretrained(
                    "classifierdl_ade_conversational_biobert", "en", "clinical/models"
                )
                .setInputCols(["sentence_embeddings"])
                .setOutputCol("class")
            )

            # JSL elements are combined to form a full pipeline
            ade_clf_pipeline = PysparkPipeline(
                stages=[
                    documentAssembler_ade,
                    tokenizer_ade,
                    bert_embeddings_ade,
                    ade_ner,
                    ner_converter,
                    assertion_ner_converter,
                    biobert_assertion,
                    embeddingsSentence,
                    classsifierdl,
                ]
            )

            empty_data = spark.createDataFrame([[""]]).toDF("text")

            ade_ner_clf_model = ade_clf_pipeline.fit(empty_data)

            # ADE pipeline is stored as the 2nd class object
            cls.ade_ner_clf_pipeline = LightPipeline(ade_ner_clf_model)


        return cls._instance
