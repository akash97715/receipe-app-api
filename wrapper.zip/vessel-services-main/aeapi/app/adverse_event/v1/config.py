import json
import logging
from os import environ
from base64 import b64decode

from pydantic import BaseSettings


class Settings(BaseSettings):
    log_level: int = logging.WARNING
    secret: str = json.loads(b64decode(environ[environ["SECRET_NAME"]]))["JSL_SECRET"]
    key: str = json.loads(b64decode(environ[environ["SECRET_NAME"]]))["JSL_AWS_SECRET_ACCESS_KEY"]        
    spark_params: dict = {
        "spark.driver.memory": "16G",
        "spark.kryoserializer.buffer.max": "2000M",
        "spark.driver.maxResultSize": "2000M",
        "spark.driver.host": "0.0.0.0",
    }


settings = Settings()
