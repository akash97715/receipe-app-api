    
import os
import base64
import logging
import requests

OAUTH2_V2_VALIDATION_URL_HOST_TEMPLATE = '{0}/as/introspect.oauth2?grant_type=urn:pingidentity.com:oauth2:grant_type:validate_bearer&response_type=code&token={1}'

OAUTH2_ENV_ID = os.environ.get('PFIZER_OAUTH2_ENV_ID','1')#'1'#VesselConfig.get_core("pfizer_oauth2_env_id")
OAUTH2_VALIDATION_CLIENT_SECRET = os.environ.get('PFIZER_OAUTH2_VALIDATION_CLIENT_SECRET','')#'xB96s#aDw@py4Z'#VesselConfig.get_core("pfizer_oauth2_validation_client_secret")


#hosts pre-defined globally (TODO: shift to conf at later date)
OAUTH2_AUTH_SRV_DICT = {1 : "https://devfederate.pfizer.com" 
                      , 2 : "https://stgfederate.pfizer.com"
                      , 3 : "https://prodfederate.pfizer.com"}
                      
OAUTH2_VALIDATION_CLIENT_ID = os.environ.get('PFIZER_OAUTH2_VALIDATION_CLIENT_ID','')#'Vessel_validate'#VesselConfig.get_core("pfizer_oauth2_validation_client_id")

	
class OAuthApiAccessorError(Exception):
    def __init__(self, message, error_code):
        super(OAuthApiAccessorError, self).__init__(message)
        
        self.error_code = error_code
	
class Oauth2AsAccessor:
        
    @staticmethod
    def get_http_basic_auth_hash(user_name, password):
        return "Basic {0}".format(base64.b64encode('{0}:{1}'.format(user_name, password).encode()).decode())
    @staticmethod
    def validate_oauth2_token(oauth_token):
        #use oauth_env_id from DB (if client_id is avaliable and oauth_env_id is not provided)
        oauth_env_id = int(OAUTH2_ENV_ID)


        oauth_validation_url = OAUTH2_V2_VALIDATION_URL_HOST_TEMPLATE.format(OAUTH2_AUTH_SRV_DICT[int(oauth_env_id)], oauth_token)
        headerData = {'Authorization' : Oauth2AsAccessor.get_http_basic_auth_hash(OAUTH2_VALIDATION_CLIENT_ID, OAUTH2_VALIDATION_CLIENT_SECRET), 'content-type': 'application/x-www-form-urlencoded'}
        try:
            validation_response = requests.post(oauth_validation_url, headers=headerData)
            if validation_response.status_code in(200, 400):
                return validation_response.json()
            else:
                #log exception and raise error
                raise OAuthApiAccessorError('validate_oauth2_token API call failed with http status code {0}'.format(validation_response.status_code), 5001)
            
        
        except Exception as ex:
            logging.warning('Error occured in validate_oauth2_token API call. %s', str(ex))
            raise