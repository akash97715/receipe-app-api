import json
import os
import subprocess
import sys
from base64 import b64decode


if __name__ == "__main__":
    # Determine which branch's secrets to set
    branch_name = os.environ["BRANCH"].upper()

    # GitHub secret data is made available as an environment variable
    github_secrets = json.loads(os.environ["SECRETS"])
    secret_name = f"{os.environ['SECRET_NAME']}_{branch_name}"

    # Set env for testing
    os.environ["SECRET_NAME"] = secret_name
    os.environ[secret_name] = github_secrets[secret_name]

    # Set env for JSL
    secrets = json.loads(b64decode(os.environ[secret_name]))
    os.environ["AWS_ACCESS_KEY_ID"] = secrets["JSL_AWS_ACCESS_KEY_ID"]
    os.environ["AWS_SECRET_ACCESS_KEY"] = secrets["JSL_AWS_SECRET_ACCESS_KEY"]
    os.environ["JSL_VERSION"] = "3.3.4"
    os.environ["PUBLIC_VERSION"] = "3.3.4"
    os.environ["SECRET"] = secrets["JSL_SECRET"]
    os.environ["SPARK_NLP_LICENSE"] = secrets["JSL_SPARK_NLP_LICENSE"]

    # Install JSL spark-nlp-jsl package
    cmd = "python -m pip install --upgrade spark-nlp-jsl==$JSL_VERSION --user "
    cmd += "--extra-index-url https://pypi.johnsnowlabs.com/$SECRET"
    pip_install = subprocess.Popen(cmd, shell=True)
    pip_install.wait()

    # Run tests
    sys.exit(subprocess.call(["nosetests", "-c", "tests/nose.cfg"], env=os.environ))
