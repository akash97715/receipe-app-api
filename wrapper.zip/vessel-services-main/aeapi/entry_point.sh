#!/bin/bash

# Convert JSL_ env var secrets to the values expected by JSL
secrets=$(echo ${!SECRET_NAME} | base64 --decode)
export AWS_ACCESS_KEY_ID=$(jq -r '.JSL_AWS_ACCESS_KEY_ID' <<< "$secrets")
export AWS_SECRET_ACCESS_KEY=$(jq -r '.JSL_AWS_SECRET_ACCESS_KEY' <<< "$secrets")
export JSL_VERSION=$(jq -r '.JSL_VERSION' <<< "$secrets")
export PUBLIC_VERSION=$(jq -r '.PUBLIC_VERSION' <<< "$secrets")
export SECRET=$(jq -r '.JSL_SECRET' <<< "$secrets")
export SPARK_NLP_LICENSE=$(jq -r '.JSL_SPARK_NLP_LICENSE' <<< "$secrets")

# Install spark-nlp-jsl using the required secret
pip install --upgrade spark-nlp-jsl==$JSL_VERSION --user --extra-index-url https://pypi.johnsnowlabs.com/$SECRET

# Ensure the spark-nlp-jsl is installed successfully
if [ $? != 0 ];
then
  echo "ERROR: Failed to install spark-nlp-jsl"
  exit 1
fi

# Run the application using uvicorn
uvicorn app.main:app --host 0.0.0.0 --port 8000
